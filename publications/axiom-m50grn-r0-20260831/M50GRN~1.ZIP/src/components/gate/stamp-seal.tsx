import { STAMP_META } from "@/lib/nexus/stamp";
import { truncateHash } from "@/lib/nexus/canonical";
import { cn } from "@/lib/utils";

export function StampSeal({
  className,
  identity = "MATCH",
}: {
  className?: string;
  identity?: "MATCH" | "MISMATCH" | "PENDING";
}) {
  const hash = STAMP_META.stamp_sha256;
  return (
    <div className={cn("relative mx-auto aspect-square w-full max-w-[280px] overflow-hidden", className)}>
      <svg viewBox="0 0 320 320" className="h-full w-full" aria-hidden="true">
        <circle cx="160" cy="160" r="154" fill="none" stroke="currentColor" strokeWidth="1.2" className="text-line-strong" />
        <circle cx="160" cy="160" r="138" fill="none" stroke="currentColor" strokeWidth="0.8" className="text-line" />
        <circle cx="160" cy="160" r="118" fill="none" stroke="currentColor" strokeWidth="1.4" className="text-steel/70" />
        <circle cx="160" cy="160" r="72" fill="none" stroke="currentColor" strokeWidth="0.8" className="text-line-strong" />
        <defs>
          <path
            id="seal-ring"
            d="M160,160 m-128,0 a128,128 0 1,1 256,0 a128,128 0 1,1 -256,0"
          />
        </defs>
        <text
          fill="currentColor"
          className="text-steel"
          style={{ fontFamily: "IBM Plex Mono, ui-monospace, monospace", fontSize: 11, letterSpacing: 3.2 }}
        >
          <textPath href="#seal-ring" startOffset="0%">
            NEXUS OMEGA · HASH-BOUND · C1 · FAIL-CLOSED · GROK BUILD · xAI ·
          </textPath>
        </text>
        <text
          x="160"
          y="128"
          textAnchor="middle"
          fill="currentColor"
          className="text-fg"
          style={{ fontFamily: "IBM Plex Sans, sans-serif", fontSize: 11, letterSpacing: 4 }}
        >
          GROK BUILD
        </text>
        <text
          x="160"
          y="152"
          textAnchor="middle"
          fill="currentColor"
          className="text-steel"
          style={{ fontFamily: "IBM Plex Sans, sans-serif", fontSize: 28, fontWeight: 500 }}
        >
          Ω
        </text>
        <text
          x="160"
          y="178"
          textAnchor="middle"
          fill="currentColor"
          className="text-muted"
          style={{ fontFamily: "IBM Plex Mono, ui-monospace, monospace", fontSize: 9, letterSpacing: 1.4 }}
        >
          {truncateHash(hash, 6)}
        </text>
        <text
          x="160"
          y="198"
          textAnchor="middle"
          fill="currentColor"
          className={identity === "MATCH" ? "text-sage" : identity === "MISMATCH" ? "text-rust" : "text-amber"}
          style={{ fontFamily: "IBM Plex Mono, ui-monospace, monospace", fontSize: 10, letterSpacing: 2.4 }}
        >
          {identity}
        </text>
      </svg>
      <span className="sr-only">Grok-Validierungsstempel, Zustand {identity}</span>
    </div>
  );
}
