import { useState } from "react";
import { Check, Copy } from "lucide-react";
import { truncateHash } from "@/lib/nexus/canonical";
import { cn } from "@/lib/utils";

export function HashBlock({
  value,
  label,
  full = false,
  className,
}: {
  value: string;
  label?: string;
  full?: boolean;
  className?: string;
}) {
  const [copied, setCopied] = useState(false);
  const [open, setOpen] = useState(full);

  async function copy() {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1200);
    } catch {
      /* clipboard may be blocked */
    }
  }

  return (
    <div className={cn("min-w-0", className)}>
      {label ? (
        <div className="mb-1 font-mono text-[10px] tracking-[0.16em] text-subtle uppercase">
          {label}
        </div>
      ) : null}
      <div className="flex min-w-0 items-center gap-2">
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="min-w-0 flex-1 truncate text-left font-mono text-[12px] leading-relaxed text-steel tabular-nums"
          title={value}
        >
          {open ? value : truncateHash(value)}
        </button>
        <button
          type="button"
          onClick={copy}
          className="inline-flex size-9 shrink-0 items-center justify-center rounded-sm text-muted hover:text-fg"
          aria-label="Hash kopieren"
        >
          {copied ? <Check className="size-3.5 text-sage" /> : <Copy className="size-3.5" />}
        </button>
      </div>
    </div>
  );
}
