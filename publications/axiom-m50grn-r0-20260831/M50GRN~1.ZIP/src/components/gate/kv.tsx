import { StatusChip } from "./status-chip";
import { HashBlock } from "./hash-block";
import { cn } from "@/lib/utils";

export function Kv({
  label,
  value,
  hash = false,
  chip = false,
  className,
}: {
  label: string;
  value: string | boolean | number | null;
  hash?: boolean;
  chip?: boolean;
  className?: string;
}) {
  const text =
    value === null ? "null" : typeof value === "boolean" ? (value ? "TRUE" : "FALSE") : String(value);
  return (
    <div className={cn("min-w-0 py-2.5", className)}>
      <div className="font-mono text-[10px] tracking-[0.16em] text-subtle uppercase">{label}</div>
      <div className="mt-1 min-w-0">
        {hash && typeof value === "string" ? (
          <HashBlock value={value} />
        ) : chip ? (
          <StatusChip value={value} />
        ) : (
          <div className="break-all font-mono text-[13px] leading-relaxed text-fg">{text}</div>
        )}
      </div>
    </div>
  );
}
