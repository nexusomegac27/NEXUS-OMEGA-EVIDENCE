import type { ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Fingerprint, GitCommit, Scale, Shield, BookOpen } from "lucide-react";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Gate", icon: Shield },
  { to: "/handoff", label: "Handoff", icon: GitCommit },
  { to: "/ledger", label: "Ledger", icon: Scale },
  { to: "/stamp", label: "Stempel", icon: Fingerprint },
  { to: "/doctrine", label: "Doktrin", icon: BookOpen },
] as const;

export function GateShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="instrument-grid min-h-dvh overflow-x-hidden bg-bg text-fg">
      <div className="mx-auto flex min-h-dvh max-w-6xl flex-col lg:flex-row">
        <header className="sticky top-0 z-20 border-b border-line bg-bg/90 backdrop-blur-sm lg:hidden">
          <div className="flex items-center justify-between px-4 py-3">
            <div>
              <div className="font-mono text-[10px] tracking-[0.22em] text-steel">NEXUS OMEGA</div>
              <div className="text-sm font-medium tracking-tight">Agent Gate</div>
            </div>
            <div className="font-mono text-[10px] tracking-[0.14em] text-muted">C1 · FAIL-CLOSED</div>
          </div>
          <nav className="flex gap-1 overflow-x-auto px-2 pb-2">
            {NAV.map((item) => {
              const active = pathname === item.to;
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "inline-flex h-11 shrink-0 items-center gap-2 rounded-md px-3 text-sm",
                    active ? "bg-raised text-fg" : "text-muted hover:text-fg",
                  )}
                >
                  <Icon className="size-4" />
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </header>

        <aside className="hidden w-56 shrink-0 flex-col border-r border-line px-4 py-8 lg:flex">
          <div className="px-2">
            <div className="font-mono text-[10px] tracking-[0.22em] text-steel">NEXUS OMEGA</div>
            <div className="mt-1 text-xl font-medium tracking-tight">Agent Gate</div>
            <div className="mt-3 font-mono text-[10px] tracking-[0.16em] text-muted">
              CLAIM_CEILING = C1
            </div>
          </div>
          <nav className="mt-10 flex flex-col gap-1">
            {NAV.map((item) => {
              const active = pathname === item.to;
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "inline-flex h-11 items-center gap-3 rounded-md px-3 text-sm",
                    active ? "bg-raised text-fg" : "text-muted hover:bg-raised/60 hover:text-fg",
                  )}
                >
                  <Icon className="size-4" />
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <div className="mt-auto px-3 pt-8 font-mono text-[10px] leading-relaxed tracking-wide text-subtle">
            HASH ≠ TRUTH
            <br />
            VALIDATION ≠ PROMOTION
          </div>
        </aside>

        <main className="min-w-0 flex-1 px-4 py-6 sm:px-6 lg:px-8 lg:py-10">{children}</main>
      </div>
    </div>
  );
}
