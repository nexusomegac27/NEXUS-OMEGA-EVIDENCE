import { cn } from "@/lib/utils";

const TONE: Record<string, string> = {
  MATCH: "text-sage bg-sage/10",
  PASS: "text-sage bg-sage/10",
  PASS_WITH_CAVEATS: "text-sage bg-sage/10",
  C1: "text-steel bg-steel/10",
  "C1.1_ARTIFACT_VALIDATED_STRUCTURE_ONLY": "text-sage bg-sage/10",
  LIVE: "text-steel bg-steel/10",
  MISMATCH: "text-rust bg-rust/10",
  HARD_FAIL: "text-rust bg-rust/10",
  FAIL_MAJOR: "text-rust bg-rust/10",
  "C1.2_CLOSED": "text-rust bg-rust/10",
  FAIL_CLOSED: "text-rust bg-rust/10",
  SOURCE_NOT_PRESENT: "text-amber bg-amber/10",
  NOT_ESTABLISHED: "text-amber bg-amber/10",
  NOT_COMPUTABLE: "text-amber bg-amber/10",
  PENDING: "text-amber bg-amber/10",
  HOLD: "text-amber bg-amber/10",
  OPERATOR_REPORTED: "text-amber bg-amber/10",
  FALSE: "text-muted bg-raised",
  NONE: "text-muted bg-raised",
  NO: "text-muted bg-raised",
};

export function StatusChip({
  value,
  className,
}: {
  value: string | boolean | number | null;
  className?: string;
}) {
  const text =
    value === null ? "null" : typeof value === "boolean" ? (value ? "TRUE" : "FALSE") : String(value);
  const tone = TONE[text] ?? "text-muted bg-raised";
  return (
    <span
      className={cn(
        "inline-flex max-w-full items-center truncate rounded-sm px-2 py-0.5 font-mono text-[11px] tracking-wide",
        tone,
        className,
      )}
    >
      {text}
    </span>
  );
}
