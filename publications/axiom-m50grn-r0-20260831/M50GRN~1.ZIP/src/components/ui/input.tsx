import * as React from "react";
import { cn } from "@/lib/utils";

export function Input({ className, ...props }: React.ComponentProps<"input">) {
  return (
    <input
      className={cn(
        "flex h-11 w-full rounded-md bg-inset px-3 text-sm text-fg",
        "shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-fg)_10%,transparent)]",
        "placeholder:text-subtle",
        "focus-visible:outline-none focus-visible:shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-steel)_55%,transparent)]",
        "disabled:opacity-40",
        className,
      )}
      {...props}
    />
  );
}
