import * as React from "react";
import { cn } from "@/lib/utils";

export function Textarea({ className, ...props }: React.ComponentProps<"textarea">) {
  return (
    <textarea
      className={cn(
        "flex min-h-32 w-full rounded-md bg-inset px-3 py-2.5 text-sm text-fg font-mono leading-relaxed",
        "shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-fg)_10%,transparent)]",
        "placeholder:text-subtle placeholder:font-sans",
        "focus-visible:outline-none focus-visible:shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-steel)_55%,transparent)]",
        className,
      )}
      {...props}
    />
  );
}
