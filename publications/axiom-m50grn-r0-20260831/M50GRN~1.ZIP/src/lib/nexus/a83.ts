import {
  A83_ROLES,
  ACTOR_ROLES,
  OBS,
  RA,
  SR,
  TRANSPORT,
} from "./constants";
import { isSha256, sha256Bytes } from "./canonical";

export const A83_REQUIRED = [
  "schema_version",
  "handoff_id",
  "object_id",
  "parent_record_sha256",
  "sender_role",
  "recipient_role",
  "actor_role",
  "claim_ceiling",
  "claim_promotion",
  "integration_authority",
  "observability_class",
  "receipt_assurance",
  "scientific_relevance_class",
  "transport_class",
  "payload_sha256",
  "payload_bytes",
  "sunset_months",
  "auto_execute",
  "network_write",
  "created_at_utc",
  "caveats",
] as const;

export type A83Envelope = Record<string, unknown>;

export type A83Verdict =
  | "C1.1_ARTIFACT_VALIDATED_STRUCTURE_ONLY"
  | "C1.2_CLOSED";

const SENTINEL_PATTERNS: Array<{ id: string; re: RegExp }> = [
  { id: "CLAIM_PROMOTION", re: /claim\s*promotion\s*=\s*true/i },
  { id: "FOUNDATION_PROMOTION", re: /foundation[_ ]promotion\s*=\s*true/i },
  { id: "HASH_AS_TRUTH", re: /hash(?:es)?\s+(?:prove|proves|establishes?)\s+(?:scientific\s+)?(?:truth|validity)/i },
  { id: "SIGNATURE_AS_SCIENCE", re: /sign(?:ed|ature).{0,40}scientifically\s+valid/i },
  { id: "CONSENSUS_AS_EVIDENCE", re: /agent\s+consensus.{0,30}(?:truth|evidence|valid)/i },
  { id: "RECONSTRUCTED_ORIGINAL", re: /reconstruct(?:ed|ion).{0,40}original/i },
  { id: "SILENT_REWRITE", re: /silent(?:ly)?\s+(?:re)?writ/i },
  { id: "INVENTED_PROVENANCE", re: /invent(?:ed|ing)\s+(?:hash|doi|timestamp|provenance)/i },
];

export function sentinelHits(payloadText: string): string[] {
  const hits: string[] = [];
  for (const p of SENTINEL_PATTERNS) {
    if (p.re.test(payloadText)) hits.push(p.id);
  }
  return hits;
}

export function decisionFunction(errors: string[]): A83Verdict {
  return errors.length === 0
    ? "C1.1_ARTIFACT_VALIDATED_STRUCTURE_ONLY"
    : "C1.2_CLOSED";
}

export function validateEnvelope(
  env: A83Envelope,
  opts: {
    payloadText?: string | null;
    payloadRaw?: Uint8Array | null;
    ledgerRecordHashes?: Set<string> | null;
  } = {},
): string[] {
  const e: string[] = [];
  const keys = new Set(Object.keys(env));
  const required = new Set<string>(A83_REQUIRED);
  if (keys.size !== required.size || [...keys].some((k) => !required.has(k))) {
    e.push("A83_SCHEMA_KEYSET");
  }
  if (env.schema_version !== "1.0.0") e.push("A83_SCHEMA_VERSION");
  if (typeof env.handoff_id !== "string" || env.handoff_id.length < 8) {
    e.push("A83_HANDOFF_ID");
  }
  if (!isSha256(env.parent_record_sha256)) e.push("A83_PARENT_SHA256");
  if (
    !A83_ROLES.includes(env.sender_role as (typeof A83_ROLES)[number]) ||
    !A83_ROLES.includes(env.recipient_role as (typeof A83_ROLES)[number])
  ) {
    e.push("A83_ROLE_INVALID");
  }
  if (!ACTOR_ROLES.includes(env.actor_role as (typeof ACTOR_ROLES)[number])) {
    e.push("A83_ACTOR_ROLE_INVALID");
  }
  if (env.claim_ceiling !== "C1") e.push("A83_CLAIM_CEILING");
  if (env.claim_promotion !== false) e.push("A83_CLAIM_PROMOTION");
  if (env.integration_authority !== "NONE") e.push("A83_INTEGRATION_AUTHORITY");
  if (!OBS.includes(env.observability_class as (typeof OBS)[number])) {
    e.push("A83_OBSERVABILITY");
  }
  if (!RA.includes(env.receipt_assurance as (typeof RA)[number])) {
    e.push("A83_RECEIPT_ASSURANCE");
  }
  if (!SR.includes(env.scientific_relevance_class as (typeof SR)[number])) {
    e.push("A83_RELEVANCE");
  }
  if (!TRANSPORT.includes(env.transport_class as (typeof TRANSPORT)[number])) {
    e.push("A83_TRANSPORT");
  }
  if (!isSha256(env.payload_sha256)) e.push("A83_PAYLOAD_SHA256");
  if (typeof env.payload_bytes !== "number" || env.payload_bytes < 0 || !Number.isInteger(env.payload_bytes)) {
    e.push("A83_PAYLOAD_BYTES");
  }
  if (typeof env.sunset_months !== "number" || env.sunset_months < 12 || !Number.isInteger(env.sunset_months)) {
    e.push("A83_SUNSET_LT_12_MONTHS");
  }
  if (env.auto_execute !== false) e.push("A83_AUTO_EXECUTE_PROHIBITED");
  if (env.network_write !== false) e.push("A83_NETWORK_WRITE_PROHIBITED");
  if (env.sender_role === env.recipient_role && env.actor_role === "VALIDATOR") {
    e.push("A83_IDENTITY_FUSION");
  }
  if (
    env.observability_class === "OBS0_UNOBSERVABLE" &&
    (env.receipt_assurance === "RA3_AUTHENTICATED_PLATFORM" ||
      env.receipt_assurance === "RA4_SIGNED_OR_TIMESTAMPED" ||
      env.receipt_assurance === "RA5_EXTERNAL_TRANSPARENCY_WITNESS")
  ) {
    e.push("A83_ASSURANCE_OBSERVABILITY_CONFLICT");
  }
  if (opts.ledgerRecordHashes && isSha256(env.parent_record_sha256)) {
    if (!opts.ledgerRecordHashes.has(env.parent_record_sha256)) {
      e.push("A83_PARENT_NOT_IN_LEDGER");
    }
  }

  if (opts.payloadRaw) {
    if (opts.payloadRaw.byteLength !== env.payload_bytes) {
      e.push("A83_PAYLOAD_BYTES_MISMATCH");
    }
  }

  return [...new Set(e)].sort();
}

export async function validateEnvelopeAsync(
  env: A83Envelope,
  opts: {
    payloadText?: string | null;
    payloadRaw?: Uint8Array | null;
    ledgerRecordHashes?: Set<string> | null;
  } = {},
): Promise<string[]> {
  const e = validateEnvelope(env, opts);
  if (opts.payloadRaw) {
    const digest = await sha256Bytes(opts.payloadRaw);
    if (digest !== env.payload_sha256) e.push("A83_PAYLOAD_SHA256_MISMATCH");
    try {
      const text = new TextDecoder("utf-8", { fatal: true }).decode(opts.payloadRaw);
      e.push(...sentinelHits(text).map((x) => `A83_SENTINEL_${x}`));
    } catch {
      e.push("A83_PAYLOAD_UTF8_INVALID");
    }
  } else if (opts.payloadText != null) {
    e.push(...sentinelHits(opts.payloadText).map((x) => `A83_SENTINEL_${x}`));
  }
  return [...new Set(e)].sort();
}

export function emptyEnvelope(): A83Envelope {
  return {
    schema_version: "1.0.0",
    handoff_id: "grok-gate-handoff-001",
    object_id: "NEXUS_OMEGA_AGENT_GATE_A83_HANDOFF",
    parent_record_sha256:
      "1cdfcc74319f6f8500d969e8345ce5b6e1e6298482e03b6c96881cbbbd99dece",
    sender_role: "EXTERNAL_AGENT",
    recipient_role: "OPERATOR",
    actor_role: "VALIDATOR",
    claim_ceiling: "C1",
    claim_promotion: false,
    integration_authority: "NONE",
    observability_class: "OBS3_MEDIATED_EVENT",
    receipt_assurance: "RA2_MUTUAL_BYTE_BOUND",
    scientific_relevance_class: "SR1_PROVENANCE_SUPPORT",
    transport_class: "CONTROLLED_GATEWAY",
    payload_sha256: "0".repeat(64),
    payload_bytes: 0,
    sunset_months: 12,
    auto_execute: false,
    network_write: false,
    created_at_utc: "2026-08-31T16:01:00Z",
    caveats:
      "C1 descriptive only. Hash identity is not scientific validity. Independent four-eyes remains NOT_ESTABLISHED.",
  };
}
