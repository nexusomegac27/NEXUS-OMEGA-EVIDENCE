import { create } from "zustand";
import { persist } from "zustand/middleware";
import { appendRecord, type LatestPointer, type StoredRecord, utcNow } from "./ledger";
import { nexusSortedJsonV1 } from "./canonical";
import { stampLedgerRecord } from "./stamp";

type GateState = {
  records: StoredRecord[];
  latest: LatestPointer | null;
  bootstrapChecked: boolean[];
  appendError: string | null;
  appending: boolean;
  sealStamp: () => Promise<void>;
  appendJson: (record: Record<string, unknown>) => Promise<void>;
  resetLedger: () => void;
  toggleBootstrap: (index: number) => void;
};

export const useGateStore = create<GateState>()(
  persist(
    (set, get) => ({
      records: [],
      latest: null,
      bootstrapChecked: Array.from({ length: 12 }, () => false),
      appendError: null,
      appending: false,
      async sealStamp() {
        const already = get().records.some(
          (r) => r.entry.record_id === "validation_receipt:grok-stamp:20260831-r0",
        );
        if (already) {
          set({ appendError: "duplicate record_id: validation_receipt:grok-stamp:20260831-r0" });
          return;
        }
        await get().appendJson(stampLedgerRecord());
      },
      async appendJson(record) {
        set({ appending: true, appendError: null });
        try {
          const raw = `${nexusSortedJsonV1(record)}\n`;
          const result = await appendRecord(get().records, raw, utcNow());
          set({ records: result.all, latest: result.latest, appending: false });
        } catch (err) {
          set({
            appending: false,
            appendError: err instanceof Error ? err.message : String(err),
          });
        }
      },
      resetLedger() {
        set({ records: [], latest: null, appendError: null });
      },
      toggleBootstrap(index) {
        const next = [...get().bootstrapChecked];
        next[index] = !next[index];
        set({ bootstrapChecked: next });
      },
    }),
    {
      name: "nexus-omega-agent-gate-v1",
      partialize: (s) => ({
        records: s.records,
        latest: s.latest,
        bootstrapChecked: s.bootstrapChecked,
      }),
    },
  ),
);
