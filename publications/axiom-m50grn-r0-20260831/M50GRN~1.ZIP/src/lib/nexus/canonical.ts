const encoder = new TextEncoder();

export const INDEX_SERIALIZATION = "NEXUS_SORTED_JSON_V1" as const;

export function sortKeys(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(sortKeys);
  if (value !== null && typeof value === "object") {
    const obj = value as Record<string, unknown>;
    const out: Record<string, unknown> = {};
    for (const key of Object.keys(obj).sort()) {
      const next = obj[key];
      if (next === undefined) continue;
      out[key] = sortKeys(next);
    }
    return out;
  }
  return value;
}

/** Repository-defined deterministic JSON. Not RFC 8785 JCS. */
export function nexusSortedJsonV1(value: unknown): string {
  return JSON.stringify(sortKeys(value));
}

export function utf8Bytes(text: string): Uint8Array {
  return encoder.encode(text);
}

export function bytesToHex(bytes: ArrayBuffer | Uint8Array): string {
  const view = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  let hex = "";
  for (const b of view) hex += b.toString(16).padStart(2, "0");
  return hex;
}

export async function sha256Bytes(data: Uint8Array | ArrayBuffer): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", data as BufferSource);
  return bytesToHex(digest);
}

export async function sha256Utf8(text: string): Promise<string> {
  return sha256Bytes(utf8Bytes(text));
}

export function noDuplicateObject(pairs: [string, unknown][]): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [key, value] of pairs) {
    if (Object.prototype.hasOwnProperty.call(out, key)) {
      throw new Error(`duplicate JSON key: ${key}`);
    }
    out[key] = value;
  }
  return out;
}

export function loadJsonObject(text: string): Record<string, unknown> {
  if (text.charCodeAt(0) === 0xfeff) {
    throw new Error("UTF-8 BOM prohibited");
  }
  const obj = JSON.parse(text) as unknown;
  if (obj === null || typeof obj !== "object" || Array.isArray(obj)) {
    throw new Error("top-level JSON object required");
  }
  return obj as Record<string, unknown>;
}

export function truncateHash(hash: string, edge = 8): string {
  if (hash.length <= edge * 2 + 1) return hash;
  return `${hash.slice(0, edge)}…${hash.slice(-edge)}`;
}

export function isSha256(value: unknown): value is string {
  return typeof value === "string" && /^[0-9a-f]{64}$/.test(value);
}
