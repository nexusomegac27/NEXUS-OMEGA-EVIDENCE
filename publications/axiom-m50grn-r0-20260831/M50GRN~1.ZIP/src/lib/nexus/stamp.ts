import stampRaw from "./stamp-object.json?raw";
import stampMetaRaw from "./stamp-meta.json?raw";
import sourceManifestRaw from "./source-manifest.json?raw";
import { nexusSortedJsonV1, sha256Bytes, sha256Utf8, utf8Bytes } from "./canonical";

export const STAMP_RAW = stampRaw;
export const STAMP_OBJECT = JSON.parse(stampRaw) as Record<string, unknown>;
export const STAMP_META = JSON.parse(stampMetaRaw) as {
  stamp_sha256: string;
  stamp_bytes: number;
  identity_binding_sha256: string;
  identity_bytes: number;
  identity_canonical: string;
  r2_patch_identity: string;
};
export const SOURCE_MANIFEST = JSON.parse(sourceManifestRaw) as {
  schema_version: string;
  object_id: string;
  claim_ceiling: string;
  claim_promotion: boolean;
  package: {
    filename: string;
    bytes: number;
    sha256: string;
    locator: string;
  };
  bindings: Array<{
    filename: string;
    source_filename: string;
    bytes: number;
    sha256: string;
    media_type: string;
    locator: string;
  }>;
  stamp_object_id: string;
  stamp_bytes: number;
  stamp_sha256: string;
  identity_binding_sha256: string;
  canonicalization_method: string;
};

export const STAMP_OBJECT_ID =
  "GROK_NEXUS_OMEGA_AGENT_GATE_VALIDATION_STAMP_20260831_R0";

export const IDENTITY_BLOCK = {
  actor_role: "VALIDATOR",
  claim_ceiling: "C1",
  claim_promotion: false,
  date_utc: "2026-08-31T16:01:00Z",
  object_id: STAMP_OBJECT_ID,
  producer_asserted_identity: "Grok Build",
  producer_release: "xAI / Grok Build / 2026-04",
  provider: "xAI",
  role: "EXTERNAL_AGENT",
} as const;

export type RehashResult = {
  declared: string;
  computed: string;
  bytes: number;
  declaredBytes: number;
  identity: "MATCH" | "MISMATCH";
  bytesIdentity: "MATCH" | "MISMATCH";
};

export async function rehashStampRaw(): Promise<RehashResult> {
  const computed = await sha256Utf8(STAMP_RAW);
  const bytes = utf8Bytes(STAMP_RAW).byteLength;
  return {
    declared: STAMP_META.stamp_sha256,
    computed,
    bytes,
    declaredBytes: STAMP_META.stamp_bytes,
    identity: computed === STAMP_META.stamp_sha256 ? "MATCH" : "MISMATCH",
    bytesIdentity: bytes === STAMP_META.stamp_bytes ? "MATCH" : "MISMATCH",
  };
}

export async function rehashIdentityBlock(): Promise<RehashResult> {
  const canonical = nexusSortedJsonV1(IDENTITY_BLOCK);
  const computed = await sha256Utf8(canonical);
  const bytes = utf8Bytes(canonical).byteLength;
  return {
    declared: STAMP_META.identity_binding_sha256,
    computed,
    bytes,
    declaredBytes: STAMP_META.identity_bytes,
    identity: computed === STAMP_META.identity_binding_sha256 ? "MATCH" : "MISMATCH",
    bytesIdentity: bytes === STAMP_META.identity_bytes ? "MATCH" : "MISMATCH",
  };
}

export async function rehashPhysicalUrl(url: string): Promise<{
  bytes: number;
  sha256: string;
}> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`SOURCE_NOT_PRESENT:${url}`);
  const buf = await res.arrayBuffer();
  return { bytes: buf.byteLength, sha256: await sha256Bytes(buf) };
}

export function stampLedgerRecord(): Record<string, unknown> {
  return {
    schema_version: "1.0.0",
    record_id: "validation_receipt:grok-stamp:20260831-r0",
    record_type: "validation_receipt",
    observed_at_utc: "2026-08-31T16:01:00Z",
    recorded_at_utc: "2026-08-31T16:01:00Z",
    actor_class: "NEXUS_AI_ROLE",
    actor_asserted_identity: "GROK_BUILD",
    actor_verified_identity: null,
    provider: "xAI",
    transport_class: "CONTROLLED_GATEWAY",
    observability_class: "OBS3_MEDIATED_EVENT",
    receipt_assurance: "RA2_MUTUAL_BYTE_BOUND",
    scientific_relevance_class: "SR1_PROVENANCE_SUPPORT",
    privacy_class: "PUBLIC_FULL_TEXT",
    claim_ceiling: "C1",
    claim_promotion: false,
    content_sha256: STAMP_META.stamp_sha256,
    content_bytes: STAMP_META.stamp_bytes,
    canonicalization_method: "NEXUS_SORTED_JSON_V1",
    causal_parent_record_ids: [],
    previous_record_sha256: null,
    external_witness_refs: [],
    completeness_status: "COMPLETE",
    uncertainty: [
      "MODEL_IDENTITY_IS_ASSERTED_NOT_CRYPTOGRAPHICALLY_VERIFIED",
      "LIVE_LEDGER_PHYSICAL_OBJECT_BYTES_NOT_IN_THIS_GATE",
    ],
    event_type: "GROK_IDENTITY_STAMP_SEALED",
    source_locator: STAMP_OBJECT_ID,
  };
}
