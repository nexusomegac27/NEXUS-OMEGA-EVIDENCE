import {
  INDEX_SERIALIZATION,
  isSha256,
  nexusSortedJsonV1,
  sha256Utf8,
  utf8Bytes,
} from "./canonical";
import { PRIVACY, RECORD_TYPES, OBS, RA, SR, TRANSPORT } from "./constants";

export const INDEX_KEYS = [
  "schema_version",
  "sequence",
  "record_id",
  "record_type",
  "record_path",
  "record_bytes",
  "record_sha256",
  "previous_index_line_sha256",
  "recorded_at_utc",
  "index_serialization",
  "claim_ceiling",
  "claim_promotion",
] as const;

export const LATEST_KEYS = [
  "schema_version",
  "sequence",
  "record_id",
  "record_type",
  "record_path",
  "record_bytes",
  "record_sha256",
  "head_index_line_sha256",
  "index_path",
  "index_serialization",
  "claim_ceiling",
  "claim_promotion",
] as const;

export const INDEX_REL = "communication/index/v1/records.jsonl";
export const LATEST_REL = "communication/index/v1/latest.json";

export type IndexEntry = {
  schema_version: string;
  sequence: number;
  record_id: string;
  record_type: string;
  record_path: string;
  record_bytes: number;
  record_sha256: string;
  previous_index_line_sha256: string | null;
  recorded_at_utc: string;
  index_serialization: string;
  claim_ceiling: string;
  claim_promotion: boolean;
};

export type LatestPointer = {
  schema_version: string;
  sequence: number;
  record_id: string;
  record_type: string;
  record_path: string;
  record_bytes: number;
  record_sha256: string;
  head_index_line_sha256: string;
  index_path: string;
  index_serialization: string;
  claim_ceiling: string;
  claim_promotion: boolean;
};

export type StoredRecord = {
  raw: string;
  sha256: string;
  bytes: number;
  record: Record<string, unknown>;
  entry: IndexEntry;
  line: string;
  entryHeadHash: string;
};

export function expectedObjectPath(recordSha256: string): string {
  return `communication/objects/sha256/${recordSha256.slice(0, 2)}/${recordSha256.slice(2, 4)}/${recordSha256}/record.json`;
}

export function canonicalIndexLine(entry: IndexEntry): string {
  return nexusSortedJsonV1(entry);
}

export function semanticErrors(record: Record<string, unknown>): string[] {
  const e: string[] = [];
  if (record.schema_version !== "1.0.0") e.push("SCHEMA_VERSION");
  if (typeof record.record_id !== "string" || record.record_id.length < 3) {
    e.push("RECORD_ID");
  }
  if (!RECORD_TYPES.includes(record.record_type as (typeof RECORD_TYPES)[number])) {
    e.push("RECORD_TYPE");
  }
  if (record.claim_ceiling !== "C1") e.push("CLAIM_CEILING");
  if (record.claim_promotion !== false) e.push("CLAIM_PROMOTION");
  if (!OBS.includes(record.observability_class as (typeof OBS)[number])) {
    e.push("OBSERVABILITY");
  }
  if (!RA.includes(record.receipt_assurance as (typeof RA)[number])) {
    e.push("RECEIPT_ASSURANCE");
  }
  if (!SR.includes(record.scientific_relevance_class as (typeof SR)[number])) {
    e.push("RELEVANCE");
  }
  if (
    record.transport_class != null &&
    !TRANSPORT.includes(record.transport_class as (typeof TRANSPORT)[number])
  ) {
    e.push("TRANSPORT");
  }
  if (
    record.privacy_class != null &&
    !PRIVACY.includes(record.privacy_class as (typeof PRIVACY)[number])
  ) {
    e.push("PRIVACY");
  }
  return e;
}

export function validateLedger(records: StoredRecord[], latest: LatestPointer | null): string[] {
  const errs: string[] = [];
  if (records.length === 0) {
    if (latest) errs.push("LATEST_WITHOUT_INDEX");
    return errs;
  }
  let previousHash: string | null = null;
  const seen = new Set<string>();
  for (let i = 0; i < records.length; i += 1) {
    const offset = i + 1;
    const rec = records[i];
    const entry = rec.entry;
    if (entry.schema_version !== "1.0.0") errs.push(`INDEX_LINE_${offset}_SCHEMA_VERSION`);
    if (entry.sequence !== offset) errs.push(`INDEX_LINE_${offset}_SEQUENCE`);
    if (entry.index_serialization !== INDEX_SERIALIZATION) {
      errs.push(`INDEX_LINE_${offset}_SERIALIZATION`);
    }
    if (entry.claim_ceiling !== "C1") errs.push(`INDEX_LINE_${offset}_CLAIM_CEILING`);
    if (entry.claim_promotion !== false) errs.push(`INDEX_LINE_${offset}_CLAIM_PROMOTION`);
    if (seen.has(entry.record_id)) errs.push(`INDEX_LINE_${offset}_DUPLICATE_RECORD_ID`);
    seen.add(entry.record_id);
    if (entry.previous_index_line_sha256 !== previousHash) {
      errs.push(`INDEX_LINE_${offset}_PREVIOUS_HASH`);
    }
    if (canonicalIndexLine(entry) !== rec.line) {
      errs.push(`INDEX_LINE_${offset}_NONCANONICAL_SERIALIZATION`);
    }
    if (!isSha256(entry.record_sha256)) errs.push(`INDEX_LINE_${offset}_RECORD_SHA256`);
    else if (entry.record_path !== expectedObjectPath(entry.record_sha256)) {
      errs.push(`INDEX_LINE_${offset}_CONTENT_ADDRESS_PATH`);
    }
    if (rec.bytes !== entry.record_bytes) errs.push(`INDEX_LINE_${offset}_OBJECT_BYTES`);
    if (rec.sha256 !== entry.record_sha256) errs.push(`INDEX_LINE_${offset}_OBJECT_SHA256`);
    if (rec.record.record_id !== entry.record_id) errs.push(`INDEX_LINE_${offset}_RECORD_ID_BIND`);
    if (rec.record.record_type !== entry.record_type) {
      errs.push(`INDEX_LINE_${offset}_RECORD_TYPE_BIND`);
    }
    for (const sem of semanticErrors(rec.record)) {
      errs.push(`INDEX_LINE_${offset}_SEMANTIC:${sem}`);
    }
    previousHash = rec.entryHeadHash ?? null;
  }
  if (!latest) {
    errs.push("LATEST_NOT_PRESENT");
    return [...new Set(errs)].sort();
  }
  const last = records[records.length - 1];
  const comparisons: Array<[keyof LatestPointer, unknown]> = [
    ["sequence", last.entry.sequence],
    ["record_id", last.entry.record_id],
    ["record_type", last.entry.record_type],
    ["record_path", last.entry.record_path],
    ["record_bytes", last.entry.record_bytes],
    ["record_sha256", last.entry.record_sha256],
  ];
  for (const [key, value] of comparisons) {
    if (latest[key] !== value) errs.push(`LATEST_${String(key).toUpperCase()}_MISMATCH`);
  }
  if (latest.head_index_line_sha256 !== last.entryHeadHash) {
    errs.push("LATEST_HEAD_HASH_MISMATCH");
  }
  if (latest.index_path !== INDEX_REL) errs.push("LATEST_INDEX_PATH");
  if (latest.index_serialization !== INDEX_SERIALIZATION) errs.push("LATEST_SERIALIZATION");
  if (latest.claim_ceiling !== "C1") errs.push("LATEST_CLAIM_CEILING");
  if (latest.claim_promotion !== false) errs.push("LATEST_CLAIM_PROMOTION");
  return [...new Set(errs)].sort();
}

type MutableStored = StoredRecord;

export async function appendRecord(
  existing: StoredRecord[],
  sourceRaw: string,
  recordedAtUtc: string,
): Promise<{ record: MutableStored; latest: LatestPointer; all: MutableStored[] }> {
  const raw = sourceRaw.endsWith("\n") ? sourceRaw : `${sourceRaw}\n`;
  const record = JSON.parse(raw) as Record<string, unknown>;
  const sem = semanticErrors(record);
  if (sem.length) throw new Error(`semantic validation failed: ${sem.join(",")}`);

  const existingIds = new Set(existing.map((r) => r.entry.record_id));
  const recordId = String(record.record_id);
  if (existingIds.has(recordId)) throw new Error(`duplicate record_id: ${recordId}`);

  const digest = await sha256Utf8(raw);
  const bytes = utf8Bytes(raw).byteLength;
  const rel = expectedObjectPath(digest);
  const sequence = existing.length + 1;
  const previousLineHash = existing.length
    ? ((existing[existing.length - 1] as MutableStored).entryHeadHash ?? null)
    : null;

  const entry: IndexEntry = {
    schema_version: "1.0.0",
    sequence,
    record_id: recordId,
    record_type: String(record.record_type),
    record_path: rel,
    record_bytes: bytes,
    record_sha256: digest,
    previous_index_line_sha256: previousLineHash,
    recorded_at_utc: recordedAtUtc,
    index_serialization: INDEX_SERIALIZATION,
    claim_ceiling: "C1",
    claim_promotion: false,
  };
  const line = canonicalIndexLine(entry);
  const lineHash = await sha256Utf8(line);
  const stored: MutableStored = {
    raw,
    sha256: digest,
    bytes,
    record,
    entry,
    line,
    entryHeadHash: lineHash,
  };

  const latest: LatestPointer = {
    schema_version: "1.0.0",
    sequence,
    record_id: recordId,
    record_type: String(record.record_type),
    record_path: rel,
    record_bytes: bytes,
    record_sha256: digest,
    head_index_line_sha256: lineHash,
    index_path: INDEX_REL,
    index_serialization: INDEX_SERIALIZATION,
    claim_ceiling: "C1",
    claim_promotion: false,
  };

  const all = [...(existing as MutableStored[]), stored];
  const post = validateLedger(all, latest);
  if (post.length) {
    throw new Error(`post-append ledger validation failed: ${post.join(";")}`);
  }
  return { record: stored, latest, all };
}

export function utcNow(): string {
  return new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
}

export function baseRecord(
  recordId: string,
  extras: Partial<Record<string, unknown>> = {},
): Record<string, unknown> {
  return {
    schema_version: "1.0.0",
    record_id: recordId,
    record_type: extras.record_type ?? "event",
    observed_at_utc: extras.observed_at_utc ?? utcNow(),
    recorded_at_utc: extras.recorded_at_utc ?? utcNow(),
    actor_class: extras.actor_class ?? "NEXUS_AI_ROLE",
    actor_asserted_identity: extras.actor_asserted_identity ?? "GROK_BUILD",
    actor_verified_identity: extras.actor_verified_identity ?? null,
    provider: extras.provider ?? "xAI",
    transport_class: extras.transport_class ?? "CONTROLLED_GATEWAY",
    observability_class: extras.observability_class ?? "OBS3_MEDIATED_EVENT",
    receipt_assurance: extras.receipt_assurance ?? "RA2_MUTUAL_BYTE_BOUND",
    scientific_relevance_class: extras.scientific_relevance_class ?? "SR1_PROVENANCE_SUPPORT",
    privacy_class: extras.privacy_class ?? "METADATA_ONLY",
    claim_ceiling: "C1",
    claim_promotion: false,
    content_sha256: extras.content_sha256 ?? null,
    content_bytes: extras.content_bytes ?? null,
    canonicalization_method: extras.canonicalization_method ?? "NEXUS_SORTED_JSON_V1",
    causal_parent_record_ids: extras.causal_parent_record_ids ?? [],
    previous_record_sha256: extras.previous_record_sha256 ?? null,
    external_witness_refs: extras.external_witness_refs ?? [],
    completeness_status: extras.completeness_status ?? "COMPLETE",
    uncertainty: extras.uncertainty ?? [],
    event_type: extras.event_type ?? "GATE_EVENT",
    source_locator: extras.source_locator ?? "nexus-omega-agent-gate",
  };
}
