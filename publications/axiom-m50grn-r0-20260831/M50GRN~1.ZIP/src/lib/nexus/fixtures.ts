import { emptyEnvelope, type A83Envelope } from "./a83";

export type DerivedFixture = {
  id: string;
  title: string;
  expected: string;
  mutate: (env: A83Envelope) => A83Envelope;
  payloadRaw?: Uint8Array;
  withLedger?: boolean;
};

function clone(): A83Envelope {
  return { ...emptyEnvelope() };
}

export const DERIVED_FIXTURES: DerivedFixture[] = [
  {
    id: "FX-01",
    title: "Anspruchdecke über C1",
    expected: "A83_CLAIM_CEILING",
    mutate: (env) => ({ ...env, claim_ceiling: "C2" }),
  },
  {
    id: "FX-02",
    title: "Claim-Promotion-Pfad",
    expected: "A83_CLAIM_PROMOTION",
    mutate: (env) => ({ ...env, claim_promotion: true }),
  },
  {
    id: "FX-03",
    title: "Integrationsautorität ungleich NONE",
    expected: "A83_INTEGRATION_AUTHORITY",
    mutate: (env) => ({ ...env, integration_authority: "MERGE" }),
  },
  {
    id: "FX-04",
    title: "Auto-Execute verboten",
    expected: "A83_AUTO_EXECUTE_PROHIBITED",
    mutate: (env) => ({ ...env, auto_execute: true }),
  },
  {
    id: "FX-05",
    title: "Netzwerk-Write verboten",
    expected: "A83_NETWORK_WRITE_PROHIBITED",
    mutate: (env) => ({ ...env, network_write: true }),
  },
  {
    id: "FX-06",
    title: "Sunset unter 12 Monaten",
    expected: "A83_SUNSET_LT_12_MONTHS",
    mutate: (env) => ({ ...env, sunset_months: 6 }),
  },
  {
    id: "FX-07",
    title: "Identitätsfusion Produzent = Validator",
    expected: "A83_IDENTITY_FUSION",
    mutate: (env) => ({
      ...env,
      sender_role: "AXIOM",
      recipient_role: "AXIOM",
      actor_role: "VALIDATOR",
    }),
  },
  {
    id: "FX-08",
    title: "OBS0 mit hoher Receipt-Assurance",
    expected: "A83_ASSURANCE_OBSERVABILITY_CONFLICT",
    mutate: (env) => ({
      ...env,
      observability_class: "OBS0_UNOBSERVABLE",
      receipt_assurance: "RA4_SIGNED_OR_TIMESTAMPED",
    }),
  },
  {
    id: "FX-09",
    title: "Parent-SHA256 formal ungültig",
    expected: "A83_PARENT_SHA256",
    mutate: (env) => ({ ...env, parent_record_sha256: "not-a-hash" }),
  },
  {
    id: "FX-10",
    title: "Payload-SHA256 formal ungültig",
    expected: "A83_PAYLOAD_SHA256",
    mutate: (env) => ({ ...env, payload_sha256: "xyz" }),
  },
  {
    id: "FX-11",
    title: "Payload-Bytes negativ",
    expected: "A83_PAYLOAD_BYTES",
    mutate: (env) => ({ ...env, payload_bytes: -1 }),
  },
  {
    id: "FX-12",
    title: "Zusätzliches Schema-Feld",
    expected: "A83_SCHEMA_KEYSET",
    mutate: (env) => ({ ...env, extra: true }),
  },
  {
    id: "FX-13",
    title: "Fehlendes Pflichtfeld",
    expected: "A83_SCHEMA_KEYSET",
    mutate: (env) => {
      const next = { ...env };
      delete next.caveats;
      return next;
    },
  },
  {
    id: "FX-14",
    title: "Ungültige Rolle",
    expected: "A83_ROLE_INVALID",
    mutate: (env) => ({ ...env, sender_role: "ORACLE" }),
  },
  {
    id: "FX-15",
    title: "Schema-Version fremd",
    expected: "A83_SCHEMA_VERSION",
    mutate: (env) => ({ ...env, schema_version: "2.0.0" }),
  },
  {
    id: "FX-16",
    title: "Parent nicht im Ledger",
    expected: "A83_PARENT_NOT_IN_LEDGER",
    mutate: (env) => env,
    withLedger: true,
  },
  {
    id: "FX-17",
    title: "Physische Payload-Länge weicht ab",
    expected: "A83_PAYLOAD_BYTES_MISMATCH",
    mutate: (env) => ({ ...env, payload_bytes: 4, payload_sha256: "a".repeat(64) }),
    payloadRaw: new TextEncoder().encode("hello"),
  },
  {
    id: "FX-18",
    title: "Physische Payload-SHA256 weicht ab",
    expected: "A83_PAYLOAD_SHA256_MISMATCH",
    mutate: (env) => ({
      ...env,
      payload_bytes: 5,
      payload_sha256: "b".repeat(64),
    }),
    payloadRaw: new TextEncoder().encode("hello"),
  },
  {
    id: "FX-19",
    title: "Sentinel: Hash als Wahrheit",
    expected: "A83_SENTINEL_HASH_AS_TRUTH",
    mutate: (env) => env,
    payloadRaw: new TextEncoder().encode("This hash proves scientific truth of the claim."),
  },
  {
    id: "FX-20",
    title: "CRLF darf nicht als LF gebunden werden",
    expected: "A83_PAYLOAD_SHA256_MISMATCH",
    mutate: (env) => ({
      ...env,
      payload_bytes: 12,
      payload_sha256: "c".repeat(64),
    }),
    payloadRaw: new Uint8Array([0x6c, 0x69, 0x6e, 0x65, 0x31, 0x0d, 0x0a, 0x6c, 0x69, 0x6e, 0x65, 0x32]),
  },
];

export function baseForFixture(): A83Envelope {
  return clone();
}

export const FIXTURE_CORPUS_CLASS =
  "GATE_DERIVED_A83_NEGATIVE_FIXTURES_V1_NOT_THE_LIVE_43" as const;
