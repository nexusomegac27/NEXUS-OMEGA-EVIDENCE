export const APP_NAME = "NEXUS OMEGA Agent Gate";

export const LIVE = {
  object:
    "NEXUS_OMEGA_GITHUB_PERSISTENT_COMMUNICATION_MEMORY_PROVENANCE_FRAMEWORK_LIVE_20260831_R0",
  state: "LIVE_CORE_ESTABLISHED_WITH_LOCAL_R2_CANDIDATE_EXTENSION_PENDING_FOUR_EYES",
  repository: "nexusomegac27/NEXUS-OMEGA-EVIDENCE",
  branch: "main",
  commit: "bc312c4d2cd6afa579db1f077c88d8fe08fc9470",
  tree: "c8856faa74efa5770717d2d44dc7d51e4269cb22",
  parent: "bb1f3fd88db79d295077062895574c6d90b390bf",
  commitSignature: "GITHUB_VERIFIED_VALID",
  rulesetId: "21252293",
  rulesetName: "main-evidence-protection",
  rulesetEnforcement: "active",
  ledgerSequence: 1,
  ledgerRecordSha256:
    "1cdfcc74319f6f8500d969e8345ce5b6e1e6298482e03b6c96881cbbbd99dece",
  ledgerHeadIndexLineSha256:
    "d4b9ea8838d393776608833257a43970c2249a3bcd8ecb65ec89d6d018d8660f",
  ledgerRecordId: "event:github-pr2-merge:20260830",
  ledgerRecordBytes: 973,
  claim: "C1_DESCRIPTIVE_ONLY",
  claimCeiling: "C1",
  claimPromotion: false,
  foundationPromotion: false,
  deploymentAuthority: false,
  integrationAuthority: "NONE",
  autoFollowOn: false,
} as const;

export const R2 = {
  localCommitReported: "63698d562352bc8c62ba717c5022d0b0eb3da354",
  localTreeReported: "f76fdb5fb42a748c42bf6908981f10d14b723ddb",
  parent: LIVE.commit,
  patchSha256Documented:
    "14a53196e00e6716eb4321c12e4560e867b448a20a08d46d239813c0d17ded36",
  stateReported: "PASS_LOCAL_R2_REMEDIATION_WITH_CAVEATS_C1",
  publicGithubWrite: false,
  independentValidation: "NOT_ESTABLISHED",
  publication: "NOT_AUTHORIZED_BY_THIS_FRAMEWORK",
} as const;

export const INVARIANTS = [
  "PERSISTENCE != TRUTH",
  "HASH_IDENTITY != SEMANTIC_VALIDITY",
  "SIGNATURE != SCIENTIFIC_VALIDITY",
  "CI_PASS != CLAIM_PROMOTION",
  "AGENT_AGREEMENT != EVIDENCE",
  "PUBLICATION != AUTHORITY",
  "ROLE_LABEL != CORRECTNESS",
  "PRODUCER_RETURN != INDEPENDENT_VALIDATION",
  "VALIDATOR_PASS != CLAIM_PROMOTION",
  "IDENTITY_MATCH != CONTENT_VALIDATION",
  "FORMAL_MODEL_FIT != OPERATIONAL_VALIDATION",
  "VALIDATION != PROMOTION",
  "BLOCKED_LANE != BLOCKED_SYSTEM",
  "CONCURRENT_SERIALIZATION != CRASH_ATOMICITY",
  "GIT_BLOB_ID != CONTENT_SHA256",
] as const;

export const EVIDENCE_HIERARCHY = [
  {
    id: "E0",
    label: "Verifizierte physische / abrufbare Bytes",
    note: "Höchste Stufe. Chat darf nur lokalisieren, nie ersetzen.",
  },
  {
    id: "E1",
    label: "Unveränderliches öffentliches Git-Objekt",
    note: "Content-addressed. Identität, nicht Wahrheit.",
  },
  {
    id: "E2",
    label: "Unabhängige bytegebundene Quittung / Zeuge",
    note: "Getrennte Validierungsdomäne.",
  },
  {
    id: "E3",
    label: "Repository-Handoff / Statusobjekt",
    note: "Nur mit expliziter epistemischer Klasse.",
  },
  {
    id: "E4",
    label: "Operator- / Chat-Bericht",
    note: "Als OPERATOR_REPORTED kennzeichnen.",
  },
  {
    id: "E5",
    label: "Modell-Vorwissen / Inferenz",
    note: "Nur Discovery. Nie als Quelle.",
  },
] as const;

export const ROLES = [
  {
    id: "OPERATOR",
    name: "Operator Alexander",
    function: "Menschliche Autoritätswurzel",
    evidence: true,
    independent: true,
    mutate: "Nur explizit",
    promote: "Nur gesonderter Prozess",
  },
  {
    id: "AXIOM",
    name: "AXIOM",
    function: "Epistemische Audit / Adjudikation",
    evidence: true,
    independent: true,
    mutate: "Nur autorisiert",
    promote: "Nein",
  },
  {
    id: "CURSOR_PRAXIS",
    name: "Cursor / PRAXIS",
    function: "Implementierung und VM-Validierung",
    evidence: true,
    independent: true,
    mutate: "Nur autorisiert",
    promote: "Nein",
  },
  {
    id: "EXTERNAL_AGENT",
    name: "Externe Agenten (GROK, …)",
    function: "Forschung, Kritik, Kandidaten, unabhängige Returns",
    evidence: true,
    independent: true,
    mutate: "Nein, außer eng gewährt",
    promote: "Nein",
  },
  {
    id: "GITHUB",
    name: "GitHub / CI / Rulesets",
    function: "Transport- und Durchsetzungsinfrastruktur",
    evidence: false,
    independent: false,
    mutate: "Plattform",
    promote: "Nein",
  },
] as const;

export const OBS = [
  "OBS0_UNOBSERVABLE",
  "OBS1_PROVIDER_AGGREGATE",
  "OBS2_PROVIDER_EVENT",
  "OBS3_MEDIATED_EVENT",
  "OBS4_MUTUAL_RECEIPT",
] as const;

export const RA = [
  "RA0_NONE",
  "RA1_SELF_ASSERTED",
  "RA2_MUTUAL_BYTE_BOUND",
  "RA3_AUTHENTICATED_PLATFORM",
  "RA4_SIGNED_OR_TIMESTAMPED",
  "RA5_EXTERNAL_TRANSPARENCY_WITNESS",
] as const;

export const SR = [
  "SR0_OPERATIONAL",
  "SR1_PROVENANCE_SUPPORT",
  "SR2_PROCESS_EVENT",
  "SR3_CLAIM_EVIDENCE",
  "SR4_GOVERNANCE_VALIDATION",
  "SR5_SECURITY_INTEGRITY",
] as const;

export const TRANSPORT = [
  "CHAT_UI",
  "API",
  "GITHUB",
  "GIT",
  "FILE_UPLOAD",
  "OPERATOR_COPY_PASTE",
  "CONTROLLED_GATEWAY",
  "OTHER",
] as const;

export const A83_ROLES = [
  "OPERATOR",
  "AXIOM",
  "CURSOR_PRAXIS",
  "EXTERNAL_AGENT",
  "VALIDATOR",
  "COPILOT_CONTEXT_CONSUMER",
] as const;

export const ACTOR_ROLES = [
  "PRODUCER",
  "VALIDATOR",
  "IMPLEMENTER",
  "OPERATOR",
  "CONTEXT_CONSUMER",
] as const;

export const RECORD_TYPES = [
  "event",
  "session",
  "access_receipt",
  "communication_receipt",
  "claim_evidence_link",
  "validation_receipt",
  "correction",
  "checkpoint",
  "observability_snapshot",
] as const;

export const PRIVACY = [
  "PUBLIC_FULL_TEXT",
  "PUBLIC_REDACTED_TEXT",
  "HASH_ONLY_PUBLIC_PRIVATE_PAYLOAD",
  "METADATA_ONLY",
  "WITHHELD",
] as const;

export const STATUS_VOCAB = [
  "MATCH",
  "MISMATCH",
  "SOURCE_NOT_PRESENT",
  "NOT_ESTABLISHED",
  "NOT_COMPUTABLE",
  "PASS",
  "PASS_WITH_CAVEATS",
  "FAIL_MAJOR",
  "HARD_FAIL",
  "HOLD",
  "OPERATOR_REPORTED",
  "AXIOM_VERIFIED",
  "EXTERNALLY_VALIDATED",
  "RETRACTED",
  "SUPERSEDED",
  "C1.1_ARTIFACT_VALIDATED_STRUCTURE_ONLY",
  "C1.2_CLOSED",
] as const;

export const LIMITATIONS = [
  {
    id: "LIM-01",
    text: "Live-Ledger-Mehrschreiber-Serialisierung auf public main nicht vorhanden",
  },
  {
    id: "LIM-02",
    text: "Live-A83 physische Payload-Bytebindung unvollständig",
  },
  {
    id: "LIM-03",
    text: "Vier getrennte CI-Gates plattformseitig nicht etabliert",
  },
  {
    id: "LIM-04",
    text: "Sentinel ist Regex-/Muster-Guardrail, keine semantische Engine",
  },
  {
    id: "LIM-05",
    text: "Testdependencies versioniert, nicht voll hash-/transitiv gesperrt",
  },
  {
    id: "LIM-06",
    text: "Draft-2020-12 unabhängige Schema-Validierung nicht voll als CI-Gate",
  },
  {
    id: "LIM-07",
    text: "Öffentliches Kommunikationsledger hat nur einen echten Datensatz",
  },
  {
    id: "LIM-08",
    text: "Langfristige Multi-Actor-/Mehrschreiber-Robustheit nicht etabliert",
  },
  {
    id: "LIM-09",
    text: "Externer Transparenzzeuge nicht aktiv/etabliert",
  },
  {
    id: "LIM-10",
    text: "RFC 8785 JCS-Konformität nicht etabliert",
  },
  {
    id: "LIM-11",
    text: "Distributed Lock / NFS / Multi-Host-Sicherheit nicht etabliert",
  },
  {
    id: "LIM-12",
    text: "Crash-atomarer Multi-Datei-Ledger-Append nicht etabliert",
  },
  {
    id: "LIM-13",
    text: "R2-Remediation lokal und noch nicht unabhängig vieräugig validiert",
  },
  {
    id: "LIM-14",
    text: "R2 ist nicht öffentlich und nicht Teil von live main",
  },
] as const;

export const EVOLUTION_GATES = [
  { id: "G0", label: "Quellenidentität", detail: "Exakte Bytes existieren und sind abrufbar." },
  { id: "G1", label: "Strukturelle Gültigkeit", detail: "Schemata, Formate, Bindungen validieren." },
  { id: "G2", label: "Semantik / Falsifikation", detail: "Negative Tests und adversariale Sonden." },
  { id: "G3", label: "Unabhängige Validierung", detail: "Getrennter Validator reproduziert." },
  { id: "G4", label: "Repository-Transport", detail: "Branch / Commit / PR-Identitäten." },
  { id: "G5", label: "CI", detail: "Mechanische Gates laufen durch." },
  { id: "G6", label: "Operator-Disposition", detail: "Publikation / Merge explizit autorisiert." },
  { id: "G7", label: "Post-Merge-Prüfung", detail: "Gemergte Bytes unabhängig nachgeprüft." },
  { id: "G8", label: "Optionaler externer Zeuge", detail: "Archiv / Transparenz gebunden." },
] as const;

export const BOOTSTRAP_STEPS = [
  "FETCH repository metadata",
  "FETCH main HEAD",
  "VERIFY exact commit/tree",
  "READ AGENTS.md",
  "READ GOVERNANCE.md",
  "READ docs/AI_CONTEXT.md",
  "READ docs/agent-protocol.md",
  "READ docs/AI_HANDOFF_PROTOCOL.md",
  "RESOLVE relevant latest ledger/checkpoint",
  "IDENTIFY latest applicable handoff",
  "CLASSIFY operator/chat-only deltas as OPERATOR_REPORTED",
  "CONTINUE only from byte-bound predecessor",
] as const;

export const HARD_FAILS = [
  "BOUND_ARTIFACT_HASH_MISMATCH",
  "SOURCE_OBJECT_SUBSTITUTION",
  "RECONSTRUCTED_MISSING_ORIGINAL_PRESENTED_AS_ORIGINAL",
  "CLAIM_PROMOTION_PATH_WITHOUT_AUTHORITY",
  "HISTORICAL_EVIDENCE_SILENT_REWRITE",
  "INVENTED_HASH_OR_BYTE_COUNT",
  "INVENTED_ACCESS_EVENT",
  "INVALID_PARENT_BIND",
  "UNAUTHORIZED_PUBLIC_WRITE",
  "UNAUTHORIZED_MAIN_MUTATION",
  "UNAUTHORIZED_FORCE_PUSH",
] as const;

export const RESEARCH_PROGRAMS = [
  { id: "R1", text: "Dauerhafte maschinenlesbare Session-Kommunikation" },
  { id: "R2", text: "Content-addressed kausale Provenienz" },
  { id: "R3", text: "Fail-closed Trennung von Quelle und Claim" },
  { id: "R4", text: "Multi-Agent Vier-Augen-Validierung" },
  { id: "R5", text: "GitHub-native Policy-Enforcement" },
  { id: "R6", text: "Sicheres Mehrschreiber- / crash-konsistentes Ledgering" },
  { id: "R7", text: "Physische Payload-Bytebindung" },
  { id: "R8", text: "Sprachübergreifende Kanonisierung" },
  { id: "R9", text: "Optionaler externer Transparenz- / Archivzeuge" },
  { id: "R10", text: "Getrennte Failure-Domain-Architektur" },
  { id: "R11", text: "Langfristige Multi-Actor-Belastungsvalidierung" },
  { id: "R12", text: "Öffentliche Auffindbarkeit ohne falsche Access-Vollständigkeit" },
] as const;
