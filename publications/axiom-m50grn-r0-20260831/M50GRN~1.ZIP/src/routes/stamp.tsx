import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Download, Fingerprint, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Panel } from "@/components/gate/panel";
import { StampSeal } from "@/components/gate/stamp-seal";
import { HashBlock } from "@/components/gate/hash-block";
import { StatusChip } from "@/components/gate/status-chip";
import { Kv } from "@/components/gate/kv";
import {
  IDENTITY_BLOCK,
  SOURCE_MANIFEST,
  STAMP_META,
  STAMP_OBJECT,
  STAMP_OBJECT_ID,
  STAMP_RAW,
  rehashIdentityBlock,
  rehashPhysicalUrl,
  rehashStampRaw,
  type RehashResult,
} from "@/lib/nexus/stamp";
import { useGateStore } from "@/lib/nexus/store";

export const Route = createFileRoute("/stamp")({ component: StampPage });

type SourceCheck = {
  filename: string;
  declared: string;
  declaredBytes: number;
  computed?: string;
  bytes?: number;
  status: "PENDING" | "MATCH" | "MISMATCH" | "SOURCE_NOT_PRESENT";
};

function StampPage() {
  const [stamp, setStamp] = useState<RehashResult | null>(null);
  const [identity, setIdentity] = useState<RehashResult | null>(null);
  const [physical, setPhysical] = useState<RehashResult | null>(null);
  const [sources, setSources] = useState<SourceCheck[]>(
    SOURCE_MANIFEST.bindings.map((b) => ({
      filename: b.filename,
      declared: b.sha256,
      declaredBytes: b.bytes,
      status: "PENDING",
    })),
  );
  const [busy, setBusy] = useState(false);
  const sealStamp = useGateStore((s) => s.sealStamp);
  const appending = useGateStore((s) => s.appending);
  const appendError = useGateStore((s) => s.appendError);
  const records = useGateStore((s) => s.records);
  const sealed = records.some(
    (r) => r.entry.record_id === "validation_receipt:grok-stamp:20260831-r0",
  );

  async function runRehash() {
    setBusy(true);
    try {
      const [s, i] = await Promise.all([rehashStampRaw(), rehashIdentityBlock()]);
      setStamp(s);
      setIdentity(i);
      try {
        const phys = await rehashPhysicalUrl("/evidence/GROK-VALIDATION-STAMP-20260831-R0.json");
        setPhysical({
          declared: STAMP_META.stamp_sha256,
          computed: phys.sha256,
          bytes: phys.bytes,
          declaredBytes: STAMP_META.stamp_bytes,
          identity: phys.sha256 === STAMP_META.stamp_sha256 ? "MATCH" : "MISMATCH",
          bytesIdentity: phys.bytes === STAMP_META.stamp_bytes ? "MATCH" : "MISMATCH",
        });
      } catch {
        setPhysical({
          declared: STAMP_META.stamp_sha256,
          computed: "",
          bytes: 0,
          declaredBytes: STAMP_META.stamp_bytes,
          identity: "MISMATCH",
          bytesIdentity: "MISMATCH",
        });
      }
    } finally {
      setBusy(false);
    }
  }

  async function rehashSources() {
    setBusy(true);
    const next: SourceCheck[] = [];
    for (const b of SOURCE_MANIFEST.bindings) {
      try {
        const phy = await rehashPhysicalUrl(b.locator);
        next.push({
          filename: b.filename,
          declared: b.sha256,
          declaredBytes: b.bytes,
          computed: phy.sha256,
          bytes: phy.bytes,
          status:
            phy.sha256 === b.sha256 && phy.bytes === b.bytes ? "MATCH" : "MISMATCH",
        });
      } catch {
        next.push({
          filename: b.filename,
          declared: b.sha256,
          declaredBytes: b.bytes,
          status: "SOURCE_NOT_PRESENT",
        });
      }
    }
    setSources(next);
    setBusy(false);
  }

  useEffect(() => {
    void runRehash();
  }, []);

  function downloadStamp() {
    const blob = new Blob([STAMP_RAW], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "GROK-VALIDATION-STAMP-20260831-R0.json";
    a.click();
    URL.revokeObjectURL(url);
  }

  const face = stamp?.identity ?? "PENDING";

  return (
    <div className="space-y-6">
      <header>
        <p className="font-mono text-[11px] tracking-[0.2em] text-steel uppercase">
          Hashgebundener Validierungsstempel
        </p>
        <h1 className="mt-2 text-3xl font-medium tracking-tight">Grok · xAI</h1>
        <p className="mt-3 max-w-2xl text-[15px] leading-relaxed text-muted">
          Externe Agenten-Identität, bytegebunden über NEXUS_SORTED_JSON_V1.
          Die Modellbezeichnung ist asserted, nicht kryptographisch verifiziert.
          Der Digest beweist Byteidentität — nicht wissenschaftliche Wahrheit.
        </p>
      </header>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,280px)_1fr]">
        <Panel>
          <StampSeal identity={face === "PENDING" ? "PENDING" : face} />
          <div className="mt-4 flex flex-col gap-2">
            <Button onClick={() => void runRehash()} variant="secondary" disabled={busy}>
              <RefreshCw className="size-4" />
              Neu hashen
            </Button>
            <Button onClick={downloadStamp} variant="secondary">
              <Download className="size-4" />
              Stempel-JSON
            </Button>
            <Button onClick={() => void sealStamp()} disabled={appending || sealed}>
              <Fingerprint className="size-4" />
              {sealed ? "Im Ledger gesiegelt" : "In lokales Ledger siegeln"}
            </Button>
            {appendError ? (
              <p className="text-xs text-rust">{appendError}</p>
            ) : null}
          </div>
        </Panel>

        <Panel kicker="Bindung" title="Unabhängiger Rehash">
          <div className="grid gap-x-6 sm:grid-cols-2">
            <Kv label="OBJECT_ID" value={STAMP_OBJECT_ID} />
            <Kv label="DATE_UTC" value={String(STAMP_OBJECT.date_utc)} />
            <Kv label="PRODUCER" value={String(STAMP_OBJECT.producer_asserted_identity)} />
            <Kv label="VERIFIED_IDENTITY" value={STAMP_OBJECT.producer_verified_identity as null} chip />
            <Kv label="ROLE" value={String(STAMP_OBJECT.from_role)} />
            <Kv label="ACTOR_ROLE" value={String(STAMP_OBJECT.actor_role)} />
            <Kv label="CLAIM_CEILING" value="C1" chip />
            <Kv label="CLAIM_PROMOTION" value={false} chip />
          </div>
          <div className="mt-4 space-y-3 rounded-md bg-inset p-3">
            <Row result={stamp} label="Kanonisches Stempel-Objekt (Import)" />
            <Row result={physical} label="Physische Datei /evidence/…json" />
            <Row result={identity} label="Identitätsblock GROK BUILD / xAI" />
          </div>
          <HashBlock className="mt-4" label="IDENTITY_BINDING_SHA256" value={STAMP_META.identity_binding_sha256} />
        </Panel>
      </div>

      <Panel
        kicker="Physische Inputs"
        title="Quellen-Rehash"
        action={
          <Button size="sm" variant="secondary" onClick={() => void rehashSources()} disabled={busy}>
            Quellen prüfen
          </Button>
        }
      >
        <p className="mb-4 text-sm text-muted">
          Jede Datei wird als physische Bytes geladen und gegen das Source-Manifest gehalten.
          Keine Rekonstruktion fehlender Originale.
        </p>
        <div className="divide-y divide-line">
          {sources.map((s) => (
            <div key={s.filename} className="flex flex-col gap-1 py-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="min-w-0">
                <div className="truncate text-sm text-fg">{s.filename}</div>
                <div className="font-mono text-[11px] text-subtle tabular-nums">
                  {s.declaredBytes} B · {s.declared.slice(0, 12)}…
                </div>
              </div>
              <StatusChip value={s.status} />
            </div>
          ))}
        </div>
      </Panel>

      <Panel kicker="Identitätsblock" title="NEXUS_SORTED_JSON_V1">
        <pre className="overflow-x-auto rounded-md bg-inset p-4 font-mono text-[12px] leading-relaxed text-steel">
          {JSON.stringify(IDENTITY_BLOCK, null, 2)}
        </pre>
      </Panel>

      <Panel kicker="Ausgeführt / Nicht ausgeführt">
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <h3 className="font-mono text-[10px] tracking-[0.16em] text-subtle uppercase">Work executed</h3>
            <ul className="mt-2 space-y-1.5">
              {(STAMP_OBJECT.work_executed as string[]).map((w) => (
                <li key={w} className="font-mono text-[12px] text-sage">
                  {w}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="font-mono text-[10px] tracking-[0.16em] text-subtle uppercase">Work not executed</h3>
            <ul className="mt-2 space-y-1.5">
              {(STAMP_OBJECT.work_not_executed as string[]).map((w) => (
                <li key={w} className="font-mono text-[12px] text-muted">
                  {w}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Panel>
    </div>
  );
}

function Row({ result, label }: { result: RehashResult | null; label: string }) {
  return (
    <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
      <div className="text-sm text-fg">{label}</div>
      <div className="flex flex-wrap items-center gap-2">
        {result ? (
          <>
            <StatusChip value={result.identity} />
            <span className="font-mono text-[11px] text-subtle tabular-nums">
              {result.bytes} B
            </span>
          </>
        ) : (
          <StatusChip value="PENDING" />
        )}
      </div>
    </div>
  );
}
