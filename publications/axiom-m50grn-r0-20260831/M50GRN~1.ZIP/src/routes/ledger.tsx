import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Panel } from "@/components/gate/panel";
import { StatusChip } from "@/components/gate/status-chip";
import { HashBlock } from "@/components/gate/hash-block";
import { Kv } from "@/components/gate/kv";
import { LIVE } from "@/lib/nexus/constants";
import { baseRecord, validateLedger } from "@/lib/nexus/ledger";
import { useGateStore } from "@/lib/nexus/store";

export const Route = createFileRoute("/ledger")({ component: LedgerPage });

function LedgerPage() {
  const records = useGateStore((s) => s.records);
  const latest = useGateStore((s) => s.latest);
  const appendJson = useGateStore((s) => s.appendJson);
  const resetLedger = useGateStore((s) => s.resetLedger);
  const sealStamp = useGateStore((s) => s.sealStamp);
  const appending = useGateStore((s) => s.appending);
  const appendError = useGateStore((s) => s.appendError);
  const [recordId, setRecordId] = useState("event:gate-note:0001");
  const [note, setNote] = useState("C1 descriptive local event. No claim promotion.");

  const errors = useMemo(() => validateLedger(records, latest), [records, latest]);

  async function appendNote() {
    await appendJson(
      baseRecord(recordId, {
        event_type: "GATE_NOTE",
        source_locator: note.slice(0, 120),
        completeness_status: "COMPLETE",
      }),
    );
  }

  return (
    <div className="space-y-6">
      <header>
        <p className="font-mono text-[11px] tracking-[0.2em] text-steel uppercase">
          Content-addressed Ledger
        </p>
        <h1 className="mt-2 text-3xl font-medium tracking-tight">Wissenschaftliches Ledger</h1>
        <p className="mt-3 max-w-2xl text-[15px] leading-relaxed text-muted">
          Append-only. Korrekturen erzeugen neue Objekte. Der öffentliche Live-Head bleibt
          SOURCE_NOT_PRESENT — fehlende Bytes werden nicht rekonstruiert.
        </p>
      </header>

      <div className="grid gap-4 lg:grid-cols-2">
        <Panel kicker="Public main" title="Deklarierter Live-Head">
          <div className="grid sm:grid-cols-2">
            <Kv label="SEQUENCE" value={LIVE.ledgerSequence} />
            <Kv label="RECORD_ID" value={LIVE.ledgerRecordId} />
            <Kv label="RECORD_BYTES" value={LIVE.ledgerRecordBytes} />
            <Kv label="PHYSICAL_OBJECT" value="SOURCE_NOT_PRESENT" chip />
          </div>
          <HashBlock className="mt-2" label="RECORD_SHA256" value={LIVE.ledgerRecordSha256} />
          <HashBlock
            className="mt-2"
            label="HEAD_INDEX_LINE_SHA256"
            value={LIVE.ledgerHeadIndexLineSha256}
          />
        </Panel>

        <Panel
          kicker="Dieses Gate"
          title="Lokaler Zustand"
          action={<StatusChip value={errors.length ? "FAIL_CLOSED" : records.length ? "PASS" : "HOLD"} />}
        >
          <div className="grid sm:grid-cols-2">
            <Kv label="LOCAL_SEQUENCE" value={latest?.sequence ?? 0} />
            <Kv label="RECORDS" value={records.length} />
          </div>
          {latest ? (
            <>
              <HashBlock className="mt-2" label="HEAD SHA256" value={latest.record_sha256} />
              <HashBlock className="mt-2" label="HEAD INDEX LINE" value={latest.head_index_line_sha256} />
            </>
          ) : (
            <p className="mt-2 text-sm text-muted">Noch kein lokaler Datensatz.</p>
          )}
          {errors.length ? (
            <ul className="mt-3 space-y-1">
              {errors.map((e) => (
                <li key={e} className="font-mono text-[12px] text-rust">
                  {e}
                </li>
              ))}
            </ul>
          ) : null}
        </Panel>
      </div>

      <Panel kicker="Append" title="Datensatz anfügen">
        <div className="grid gap-3 sm:grid-cols-2">
          <label>
            <div className="mb-1.5 font-mono text-[10px] tracking-[0.14em] text-subtle uppercase">
              record_id
            </div>
            <Input value={recordId} onChange={(e) => setRecordId(e.target.value)} />
          </label>
          <div className="flex items-end gap-2">
            <Button onClick={() => void appendNote()} disabled={appending}>
              Anfügen
            </Button>
            <Button variant="secondary" onClick={() => void sealStamp()} disabled={appending}>
              Grok-Stempel siegeln
            </Button>
            <Button variant="ghost" onClick={resetLedger}>
              Zurücksetzen
            </Button>
          </div>
        </div>
        <label className="mt-3 block">
          <div className="mb-1.5 font-mono text-[10px] tracking-[0.14em] text-subtle uppercase">
            source_locator / note
          </div>
          <Textarea className="min-h-24 font-sans" value={note} onChange={(e) => setNote(e.target.value)} />
        </label>
        {appendError ? <p className="mt-2 text-sm text-rust">{appendError}</p> : null}
        <p className="mt-3 text-xs leading-relaxed text-subtle">
          Browser-Ledger ist einzelprozessig serialisiert. Das beweist keine Crash-Atomizität
          und keine POSIX-flock-Semantik (LIM-01, LIM-12).
        </p>
      </Panel>

      <Panel kicker="Index" title="records.jsonl">
        {records.length === 0 ? (
          <p className="text-sm text-muted">Leer. Negative Evidenz: kein lokaler Head.</p>
        ) : (
          <ol className="space-y-3">
            {records.map((r) => (
              <li
                key={r.entry.record_id}
                className="rounded-md bg-inset p-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="font-mono text-[12px] text-steel">
                    #{r.entry.sequence} · {r.entry.record_type}
                  </div>
                  <StatusChip value="C1" />
                </div>
                <div className="mt-1 text-sm text-fg">{r.entry.record_id}</div>
                <HashBlock className="mt-2" value={r.entry.record_sha256} />
                <div className="mt-1 font-mono text-[11px] text-subtle">
                  {r.entry.record_bytes} B · {r.entry.recorded_at_utc}
                </div>
              </li>
            ))}
          </ol>
        )}
      </Panel>
    </div>
  );
}
