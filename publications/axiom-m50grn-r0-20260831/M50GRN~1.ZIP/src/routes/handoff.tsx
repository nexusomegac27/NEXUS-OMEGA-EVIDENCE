import { useMemo, useState, type ReactNode } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Panel } from "@/components/gate/panel";
import { StatusChip } from "@/components/gate/status-chip";
import { HashBlock } from "@/components/gate/hash-block";
import {
  A83_REQUIRED,
  decisionFunction,
  emptyEnvelope,
  validateEnvelopeAsync,
  type A83Envelope,
  type A83Verdict,
} from "@/lib/nexus/a83";
import { A83_ROLES, ACTOR_ROLES, OBS, RA, SR, TRANSPORT } from "@/lib/nexus/constants";
import { sha256Bytes, utf8Bytes } from "@/lib/nexus/canonical";
import { useGateStore } from "@/lib/nexus/store";

export const Route = createFileRoute("/handoff")({ component: HandoffPage });

function HandoffPage() {
  const [env, setEnv] = useState<A83Envelope>(emptyEnvelope);
  const [payload, setPayload] = useState(
    "C1 descriptive handoff. Hash identity is not scientific validity.",
  );
  const [errors, setErrors] = useState<string[] | null>(null);
  const [verdict, setVerdict] = useState<A83Verdict | null>(null);
  const [bound, setBound] = useState<{ bytes: number; sha256: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const records = useGateStore((s) => s.records);
  const ledgerHashes = useMemo(
    () => new Set(records.map((r) => r.entry.record_sha256)),
    [records],
  );

  function setField(key: string, value: unknown) {
    setEnv((e) => ({ ...e, [key]: value }));
    setErrors(null);
    setVerdict(null);
  }

  async function bindPayload(text: string) {
    const raw = utf8Bytes(text);
    const digest = await sha256Bytes(raw);
    setBound({ bytes: raw.byteLength, sha256: digest });
    setEnv((e) => ({ ...e, payload_bytes: raw.byteLength, payload_sha256: digest }));
  }

  async function onPayloadChange(text: string) {
    setPayload(text);
    await bindPayload(text);
  }

  async function validate(rawOverride?: Uint8Array) {
    setBusy(true);
    try {
      const raw = rawOverride ?? utf8Bytes(payload);
      const digest = await sha256Bytes(raw);
      const next = {
        ...env,
        payload_bytes: env.payload_bytes,
        payload_sha256: env.payload_sha256,
      };
      const errs = await validateEnvelopeAsync(next, {
        payloadRaw: raw,
        ledgerRecordHashes: ledgerHashes.size ? ledgerHashes : null,
      });
      setBound({ bytes: raw.byteLength, sha256: digest });
      setErrors(errs);
      setVerdict(decisionFunction(errs));
    } finally {
      setBusy(false);
    }
  }

  async function probe(kind: "crlf" | "bom" | "nul" | "extra") {
    let raw = utf8Bytes(payload);
    if (kind === "crlf") raw = utf8Bytes(payload.replace(/\n/g, "\r\n"));
    if (kind === "bom") {
      const next = new Uint8Array(3 + raw.byteLength);
      next.set([0xef, 0xbb, 0xbf]);
      next.set(raw, 3);
      raw = next;
    }
    if (kind === "nul") {
      const next = new Uint8Array(raw.byteLength + 1);
      next.set(raw);
      next[raw.byteLength] = 0;
      raw = next;
    }
    if (kind === "extra") {
      const next = new Uint8Array(raw.byteLength + 1);
      next.set(raw);
      next[raw.byteLength] = 0x78;
      raw = next;
    }
    await validate(raw);
  }

  return (
    <div className="space-y-6">
      <header>
        <p className="font-mono text-[11px] tracking-[0.2em] text-steel uppercase">A83</p>
        <h1 className="mt-2 text-3xl font-medium tracking-tight">Handoff-Gate</h1>
        <p className="mt-3 max-w-2xl text-[15px] leading-relaxed text-muted">
          Strukturelle Handoff-Validierung mit physischer Payload-Bindung.
          Entscheidungshöhe: C1.1 Struktur only — keine wissenschaftliche Promotion.
          Live-Base ohne Bytebindung bleibt als LIM-02 registriert; dieses Gate prüft die Bytes.
        </p>
      </header>

      <div className="grid gap-4 lg:grid-cols-2">
        <Panel kicker="Envelope" title="A83 v1.0.0">
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="handoff_id">
              <Input value={String(env.handoff_id)} onChange={(e) => setField("handoff_id", e.target.value)} />
            </Field>
            <Field label="object_id">
              <Input value={String(env.object_id)} onChange={(e) => setField("object_id", e.target.value)} />
            </Field>
            <Field label="sender_role">
              <Select value={String(env.sender_role)} onChange={(v) => setField("sender_role", v)} options={A83_ROLES} />
            </Field>
            <Field label="recipient_role">
              <Select value={String(env.recipient_role)} onChange={(v) => setField("recipient_role", v)} options={A83_ROLES} />
            </Field>
            <Field label="actor_role">
              <Select value={String(env.actor_role)} onChange={(v) => setField("actor_role", v)} options={ACTOR_ROLES} />
            </Field>
            <Field label="observability_class">
              <Select value={String(env.observability_class)} onChange={(v) => setField("observability_class", v)} options={OBS} />
            </Field>
            <Field label="receipt_assurance">
              <Select value={String(env.receipt_assurance)} onChange={(v) => setField("receipt_assurance", v)} options={RA} />
            </Field>
            <Field label="scientific_relevance_class">
              <Select value={String(env.scientific_relevance_class)} onChange={(v) => setField("scientific_relevance_class", v)} options={SR} />
            </Field>
            <Field label="transport_class">
              <Select value={String(env.transport_class)} onChange={(v) => setField("transport_class", v)} options={TRANSPORT} />
            </Field>
            <Field label="sunset_months">
              <Input
                type="number"
                value={String(env.sunset_months)}
                onChange={(e) => setField("sunset_months", Number(e.target.value))}
              />
            </Field>
            <Field label="parent_record_sha256" className="sm:col-span-2">
              <Input
                className="font-mono text-xs"
                value={String(env.parent_record_sha256)}
                onChange={(e) => setField("parent_record_sha256", e.target.value)}
              />
            </Field>
            <Field label="caveats" className="sm:col-span-2">
              <Textarea
                className="min-h-24 font-sans"
                value={String(env.caveats)}
                onChange={(e) => setField("caveats", e.target.value)}
              />
            </Field>
          </div>
          <p className="mt-3 font-mono text-[11px] text-subtle">
            Pflichtfelder: {A83_REQUIRED.length} · claim_ceiling=C1 · promotion=false · integration=NONE · auto_execute=false · network_write=false
          </p>
        </Panel>

        <div className="space-y-4">
          <Panel kicker="Physische Payload" title="Bytebindung">
            <Textarea
              value={payload}
              onChange={(e) => void onPayloadChange(e.target.value)}
              onFocus={() => {
                if (!bound) void bindPayload(payload);
              }}
            />
            <div className="mt-3 flex flex-wrap gap-2">
              <Button size="sm" onClick={() => void bindPayload(payload)} variant="secondary">
                Payload binden
              </Button>
              <Button size="sm" onClick={() => void validate()} disabled={busy}>
                Validieren
              </Button>
            </div>
            {bound ? (
              <div className="mt-3 space-y-1">
                <div className="font-mono text-[11px] text-muted">{bound.bytes} Bytes</div>
                <HashBlock label="PHYSICAL SHA256" value={bound.sha256} />
                <HashBlock label="ENVELOPE SHA256" value={String(env.payload_sha256)} />
              </div>
            ) : null}
          </Panel>

          <Panel kicker="Adversarial" title="Physische Sonden">
            <p className="mb-3 text-sm text-muted">
              Dieselben Envelope-Felder, andere physische Bytes. Nur exaktes Hashen der Rohbytes trägt eine Bytebindungs-Behauptung.
            </p>
            <div className="flex flex-wrap gap-2">
              <Button size="sm" variant="secondary" onClick={() => void probe("crlf")}>
                CRLF
              </Button>
              <Button size="sm" variant="secondary" onClick={() => void probe("bom")}>
                UTF-8 BOM
              </Button>
              <Button size="sm" variant="secondary" onClick={() => void probe("nul")}>
                NUL
              </Button>
              <Button size="sm" variant="secondary" onClick={() => void probe("extra")}>
                Extra-Byte
              </Button>
            </div>
          </Panel>

          <Panel kicker="Verdict">
            {verdict ? (
              <div className="space-y-3">
                <StatusChip value={verdict} className="text-xs" />
                {errors && errors.length === 0 ? (
                  <p className="text-sm text-sage">
                    Struktur validiert. Das ist nicht Claim-Promotion.
                  </p>
                ) : (
                  <ul className="space-y-1">
                    {errors?.map((err) => (
                      <li key={err} className="font-mono text-[12px] text-rust">
                        {err}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ) : (
              <p className="text-sm text-muted">Noch nicht geprüft.</p>
            )}
          </Panel>
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  children,
  className,
}: {
  label: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={className}>
      <div className="mb-1.5 font-mono text-[10px] tracking-[0.14em] text-subtle uppercase">{label}</div>
      {children}
    </label>
  );
}

function Select({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (v: string) => void;
  options: readonly string[];
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="flex h-11 w-full rounded-md bg-inset px-3 text-sm text-fg shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-fg)_10%,transparent)] focus-visible:outline-none"
    >
      {options.map((o) => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
  );
}
