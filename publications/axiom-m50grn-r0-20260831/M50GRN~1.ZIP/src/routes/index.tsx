import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { LIVE, R2, INVARIANTS } from "@/lib/nexus/constants";
import { STAMP_META, STAMP_OBJECT_ID, rehashStampRaw, type RehashResult } from "@/lib/nexus/stamp";
import { StampSeal } from "@/components/gate/stamp-seal";
import { Panel } from "@/components/gate/panel";
import { Kv } from "@/components/gate/kv";
import { StatusChip } from "@/components/gate/status-chip";
import { HashBlock } from "@/components/gate/hash-block";
import { Button } from "@/components/ui/button";
import { useGateStore } from "@/lib/nexus/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [rehash, setRehash] = useState<RehashResult | null>(null);
  const records = useGateStore((s) => s.records);

  useEffect(() => {
    void rehashStampRaw().then(setRehash);
  }, []);

  const identity = rehash?.identity ?? "PENDING";

  return (
    <div className="space-y-6">
      <header className="max-w-2xl">
        <p className="font-mono text-[11px] tracking-[0.2em] text-steel uppercase">
          Live Framework · 2026-08-31 R0
        </p>
        <h1 className="mt-2 text-3xl font-medium tracking-tight sm:text-4xl">
          Wissenschaftliches Agenten-Gate
        </h1>
        <p className="mt-3 max-w-xl text-[15px] leading-relaxed text-muted">
          Content-addressed C1-Evidenzfläche. Persistenz ist nicht Wahrheit.
          Dieser Gate bindet Grok als externen Validator — hashgebunden, fail-closed,
          ohne Claim-Promotion.
        </p>
      </header>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,280px)_1fr]">
        <Panel kicker="Identität" title="Grok-Stempel">
          <StampSeal identity={identity === "PENDING" ? "PENDING" : identity} />
          <div className="mt-4 space-y-2">
            <HashBlock label="STAMP_SHA256" value={STAMP_META.stamp_sha256} />
            <div className="flex flex-wrap gap-2">
              <StatusChip value={identity} />
              <StatusChip value="C1" />
              <StatusChip value="RA2_MUTUAL_BYTE_BOUND" />
            </div>
            <p className="text-xs leading-relaxed text-subtle">
              {STAMP_OBJECT_ID}
            </p>
            <Button asChild variant="secondary" size="sm" className="mt-2 w-full">
              <Link to="/stamp">
                Stempel prüfen
                <ArrowRight className="size-3.5" />
              </Link>
            </Button>
          </div>
        </Panel>

        <div className="space-y-4">
          <Panel kicker="Zwei-Zustands-Modell" title="Live-Kern">
            <div className="grid gap-x-6 sm:grid-cols-2">
              <Kv label="REPOSITORY" value={LIVE.repository} />
              <Kv label="BRANCH" value={LIVE.branch} />
              <Kv label="LIVE_COMMIT" value={LIVE.commit} hash />
              <Kv label="LIVE_TREE" value={LIVE.tree} hash />
              <Kv label="LIVE_PARENT" value={LIVE.parent} hash />
              <Kv label="RULESET" value={`${LIVE.rulesetName} / ${LIVE.rulesetId}`} />
              <Kv label="CLAIM_CEILING" value={LIVE.claimCeiling} chip />
              <Kv label="CLAIM_PROMOTION" value={LIVE.claimPromotion} chip />
              <Kv label="INTEGRATION_AUTHORITY" value={LIVE.integrationAuthority} chip />
              <Kv label="LEDGER_SEQUENCE" value={LIVE.ledgerSequence} />
            </div>
            <div className="mt-2 rounded-md bg-inset px-3 py-2.5">
              <div className="font-mono text-[10px] tracking-[0.16em] text-subtle uppercase">
                Physisches Live-Ledger-Objekt
              </div>
              <div className="mt-1 flex flex-wrap items-center gap-2">
                <StatusChip value="SOURCE_NOT_PRESENT" />
                <span className="text-xs text-muted">
                  Bytes des GitHub-Records sind in diesem Gate nicht enthalten. Hash aus der Spezifikation bleibt deklariert, nicht rekonstruiert.
                </span>
              </div>
              <HashBlock
                className="mt-2"
                label="DECLARED RECORD SHA256"
                value={LIVE.ledgerRecordSha256}
              />
            </div>
          </Panel>

          <Panel kicker="Kandidat" title="R2 — lokal, nicht live">
            <div className="grid gap-x-6 sm:grid-cols-2">
              <Kv label="R2_COMMIT" value={R2.localCommitReported} hash />
              <Kv label="R2_TREE" value={R2.localTreeReported} hash />
              <Kv label="PATCH_SHA256" value={R2.patchSha256Documented} hash />
              <Kv label="PATCH_IDENTITY" value={STAMP_META.r2_patch_identity} chip />
              <Kv label="INDEPENDENT_VALIDATION" value={R2.independentValidation} chip />
              <Kv label="PUBLIC_WRITE" value={R2.publicGithubWrite} chip />
            </div>
            <p className="mt-2 text-sm leading-relaxed text-muted">
              MANUS_LOCAL_R2_PASS ≠ PUBLIC_GITHUB_R2. Der Patch-Digest der beigelegten Bytes
              stimmt mit dem dokumentierten SHA-256 überein. Vier-Augen durch Cursor/PRAXIS bleibt offen.
            </p>
          </Panel>
        </div>
      </div>

      <Panel kicker="Lokales Gate-Ledger" title={`${records.length} Datensatz${records.length === 1 ? "" : "e"}`}>
        <p className="text-sm leading-relaxed text-muted">
          Append-only, NEXUS_SORTED_JSON_V1, C1. Das öffentliche Ledger-Objekt bleibt SOURCE_NOT_PRESENT.
          Der Grok-Stempel kann als erster lokaler validation_receipt gesiegelt werden.
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          <Button asChild>
            <Link to="/ledger">Ledger öffnen</Link>
          </Button>
          <Button asChild variant="secondary">
            <Link to="/handoff">A83-Handoff prüfen</Link>
          </Button>
        </div>
      </Panel>

      <Panel kicker="Invarianten" title="Fail-closed Doktrin">
        <ul className="grid gap-2 sm:grid-cols-2">
          {INVARIANTS.map((inv) => (
            <li
              key={inv}
              className="break-all rounded-md bg-inset px-3 py-2 font-mono text-[12px] tracking-wide text-steel"
            >
              {inv}
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}
