import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Panel } from "@/components/gate/panel";
import { StatusChip } from "@/components/gate/status-chip";
import { HashBlock } from "@/components/gate/hash-block";
import {
  BOOTSTRAP_STEPS,
  EVIDENCE_HIERARCHY,
  EVOLUTION_GATES,
  HARD_FAILS,
  LIMITATIONS,
  RESEARCH_PROGRAMS,
  ROLES,
} from "@/lib/nexus/constants";
import {
  DERIVED_FIXTURES,
  FIXTURE_CORPUS_CLASS,
  baseForFixture,
} from "@/lib/nexus/fixtures";
import { decisionFunction, validateEnvelopeAsync } from "@/lib/nexus/a83";
import { sha256Bytes } from "@/lib/nexus/canonical";
import { SOURCE_MANIFEST } from "@/lib/nexus/stamp";
import { useGateStore } from "@/lib/nexus/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/doctrine")({ component: DoctrinePage });

type Tab = "protocol" | "limits" | "fixtures" | "sources";

function DoctrinePage() {
  const [tab, setTab] = useState<Tab>("protocol");
  return (
    <div className="space-y-6">
      <header>
        <p className="font-mono text-[11px] tracking-[0.2em] text-steel uppercase">Doktrin</p>
        <h1 className="mt-2 text-3xl font-medium tracking-tight">Protokoll & Register</h1>
        <p className="mt-3 max-w-2xl text-[15px] leading-relaxed text-muted">
          Rollen, Evidenzhierarchie, Evolution Gates, Limitationen und ein abgeleitetes
          Negativ-Korpus. Das originale 43er-Kommunikationskorpus ist SOURCE_NOT_PRESENT.
        </p>
      </header>

      <div className="flex gap-1 overflow-x-auto">
        {(
          [
            ["protocol", "Protokoll"],
            ["limits", "Limiten"],
            ["fixtures", "Fixtures"],
            ["sources", "Quellen"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={cn(
              "h-11 shrink-0 rounded-md px-4 text-sm",
              tab === id ? "bg-raised text-fg" : "text-muted hover:text-fg",
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "protocol" ? <Protocol /> : null}
      {tab === "limits" ? <Limits /> : null}
      {tab === "fixtures" ? <Fixtures /> : null}
      {tab === "sources" ? <Sources /> : null}
    </div>
  );
}

function Protocol() {
  const checked = useGateStore((s) => s.bootstrapChecked);
  const toggle = useGateStore((s) => s.toggleBootstrap);
  return (
    <div className="space-y-4">
      <Panel kicker="Session" title="Bootstrap-Protokoll">
        <ol className="space-y-1">
          {BOOTSTRAP_STEPS.map((step, i) => (
            <li key={step}>
              <button
                type="button"
                onClick={() => toggle(i)}
                className="flex w-full items-start gap-3 rounded-md px-2 py-2 text-left hover:bg-raised"
              >
                <span
                  className={cn(
                    "mt-0.5 inline-flex size-5 shrink-0 items-center justify-center rounded-xs font-mono text-[10px]",
                    checked[i] ? "bg-sage/20 text-sage" : "bg-inset text-subtle",
                  )}
                >
                  {i + 1}
                </span>
                <span className="font-mono text-[13px] text-fg">{step}</span>
              </button>
            </li>
          ))}
        </ol>
      </Panel>

      <Panel kicker="Autorität" title="Rollen — nicht transitiv">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead className="font-mono text-[10px] tracking-[0.14em] text-subtle uppercase">
              <tr>
                <th className="py-2 pr-3 font-medium">Akteur</th>
                <th className="py-2 pr-3 font-medium">Funktion</th>
                <th className="py-2 pr-3 font-medium">Mutation</th>
                <th className="py-2 font-medium">Promotion</th>
              </tr>
            </thead>
            <tbody>
              {ROLES.map((r) => (
                <tr key={r.id} className="border-t border-line">
                  <td className="py-3 pr-3 font-medium">{r.name}</td>
                  <td className="py-3 pr-3 text-muted">{r.function}</td>
                  <td className="py-3 pr-3 text-muted">{r.mutate}</td>
                  <td className="py-3 text-muted">{r.promote}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 font-mono text-[12px] text-steel">ROLE_LABEL ≠ CORRECTNESS</p>
      </Panel>

      <Panel kicker="E0–E5" title="Evidenzhierarchie">
        <ol className="space-y-3">
          {EVIDENCE_HIERARCHY.map((e) => (
            <li key={e.id} className="flex gap-3">
              <span className="font-mono text-[12px] text-steel">{e.id}</span>
              <div>
                <div className="text-sm text-fg">{e.label}</div>
                <div className="text-xs text-muted">{e.note}</div>
              </div>
            </li>
          ))}
        </ol>
      </Panel>

      <Panel kicker="G0–G8" title="Evolution Gates">
        <div className="grid gap-2 sm:grid-cols-2">
          {EVOLUTION_GATES.map((g) => (
            <div key={g.id} className="rounded-md bg-inset px-3 py-2.5">
              <div className="font-mono text-[11px] text-steel">
                {g.id} · {g.label}
              </div>
              <div className="mt-1 text-xs text-muted">{g.detail}</div>
            </div>
          ))}
        </div>
        <p className="mt-3 text-sm text-muted">Kein höheres Gate wird aus einem niedrigeren geschlossen.</p>
      </Panel>
    </div>
  );
}

function Limits() {
  return (
    <div className="space-y-4">
      <Panel kicker="LIM-01–14" title="Offene Limitationen">
        <ul className="divide-y divide-line">
          {LIMITATIONS.map((l) => (
            <li key={l.id} className="flex gap-3 py-3">
              <span className="font-mono text-[12px] text-amber">{l.id}</span>
              <span className="text-sm text-fg">{l.text}</span>
            </li>
          ))}
        </ul>
      </Panel>
      <Panel kicker="Hard fail" title="Materiale Fehlschläge">
        <ul className="grid gap-2 sm:grid-cols-2">
          {HARD_FAILS.map((h) => (
            <li key={h} className="rounded-md bg-inset px-3 py-2 font-mono text-[12px] text-rust">
              {h}
            </li>
          ))}
        </ul>
      </Panel>
      <Panel kicker="R1–R12" title="Forschungsprogramme">
        <ul className="grid gap-2 sm:grid-cols-2">
          {RESEARCH_PROGRAMS.map((r) => (
            <li key={r.id} className="rounded-md bg-inset px-3 py-2">
              <span className="font-mono text-[11px] text-steel">{r.id}</span>
              <div className="text-sm text-fg">{r.text}</div>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}

function Fixtures() {
  const [results, setResults] = useState<
    Array<{ id: string; expected: string; hit: boolean; verdict: string; errors: string[] }>
  >([]);
  const [busy, setBusy] = useState(false);

  async function run() {
    setBusy(true);
    const out = [];
    for (const fx of DERIVED_FIXTURES) {
      let env = fx.mutate(baseForFixture());
      if (fx.payloadRaw && fx.expected.startsWith("A83_SENTINEL_")) {
        env = {
          ...env,
          payload_bytes: fx.payloadRaw.byteLength,
          payload_sha256: await sha256Bytes(fx.payloadRaw),
        };
      }
      const errs = await validateEnvelopeAsync(env, {
        payloadRaw: fx.payloadRaw ?? null,
        ledgerRecordHashes: fx.withLedger ? new Set() : null,
      });
      out.push({
        id: fx.id,
        expected: fx.expected,
        hit: errs.includes(fx.expected),
        verdict: decisionFunction(errs),
        errors: errs,
      });
    }
    setResults(out);
    setBusy(false);
  }

  const pass = results.filter((r) => r.hit).length;

  return (
    <div className="space-y-4">
      <Panel
        kicker="Fail-closed"
        title="Abgeleitetes A83-Negativkorpus"
        action={
          <Button size="sm" onClick={() => void run()} disabled={busy}>
            Korpus laufen
          </Button>
        }
      >
        <p className="text-sm text-muted">
          {FIXTURE_CORPUS_CLASS}. Nicht das Live-43-Korpus. Jede Fixture muss fail-closed schließen.
        </p>
        {results.length ? (
          <div className="mt-3 flex items-center gap-2">
            <StatusChip value={pass === results.length ? "PASS" : "FAIL_CLOSED"} />
            <span className="font-mono text-sm tabular-nums text-muted">
              {pass}/{results.length}
            </span>
          </div>
        ) : null}
      </Panel>
      <div className="divide-y divide-line rounded-xl bg-surface shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-fg)_10%,transparent)]">
        {DERIVED_FIXTURES.map((fx) => {
          const r = results.find((x) => x.id === fx.id);
          return (
            <div key={fx.id} className="flex flex-col gap-1 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <div className="font-mono text-[11px] text-steel">
                  {fx.id} · {fx.expected}
                </div>
                <div className="text-sm text-fg">{fx.title}</div>
              </div>
              {r ? <StatusChip value={r.hit ? "PASS" : "MISMATCH"} /> : <StatusChip value="HOLD" />}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function Sources() {
  return (
    <div className="space-y-4">
      <Panel kicker="Package" title="Beigelegtes Archiv">
        <Kvish label="FILENAME" value={SOURCE_MANIFEST.package.filename} />
        <Kvish label="BYTES" value={String(SOURCE_MANIFEST.package.bytes)} />
        <HashBlock label="PACKAGE SHA256" value={SOURCE_MANIFEST.package.sha256} />
        <p className="mt-3 text-sm text-muted">
          Locator: {SOURCE_MANIFEST.package.locator}. Abrufbare Kopien unter /evidence/.
        </p>
      </Panel>
      <Panel kicker="Bindings" title="Physische Inputs">
        <ul className="divide-y divide-line">
          {SOURCE_MANIFEST.bindings.map((b) => (
            <li key={b.filename} className="py-3">
              <a href={b.locator} className="text-sm text-fg hover:text-steel" target="_blank" rel="noreferrer">
                {b.filename}
              </a>
              <div className="font-mono text-[11px] text-subtle">
                {b.bytes} B · {b.source_filename}
              </div>
              <HashBlock value={b.sha256} />
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}

function Kvish({ label, value }: { label: string; value: string }) {
  return (
    <div className="py-1.5">
      <div className="font-mono text-[10px] tracking-[0.16em] text-subtle uppercase">{label}</div>
      <div className="font-mono text-[13px] text-fg">{value}</div>
    </div>
  );
}
