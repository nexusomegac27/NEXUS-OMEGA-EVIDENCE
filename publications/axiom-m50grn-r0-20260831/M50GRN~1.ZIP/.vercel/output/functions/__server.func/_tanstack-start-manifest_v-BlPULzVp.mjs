//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BlPULzVp.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/doctrine",
			"/handoff",
			"/ledger",
			"/stamp"
		],
		preloads: ["/assets/index-CBncAzq_.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CBncAzq_.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BobNhnpR.js",
			"/assets/store-CZVjWsNA.js",
			"/assets/stamp-seal-eLh3-vGm.js",
			"/assets/kv-BA2OcD5v.js"
		]
	},
	"/doctrine": {
		filePath: "/workspace/src/routes/doctrine.tsx",
		children: void 0,
		preloads: [
			"/assets/doctrine-CfZDje72.js",
			"/assets/store-CZVjWsNA.js",
			"/assets/a83-DrUSoTIS.js"
		]
	},
	"/handoff": {
		filePath: "/workspace/src/routes/handoff.tsx",
		children: void 0,
		preloads: [
			"/assets/handoff-Zy3j50ib.js",
			"/assets/store-CZVjWsNA.js",
			"/assets/a83-DrUSoTIS.js",
			"/assets/textarea-inLpMp9G.js"
		]
	},
	"/ledger": {
		filePath: "/workspace/src/routes/ledger.tsx",
		children: void 0,
		preloads: [
			"/assets/ledger-Q9esjBVj.js",
			"/assets/store-CZVjWsNA.js",
			"/assets/textarea-inLpMp9G.js",
			"/assets/kv-BA2OcD5v.js"
		]
	},
	"/stamp": {
		filePath: "/workspace/src/routes/stamp.tsx",
		children: void 0,
		preloads: [
			"/assets/stamp-BHe4qRII.js",
			"/assets/store-CZVjWsNA.js",
			"/assets/stamp-seal-eLh3-vGm.js",
			"/assets/kv-BA2OcD5v.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
