import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as RefreshCw, o as Fingerprint, s as Download } from "../_libs/lucide-react.mjs";
import { A as rehashPhysicalUrl, C as STAMP_OBJECT_ID, P as useGateStore, S as STAMP_OBJECT, T as StatusChip, c as HashBlock, i as Button, j as rehashStampRaw, k as rehashIdentityBlock, l as IDENTITY_BLOCK, m as Panel, w as STAMP_RAW, x as STAMP_META, y as SOURCE_MANIFEST } from "./store-CkzlrWW2.mjs";
import { t as Kv } from "./kv-DizFxdeC.mjs";
import { t as StampSeal } from "./stamp-seal-ZYeSUz2Z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/stamp-B-CqqXFw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StampPage() {
	const [stamp, setStamp] = (0, import_react.useState)(null);
	const [identity, setIdentity] = (0, import_react.useState)(null);
	const [physical, setPhysical] = (0, import_react.useState)(null);
	const [sources, setSources] = (0, import_react.useState)(SOURCE_MANIFEST.bindings.map((b) => ({
		filename: b.filename,
		declared: b.sha256,
		declaredBytes: b.bytes,
		status: "PENDING"
	})));
	const [busy, setBusy] = (0, import_react.useState)(false);
	const sealStamp = useGateStore((s) => s.sealStamp);
	const appending = useGateStore((s) => s.appending);
	const appendError = useGateStore((s) => s.appendError);
	const sealed = useGateStore((s) => s.records).some((r) => r.entry.record_id === "validation_receipt:grok-stamp:20260831-r0");
	async function runRehash() {
		setBusy(true);
		try {
			const [s, i] = await Promise.all([rehashStampRaw(), rehashIdentityBlock()]);
			setStamp(s);
			setIdentity(i);
			try {
				const phys = await rehashPhysicalUrl("/evidence/GROK-VALIDATION-STAMP-20260831-R0.json");
				setPhysical({
					declared: STAMP_META.stamp_sha256,
					computed: phys.sha256,
					bytes: phys.bytes,
					declaredBytes: STAMP_META.stamp_bytes,
					identity: phys.sha256 === STAMP_META.stamp_sha256 ? "MATCH" : "MISMATCH",
					bytesIdentity: phys.bytes === STAMP_META.stamp_bytes ? "MATCH" : "MISMATCH"
				});
			} catch {
				setPhysical({
					declared: STAMP_META.stamp_sha256,
					computed: "",
					bytes: 0,
					declaredBytes: STAMP_META.stamp_bytes,
					identity: "MISMATCH",
					bytesIdentity: "MISMATCH"
				});
			}
		} finally {
			setBusy(false);
		}
	}
	async function rehashSources() {
		setBusy(true);
		const next = [];
		for (const b of SOURCE_MANIFEST.bindings) try {
			const phy = await rehashPhysicalUrl(b.locator);
			next.push({
				filename: b.filename,
				declared: b.sha256,
				declaredBytes: b.bytes,
				computed: phy.sha256,
				bytes: phy.bytes,
				status: phy.sha256 === b.sha256 && phy.bytes === b.bytes ? "MATCH" : "MISMATCH"
			});
		} catch {
			next.push({
				filename: b.filename,
				declared: b.sha256,
				declaredBytes: b.bytes,
				status: "SOURCE_NOT_PRESENT"
			});
		}
		setSources(next);
		setBusy(false);
	}
	(0, import_react.useEffect)(() => {
		runRehash();
	}, []);
	function downloadStamp() {
		const blob = new Blob([STAMP_RAW], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = "GROK-VALIDATION-STAMP-20260831-R0.json";
		a.click();
		URL.revokeObjectURL(url);
	}
	const face = stamp?.identity ?? "PENDING";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[11px] tracking-[0.2em] text-steel uppercase",
					children: "Hashgebundener Validierungsstempel"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 text-3xl font-medium tracking-tight",
					children: "Grok · xAI"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-2xl text-[15px] leading-relaxed text-muted",
					children: "Externe Agenten-Identität, bytegebunden über NEXUS_SORTED_JSON_V1. Die Modellbezeichnung ist asserted, nicht kryptographisch verifiziert. Der Digest beweist Byteidentität — nicht wissenschaftliche Wahrheit."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-[minmax(0,280px)_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StampSeal, { identity: face === "PENDING" ? "PENDING" : face }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => void runRehash(),
							variant: "secondary",
							disabled: busy,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4" }), "Neu hashen"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: downloadStamp,
							variant: "secondary",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Stempel-JSON"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => void sealStamp(),
							disabled: appending || sealed,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fingerprint, { className: "size-4" }), sealed ? "Im Ledger gesiegelt" : "In lokales Ledger siegeln"]
						}),
						appendError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-rust",
							children: appendError
						}) : null
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					kicker: "Bindung",
					title: "Unabhängiger Rehash",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-x-6 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "OBJECT_ID",
									value: STAMP_OBJECT_ID
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "DATE_UTC",
									value: String(STAMP_OBJECT.date_utc)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "PRODUCER",
									value: String(STAMP_OBJECT.producer_asserted_identity)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "VERIFIED_IDENTITY",
									value: STAMP_OBJECT.producer_verified_identity,
									chip: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "ROLE",
									value: String(STAMP_OBJECT.from_role)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "ACTOR_ROLE",
									value: String(STAMP_OBJECT.actor_role)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "CLAIM_CEILING",
									value: "C1",
									chip: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "CLAIM_PROMOTION",
									value: false,
									chip: true
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 space-y-3 rounded-md bg-inset p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									result: stamp,
									label: "Kanonisches Stempel-Objekt (Import)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									result: physical,
									label: "Physische Datei /evidence/…json"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									result: identity,
									label: "Identitätsblock GROK BUILD / xAI"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashBlock, {
							className: "mt-4",
							label: "IDENTITY_BINDING_SHA256",
							value: STAMP_META.identity_binding_sha256
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				kicker: "Physische Inputs",
				title: "Quellen-Rehash",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "secondary",
					onClick: () => void rehashSources(),
					disabled: busy,
					children: "Quellen prüfen"
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-4 text-sm text-muted",
					children: "Jede Datei wird als physische Bytes geladen und gegen das Source-Manifest gehalten. Keine Rekonstruktion fehlender Originale."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y divide-line",
					children: sources.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-1 py-3 sm:flex-row sm:items-center sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate text-sm text-fg",
								children: s.filename
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-mono text-[11px] text-subtle tabular-nums",
								children: [
									s.declaredBytes,
									" B · ",
									s.declared.slice(0, 12),
									"…"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, { value: s.status })]
					}, s.filename))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				kicker: "Identitätsblock",
				title: "NEXUS_SORTED_JSON_V1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "overflow-x-auto rounded-md bg-inset p-4 font-mono text-[12px] leading-relaxed text-steel",
					children: JSON.stringify(IDENTITY_BLOCK, null, 2)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				kicker: "Ausgeführt / Nicht ausgeführt",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-mono text-[10px] tracking-[0.16em] text-subtle uppercase",
						children: "Work executed"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 space-y-1.5",
						children: STAMP_OBJECT.work_executed.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "font-mono text-[12px] text-sage",
							children: w
						}, w))
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-mono text-[10px] tracking-[0.16em] text-subtle uppercase",
						children: "Work not executed"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 space-y-1.5",
						children: STAMP_OBJECT.work_not_executed.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "font-mono text-[12px] text-muted",
							children: w
						}, w))
					})] })]
				})
			})
		]
	});
}
function Row({ result, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm text-fg",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap items-center gap-2",
			children: result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, { value: result.identity }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-mono text-[11px] text-subtle tabular-nums",
				children: [result.bytes, " B"]
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, { value: "PENDING" })
		})]
	});
}
//#endregion
export { StampPage as component };
