import "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as cn } from "./router-CUOx3VDb.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("flex h-11 w-full rounded-md bg-inset px-3 text-sm text-fg", "shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-fg)_10%,transparent)]", "placeholder:text-subtle", "focus-visible:outline-none focus-visible:shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-steel)_55%,transparent)]", "disabled:opacity-40", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-32 w-full rounded-md bg-inset px-3 py-2.5 text-sm text-fg font-mono leading-relaxed", "shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-fg)_10%,transparent)]", "placeholder:text-subtle placeholder:font-sans", "focus-visible:outline-none focus-visible:shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-steel)_55%,transparent)]", className),
		...props
	});
}
//#endregion
export { Textarea as n, Input as t };
