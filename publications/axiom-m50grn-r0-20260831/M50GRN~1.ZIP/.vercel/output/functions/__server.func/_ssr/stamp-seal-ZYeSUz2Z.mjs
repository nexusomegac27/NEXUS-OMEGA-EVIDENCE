import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as cn } from "./router-CUOx3VDb.mjs";
import { C as STAMP_OBJECT_ID, N as truncateHash, x as STAMP_META } from "./store-CkzlrWW2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/stamp-seal-ZYeSUz2Z.js
var import_jsx_runtime = require_jsx_runtime();
function StampSeal({ className, identity = "MATCH" }) {
	const hash = STAMP_META.stamp_sha256;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative mx-auto aspect-square w-full max-w-[280px]", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 320 320",
			className: "h-full w-full",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "160",
					cy: "160",
					r: "154",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "1.2",
					className: "text-line-strong"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "160",
					cy: "160",
					r: "138",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "0.8",
					className: "text-line"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "160",
					cy: "160",
					r: "118",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "1.4",
					className: "text-steel/70"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "160",
					cy: "160",
					r: "72",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "0.8",
					className: "text-line-strong"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					id: "seal-ring",
					d: "M160,160 m-128,0 a128,128 0 1,1 256,0 a128,128 0 1,1 -256,0"
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					fill: "currentColor",
					className: "text-steel",
					style: {
						fontFamily: "IBM Plex Mono, ui-monospace, monospace",
						fontSize: 11,
						letterSpacing: 3.2
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textPath", {
						href: "#seal-ring",
						startOffset: "0%",
						children: "NEXUS OMEGA · HASH-BOUND · C1 · FAIL-CLOSED · GROK BUILD · xAI ·"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "160",
					y: "128",
					textAnchor: "middle",
					fill: "currentColor",
					className: "text-fg",
					style: {
						fontFamily: "IBM Plex Sans, sans-serif",
						fontSize: 11,
						letterSpacing: 4
					},
					children: "GROK BUILD"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "160",
					y: "152",
					textAnchor: "middle",
					fill: "currentColor",
					className: "text-steel",
					style: {
						fontFamily: "IBM Plex Sans, sans-serif",
						fontSize: 28,
						fontWeight: 500
					},
					children: "Ω"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "160",
					y: "178",
					textAnchor: "middle",
					fill: "currentColor",
					className: "text-muted",
					style: {
						fontFamily: "IBM Plex Mono, ui-monospace, monospace",
						fontSize: 9,
						letterSpacing: 1.4
					},
					children: truncateHash(hash, 6)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "160",
					y: "198",
					textAnchor: "middle",
					fill: "currentColor",
					className: identity === "MATCH" ? "text-sage" : identity === "MISMATCH" ? "text-rust" : "text-amber",
					style: {
						fontFamily: "IBM Plex Mono, ui-monospace, monospace",
						fontSize: 10,
						letterSpacing: 2.4
					},
					children: identity
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "sr-only",
			children: [
				"Hashgebundener Validierungsstempel ",
				STAMP_OBJECT_ID,
				", SHA-256 ",
				hash,
				", Zustand ",
				identity
			]
		})]
	});
}
//#endregion
export { StampSeal as t };
