import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as cn } from "./router-CUOx3VDb.mjs";
import { M as sha256Bytes, P as useGateStore, T as StatusChip, _ as RESEARCH_PROGRAMS, a as EVIDENCE_HIERARCHY, c as HashBlock, d as LIMITATIONS, i as Button, m as Panel, o as EVOLUTION_GATES, r as BOOTSTRAP_STEPS, s as HARD_FAILS, v as ROLES, y as SOURCE_MANIFEST } from "./store-CkzlrWW2.mjs";
import { i as validateEnvelopeAsync, n as decisionFunction, r as emptyEnvelope } from "./a83-BQafLP0x.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/doctrine-CdDOwLut.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function clone() {
	return { ...emptyEnvelope() };
}
var DERIVED_FIXTURES = [
	{
		id: "FX-01",
		title: "Anspruchdecke über C1",
		expected: "A83_CLAIM_CEILING",
		mutate: (env) => ({
			...env,
			claim_ceiling: "C2"
		})
	},
	{
		id: "FX-02",
		title: "Claim-Promotion-Pfad",
		expected: "A83_CLAIM_PROMOTION",
		mutate: (env) => ({
			...env,
			claim_promotion: true
		})
	},
	{
		id: "FX-03",
		title: "Integrationsautorität ungleich NONE",
		expected: "A83_INTEGRATION_AUTHORITY",
		mutate: (env) => ({
			...env,
			integration_authority: "MERGE"
		})
	},
	{
		id: "FX-04",
		title: "Auto-Execute verboten",
		expected: "A83_AUTO_EXECUTE_PROHIBITED",
		mutate: (env) => ({
			...env,
			auto_execute: true
		})
	},
	{
		id: "FX-05",
		title: "Netzwerk-Write verboten",
		expected: "A83_NETWORK_WRITE_PROHIBITED",
		mutate: (env) => ({
			...env,
			network_write: true
		})
	},
	{
		id: "FX-06",
		title: "Sunset unter 12 Monaten",
		expected: "A83_SUNSET_LT_12_MONTHS",
		mutate: (env) => ({
			...env,
			sunset_months: 6
		})
	},
	{
		id: "FX-07",
		title: "Identitätsfusion Produzent = Validator",
		expected: "A83_IDENTITY_FUSION",
		mutate: (env) => ({
			...env,
			sender_role: "AXIOM",
			recipient_role: "AXIOM",
			actor_role: "VALIDATOR"
		})
	},
	{
		id: "FX-08",
		title: "OBS0 mit hoher Receipt-Assurance",
		expected: "A83_ASSURANCE_OBSERVABILITY_CONFLICT",
		mutate: (env) => ({
			...env,
			observability_class: "OBS0_UNOBSERVABLE",
			receipt_assurance: "RA4_SIGNED_OR_TIMESTAMPED"
		})
	},
	{
		id: "FX-09",
		title: "Parent-SHA256 formal ungültig",
		expected: "A83_PARENT_SHA256",
		mutate: (env) => ({
			...env,
			parent_record_sha256: "not-a-hash"
		})
	},
	{
		id: "FX-10",
		title: "Payload-SHA256 formal ungültig",
		expected: "A83_PAYLOAD_SHA256",
		mutate: (env) => ({
			...env,
			payload_sha256: "xyz"
		})
	},
	{
		id: "FX-11",
		title: "Payload-Bytes negativ",
		expected: "A83_PAYLOAD_BYTES",
		mutate: (env) => ({
			...env,
			payload_bytes: -1
		})
	},
	{
		id: "FX-12",
		title: "Zusätzliches Schema-Feld",
		expected: "A83_SCHEMA_KEYSET",
		mutate: (env) => ({
			...env,
			extra: true
		})
	},
	{
		id: "FX-13",
		title: "Fehlendes Pflichtfeld",
		expected: "A83_SCHEMA_KEYSET",
		mutate: (env) => {
			const next = { ...env };
			delete next.caveats;
			return next;
		}
	},
	{
		id: "FX-14",
		title: "Ungültige Rolle",
		expected: "A83_ROLE_INVALID",
		mutate: (env) => ({
			...env,
			sender_role: "ORACLE"
		})
	},
	{
		id: "FX-15",
		title: "Schema-Version fremd",
		expected: "A83_SCHEMA_VERSION",
		mutate: (env) => ({
			...env,
			schema_version: "2.0.0"
		})
	},
	{
		id: "FX-16",
		title: "Parent nicht im Ledger",
		expected: "A83_PARENT_NOT_IN_LEDGER",
		mutate: (env) => env,
		withLedger: true
	},
	{
		id: "FX-17",
		title: "Physische Payload-Länge weicht ab",
		expected: "A83_PAYLOAD_BYTES_MISMATCH",
		mutate: (env) => ({
			...env,
			payload_bytes: 4,
			payload_sha256: "a".repeat(64)
		}),
		payloadRaw: new TextEncoder().encode("hello")
	},
	{
		id: "FX-18",
		title: "Physische Payload-SHA256 weicht ab",
		expected: "A83_PAYLOAD_SHA256_MISMATCH",
		mutate: (env) => ({
			...env,
			payload_bytes: 5,
			payload_sha256: "b".repeat(64)
		}),
		payloadRaw: new TextEncoder().encode("hello")
	},
	{
		id: "FX-19",
		title: "Sentinel: Hash als Wahrheit",
		expected: "A83_SENTINEL_HASH_AS_TRUTH",
		mutate: (env) => env,
		payloadRaw: new TextEncoder().encode("This hash proves scientific truth of the claim.")
	},
	{
		id: "FX-20",
		title: "CRLF darf nicht als LF gebunden werden",
		expected: "A83_PAYLOAD_SHA256_MISMATCH",
		mutate: (env) => ({
			...env,
			payload_bytes: 12,
			payload_sha256: "c".repeat(64)
		}),
		payloadRaw: new Uint8Array([
			108,
			105,
			110,
			101,
			49,
			13,
			10,
			108,
			105,
			110,
			101,
			50
		])
	}
];
function baseForFixture() {
	return clone();
}
var FIXTURE_CORPUS_CLASS = "GATE_DERIVED_A83_NEGATIVE_FIXTURES_V1_NOT_THE_LIVE_43";
function DoctrinePage() {
	const [tab, setTab] = (0, import_react.useState)("protocol");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[11px] tracking-[0.2em] text-steel uppercase",
					children: "Doktrin"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 text-3xl font-medium tracking-tight",
					children: "Protokoll & Register"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-2xl text-[15px] leading-relaxed text-muted",
					children: "Rollen, Evidenzhierarchie, Evolution Gates, Limitationen und ein abgeleitetes Negativ-Korpus. Das originale 43er-Kommunikationskorpus ist SOURCE_NOT_PRESENT."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1 overflow-x-auto",
				children: [
					["protocol", "Protokoll"],
					["limits", "Limiten"],
					["fixtures", "Fixtures"],
					["sources", "Quellen"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTab(id),
					className: cn("h-11 shrink-0 rounded-md px-4 text-sm", tab === id ? "bg-raised text-fg" : "text-muted hover:text-fg"),
					children: label
				}, id))
			}),
			tab === "protocol" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Protocol, {}) : null,
			tab === "limits" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Limits, {}) : null,
			tab === "fixtures" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fixtures, {}) : null,
			tab === "sources" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sources, {}) : null
		]
	});
}
function Protocol() {
	const checked = useGateStore((s) => s.bootstrapChecked);
	const toggle = useGateStore((s) => s.toggleBootstrap);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				kicker: "Session",
				title: "Bootstrap-Protokoll",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "space-y-1",
					children: BOOTSTRAP_STEPS.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => toggle(i),
						className: "flex w-full items-start gap-3 rounded-md px-2 py-2 text-left hover:bg-raised",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("mt-0.5 inline-flex size-5 shrink-0 items-center justify-center rounded-xs font-mono text-[10px]", checked[i] ? "bg-sage/20 text-sage" : "bg-inset text-subtle"),
							children: i + 1
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-[13px] text-fg",
							children: step
						})]
					}) }, step))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				kicker: "Autorität",
				title: "Rollen — nicht transitiv",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[640px] text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "font-mono text-[10px] tracking-[0.14em] text-subtle uppercase",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 pr-3 font-medium",
									children: "Akteur"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 pr-3 font-medium",
									children: "Funktion"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 pr-3 font-medium",
									children: "Mutation"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-medium",
									children: "Promotion"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: ROLES.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-line",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 pr-3 font-medium",
									children: r.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 pr-3 text-muted",
									children: r.function
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 pr-3 text-muted",
									children: r.mutate
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 text-muted",
									children: r.promote
								})
							]
						}, r.id)) })]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 font-mono text-[12px] text-steel",
					children: "ROLE_LABEL ≠ CORRECTNESS"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				kicker: "E0–E5",
				title: "Evidenzhierarchie",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "space-y-3",
					children: EVIDENCE_HIERARCHY.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-[12px] text-steel",
							children: e.id
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm text-fg",
							children: e.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted",
							children: e.note
						})] })]
					}, e.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				kicker: "G0–G8",
				title: "Evolution Gates",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-2 sm:grid-cols-2",
					children: EVOLUTION_GATES.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md bg-inset px-3 py-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-mono text-[11px] text-steel",
							children: [
								g.id,
								" · ",
								g.label
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-xs text-muted",
							children: g.detail
						})]
					}, g.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "Kein höheres Gate wird aus einem niedrigeren geschlossen."
				})]
			})
		]
	});
}
function Limits() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				kicker: "LIM-01–14",
				title: "Offene Limitationen",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-line",
					children: LIMITATIONS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-[12px] text-amber",
							children: l.id
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-fg",
							children: l.text
						})]
					}, l.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				kicker: "Hard fail",
				title: "Materiale Fehlschläge",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2 sm:grid-cols-2",
					children: HARD_FAILS.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "rounded-md bg-inset px-3 py-2 font-mono text-[12px] text-rust",
						children: h
					}, h))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				kicker: "R1–R12",
				title: "Forschungsprogramme",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2 sm:grid-cols-2",
					children: RESEARCH_PROGRAMS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-md bg-inset px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-[11px] text-steel",
							children: r.id
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm text-fg",
							children: r.text
						})]
					}, r.id))
				})
			})
		]
	});
}
function Fixtures() {
	const [results, setResults] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function run() {
		setBusy(true);
		const out = [];
		for (const fx of DERIVED_FIXTURES) {
			let env = fx.mutate(baseForFixture());
			if (fx.payloadRaw && fx.expected.startsWith("A83_SENTINEL_")) env = {
				...env,
				payload_bytes: fx.payloadRaw.byteLength,
				payload_sha256: await sha256Bytes(fx.payloadRaw)
			};
			const errs = await validateEnvelopeAsync(env, {
				payloadRaw: fx.payloadRaw ?? null,
				ledgerRecordHashes: fx.withLedger ? /* @__PURE__ */ new Set() : null
			});
			out.push({
				id: fx.id,
				expected: fx.expected,
				hit: errs.includes(fx.expected),
				verdict: decisionFunction(errs),
				errors: errs
			});
		}
		setResults(out);
		setBusy(false);
	}
	const pass = results.filter((r) => r.hit).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "Fail-closed",
			title: "Abgeleitetes A83-Negativkorpus",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				onClick: () => void run(),
				disabled: busy,
				children: "Korpus laufen"
			}),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [FIXTURE_CORPUS_CLASS, ". Nicht das Live-43-Korpus. Jede Fixture muss fail-closed schließen."]
			}), results.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, { value: pass === results.length ? "PASS" : "FAIL_CLOSED" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-mono text-sm tabular-nums text-muted",
					children: [
						pass,
						"/",
						results.length
					]
				})]
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "divide-y divide-line rounded-xl bg-surface shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-fg)_10%,transparent)]",
			children: DERIVED_FIXTURES.map((fx) => {
				const r = results.find((x) => x.id === fx.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-1 px-4 py-3 sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "font-mono text-[11px] text-steel",
						children: [
							fx.id,
							" · ",
							fx.expected
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm text-fg",
						children: fx.title
					})] }), r ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, { value: r.hit ? "PASS" : "MISMATCH" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, { value: "HOLD" })]
				}, fx.id);
			})
		})]
	});
}
function Sources() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "Package",
			title: "Beigelegtes Archiv",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kvish, {
					label: "FILENAME",
					value: SOURCE_MANIFEST.package.filename
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kvish, {
					label: "BYTES",
					value: String(SOURCE_MANIFEST.package.bytes)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashBlock, {
					label: "PACKAGE SHA256",
					value: SOURCE_MANIFEST.package.sha256
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted",
					children: [
						"Locator: ",
						SOURCE_MANIFEST.package.locator,
						". Abrufbare Kopien unter /evidence/."
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			kicker: "Bindings",
			title: "Physische Inputs",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-line",
				children: SOURCE_MANIFEST.bindings.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: b.locator,
							className: "text-sm text-fg hover:text-steel",
							target: "_blank",
							rel: "noreferrer",
							children: b.filename
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-mono text-[11px] text-subtle",
							children: [
								b.bytes,
								" B · ",
								b.source_filename
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashBlock, { value: b.sha256 })
					]
				}, b.filename))
			})
		})]
	});
}
function Kvish({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-mono text-[10px] tracking-[0.16em] text-subtle uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-mono text-[13px] text-fg",
			children: value
		})]
	});
}
//#endregion
export { DoctrinePage as component };
