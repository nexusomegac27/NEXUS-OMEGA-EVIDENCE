import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as TRANSPORT, F as utf8Bytes, M as sha256Bytes, P as useGateStore, T as StatusChip, b as SR, c as HashBlock, g as RA, i as Button, m as Panel, n as ACTOR_ROLES, p as OBS, t as A83_ROLES } from "./store-CkzlrWW2.mjs";
import { i as validateEnvelopeAsync, n as decisionFunction, r as emptyEnvelope, t as A83_REQUIRED } from "./a83-BQafLP0x.mjs";
import { n as Textarea, t as Input } from "./textarea-C5v4QppQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/handoff-BdJmj5gU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HandoffPage() {
	const [env, setEnv] = (0, import_react.useState)(emptyEnvelope);
	const [payload, setPayload] = (0, import_react.useState)("C1 descriptive handoff. Hash identity is not scientific validity.");
	const [errors, setErrors] = (0, import_react.useState)(null);
	const [verdict, setVerdict] = (0, import_react.useState)(null);
	const [bound, setBound] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const records = useGateStore((s) => s.records);
	const ledgerHashes = (0, import_react.useMemo)(() => new Set(records.map((r) => r.entry.record_sha256)), [records]);
	function setField(key, value) {
		setEnv((e) => ({
			...e,
			[key]: value
		}));
		setErrors(null);
		setVerdict(null);
	}
	async function bindPayload(text) {
		const raw = utf8Bytes(text);
		const digest = await sha256Bytes(raw);
		setBound({
			bytes: raw.byteLength,
			sha256: digest
		});
		setEnv((e) => ({
			...e,
			payload_bytes: raw.byteLength,
			payload_sha256: digest
		}));
	}
	async function onPayloadChange(text) {
		setPayload(text);
		await bindPayload(text);
	}
	async function validate(rawOverride) {
		setBusy(true);
		try {
			const raw = rawOverride ?? utf8Bytes(payload);
			const digest = await sha256Bytes(raw);
			const next = {
				...env,
				payload_bytes: env.payload_bytes,
				payload_sha256: env.payload_sha256
			};
			const errs = await validateEnvelopeAsync(next, {
				payloadRaw: raw,
				ledgerRecordHashes: ledgerHashes.size ? ledgerHashes : null
			});
			setBound({
				bytes: raw.byteLength,
				sha256: digest
			});
			setErrors(errs);
			setVerdict(decisionFunction(errs));
		} finally {
			setBusy(false);
		}
	}
	async function probe(kind) {
		let raw = utf8Bytes(payload);
		if (kind === "crlf") raw = utf8Bytes(payload.replace(/\n/g, "\r\n"));
		if (kind === "bom") {
			const next = new Uint8Array(3 + raw.byteLength);
			next.set([
				239,
				187,
				191
			]);
			next.set(raw, 3);
			raw = next;
		}
		if (kind === "nul") {
			const next = new Uint8Array(raw.byteLength + 1);
			next.set(raw);
			next[raw.byteLength] = 0;
			raw = next;
		}
		if (kind === "extra") {
			const next = new Uint8Array(raw.byteLength + 1);
			next.set(raw);
			next[raw.byteLength] = 120;
			raw = next;
		}
		await validate(raw);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-[11px] tracking-[0.2em] text-steel uppercase",
				children: "A83"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-3xl font-medium tracking-tight",
				children: "Handoff-Gate"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-2xl text-[15px] leading-relaxed text-muted",
				children: "Strukturelle Handoff-Validierung mit physischer Payload-Bindung. Entscheidungshöhe: C1.1 Struktur only — keine wissenschaftliche Promotion. Live-Base ohne Bytebindung bleibt als LIM-02 registriert; dieses Gate prüft die Bytes."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				kicker: "Envelope",
				title: "A83 v1.0.0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "handoff_id",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: String(env.handoff_id),
								onChange: (e) => setField("handoff_id", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "object_id",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: String(env.object_id),
								onChange: (e) => setField("object_id", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "sender_role",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
								value: String(env.sender_role),
								onChange: (v) => setField("sender_role", v),
								options: A83_ROLES
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "recipient_role",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
								value: String(env.recipient_role),
								onChange: (v) => setField("recipient_role", v),
								options: A83_ROLES
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "actor_role",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
								value: String(env.actor_role),
								onChange: (v) => setField("actor_role", v),
								options: ACTOR_ROLES
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "observability_class",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
								value: String(env.observability_class),
								onChange: (v) => setField("observability_class", v),
								options: OBS
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "receipt_assurance",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
								value: String(env.receipt_assurance),
								onChange: (v) => setField("receipt_assurance", v),
								options: RA
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "scientific_relevance_class",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
								value: String(env.scientific_relevance_class),
								onChange: (v) => setField("scientific_relevance_class", v),
								options: SR
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "transport_class",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
								value: String(env.transport_class),
								onChange: (v) => setField("transport_class", v),
								options: TRANSPORT
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "sunset_months",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: String(env.sunset_months),
								onChange: (e) => setField("sunset_months", Number(e.target.value))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "parent_record_sha256",
							className: "sm:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								className: "font-mono text-xs",
								value: String(env.parent_record_sha256),
								onChange: (e) => setField("parent_record_sha256", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "caveats",
							className: "sm:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								className: "min-h-24 font-sans",
								value: String(env.caveats),
								onChange: (e) => setField("caveats", e.target.value)
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 font-mono text-[11px] text-subtle",
					children: [
						"Pflichtfelder: ",
						A83_REQUIRED.length,
						" · claim_ceiling=C1 · promotion=false · integration=NONE · auto_execute=false · network_write=false"
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						kicker: "Physische Payload",
						title: "Bytebindung",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: payload,
								onChange: (e) => void onPayloadChange(e.target.value),
								onFocus: () => {
									if (!bound) bindPayload(payload);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: () => void bindPayload(payload),
									variant: "secondary",
									children: "Payload binden"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: () => void validate(),
									disabled: busy,
									children: "Validieren"
								})]
							}),
							bound ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 space-y-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "font-mono text-[11px] text-muted",
										children: [bound.bytes, " Bytes"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashBlock, {
										label: "PHYSICAL SHA256",
										value: bound.sha256
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashBlock, {
										label: "ENVELOPE SHA256",
										value: String(env.payload_sha256)
									})
								]
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						kicker: "Adversarial",
						title: "Physische Sonden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-sm text-muted",
							children: "Dieselben Envelope-Felder, andere physische Bytes. Nur exaktes Hashen der Rohbytes trägt eine Bytebindungs-Behauptung."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "secondary",
									onClick: () => void probe("crlf"),
									children: "CRLF"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "secondary",
									onClick: () => void probe("bom"),
									children: "UTF-8 BOM"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "secondary",
									onClick: () => void probe("nul"),
									children: "NUL"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "secondary",
									onClick: () => void probe("extra"),
									children: "Extra-Byte"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						kicker: "Verdict",
						children: verdict ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, {
								value: verdict,
								className: "text-xs"
							}), errors && errors.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-sage",
								children: "Struktur validiert. Das ist nicht Claim-Promotion."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-1",
								children: errors?.map((err) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "font-mono text-[12px] text-rust",
									children: err
								}, err))
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Noch nicht geprüft."
						})
					})
				]
			})]
		})]
	});
}
function Field({ label, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-1.5 font-mono text-[10px] tracking-[0.14em] text-subtle uppercase",
			children: label
		}), children]
	});
}
function Select({ value, onChange, options }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		value,
		onChange: (e) => onChange(e.target.value),
		className: "flex h-11 w-full rounded-md bg-inset px-3 text-sm text-fg shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-fg)_10%,transparent)] focus-visible:outline-none",
		children: options.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: o,
			children: o
		}, o))
	});
}
//#endregion
export { HandoffPage as component };
