import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Copy, l as Check } from "../_libs/lucide-react.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as cn } from "./router-CUOx3VDb.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-CkzlrWW2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[opacity,transform,box-shadow,background-color,color] duration-150 ease-out disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-steel/50 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			primary: "bg-fg text-ink hover:opacity-90",
			secondary: "bg-raised text-fg hairline hairline-hover",
			ghost: "text-muted hover:text-fg hover:bg-raised",
			danger: "bg-rust/15 text-rust hover:bg-rust/25"
		},
		size: {
			sm: "h-9 rounded-sm px-3 text-sm",
			md: "h-11 rounded-md px-4 text-sm",
			lg: "h-12 rounded-lg px-5 text-base",
			icon: "size-11 rounded-md"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Panel({ title, kicker, action, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("rounded-xl bg-surface p-4 sm:p-5", "shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-fg)_10%,transparent)]", className),
		children: [(kicker || title || action) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-4 flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [kicker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-mono text-[10px] tracking-[0.18em] text-subtle uppercase",
					children: kicker
				}) : null, title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-lg font-medium tracking-tight text-fg",
					children: title
				}) : null]
			}), action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "shrink-0",
				children: action
			}) : null]
		}), children]
	});
}
var TONE = {
	MATCH: "text-sage bg-sage/10",
	PASS: "text-sage bg-sage/10",
	PASS_WITH_CAVEATS: "text-sage bg-sage/10",
	C1: "text-steel bg-steel/10",
	"C1.1_ARTIFACT_VALIDATED_STRUCTURE_ONLY": "text-sage bg-sage/10",
	LIVE: "text-steel bg-steel/10",
	MISMATCH: "text-rust bg-rust/10",
	HARD_FAIL: "text-rust bg-rust/10",
	FAIL_MAJOR: "text-rust bg-rust/10",
	"C1.2_CLOSED": "text-rust bg-rust/10",
	FAIL_CLOSED: "text-rust bg-rust/10",
	SOURCE_NOT_PRESENT: "text-amber bg-amber/10",
	NOT_ESTABLISHED: "text-amber bg-amber/10",
	NOT_COMPUTABLE: "text-amber bg-amber/10",
	PENDING: "text-amber bg-amber/10",
	HOLD: "text-amber bg-amber/10",
	OPERATOR_REPORTED: "text-amber bg-amber/10",
	FALSE: "text-muted bg-raised",
	NONE: "text-muted bg-raised",
	NO: "text-muted bg-raised"
};
function StatusChip({ value, className }) {
	const text = value === null ? "null" : typeof value === "boolean" ? value ? "TRUE" : "FALSE" : String(value);
	const tone = TONE[text] ?? "text-muted bg-raised";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex max-w-full items-center truncate rounded-sm px-2 py-0.5 font-mono text-[11px] tracking-wide", tone, className),
		children: text
	});
}
var encoder = new TextEncoder();
var INDEX_SERIALIZATION = "NEXUS_SORTED_JSON_V1";
function sortKeys(value) {
	if (Array.isArray(value)) return value.map(sortKeys);
	if (value !== null && typeof value === "object") {
		const obj = value;
		const out = {};
		for (const key of Object.keys(obj).sort()) {
			const next = obj[key];
			if (next === void 0) continue;
			out[key] = sortKeys(next);
		}
		return out;
	}
	return value;
}
/** Repository-defined deterministic JSON. Not RFC 8785 JCS. */
function nexusSortedJsonV1(value) {
	return JSON.stringify(sortKeys(value));
}
function utf8Bytes(text) {
	return encoder.encode(text);
}
function bytesToHex(bytes) {
	const view = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
	let hex = "";
	for (const b of view) hex += b.toString(16).padStart(2, "0");
	return hex;
}
async function sha256Bytes(data) {
	return bytesToHex(await crypto.subtle.digest("SHA-256", data));
}
async function sha256Utf8(text) {
	return sha256Bytes(utf8Bytes(text));
}
function truncateHash(hash, edge = 8) {
	if (hash.length <= edge * 2 + 1) return hash;
	return `${hash.slice(0, edge)}…${hash.slice(-edge)}`;
}
function isSha256(value) {
	return typeof value === "string" && /^[0-9a-f]{64}$/.test(value);
}
function HashBlock({ value, label, full = false, className }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [open, setOpen] = (0, import_react.useState)(full);
	async function copy() {
		try {
			await navigator.clipboard.writeText(value);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1200);
		} catch {}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("min-w-0", className),
		children: [label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-1 font-mono text-[10px] tracking-[0.16em] text-subtle uppercase",
			children: label
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setOpen((v) => !v),
				className: "min-w-0 flex-1 truncate text-left font-mono text-[12px] leading-relaxed text-steel tabular-nums",
				title: value,
				children: open ? value : truncateHash(value)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: copy,
				className: "inline-flex size-9 shrink-0 items-center justify-center rounded-sm text-muted hover:text-fg",
				"aria-label": "Hash kopieren",
				children: copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 text-sage" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" })
			})]
		})]
	});
}
var LIVE = {
	object: "NEXUS_OMEGA_GITHUB_PERSISTENT_COMMUNICATION_MEMORY_PROVENANCE_FRAMEWORK_LIVE_20260831_R0",
	state: "LIVE_CORE_ESTABLISHED_WITH_LOCAL_R2_CANDIDATE_EXTENSION_PENDING_FOUR_EYES",
	repository: "nexusomegac27/NEXUS-OMEGA-EVIDENCE",
	branch: "main",
	commit: "bc312c4d2cd6afa579db1f077c88d8fe08fc9470",
	tree: "c8856faa74efa5770717d2d44dc7d51e4269cb22",
	parent: "bb1f3fd88db79d295077062895574c6d90b390bf",
	commitSignature: "GITHUB_VERIFIED_VALID",
	rulesetId: "21252293",
	rulesetName: "main-evidence-protection",
	rulesetEnforcement: "active",
	ledgerSequence: 1,
	ledgerRecordSha256: "1cdfcc74319f6f8500d969e8345ce5b6e1e6298482e03b6c96881cbbbd99dece",
	ledgerHeadIndexLineSha256: "d4b9ea8838d393776608833257a43970c2249a3bcd8ecb65ec89d6d018d8660f",
	ledgerRecordId: "event:github-pr2-merge:20260830",
	ledgerRecordBytes: 973,
	claim: "C1_DESCRIPTIVE_ONLY",
	claimCeiling: "C1",
	claimPromotion: false,
	foundationPromotion: false,
	deploymentAuthority: false,
	integrationAuthority: "NONE",
	autoFollowOn: false
};
var R2 = {
	localCommitReported: "63698d562352bc8c62ba717c5022d0b0eb3da354",
	localTreeReported: "f76fdb5fb42a748c42bf6908981f10d14b723ddb",
	parent: LIVE.commit,
	patchSha256Documented: "14a53196e00e6716eb4321c12e4560e867b448a20a08d46d239813c0d17ded36",
	stateReported: "PASS_LOCAL_R2_REMEDIATION_WITH_CAVEATS_C1",
	publicGithubWrite: false,
	independentValidation: "NOT_ESTABLISHED",
	publication: "NOT_AUTHORIZED_BY_THIS_FRAMEWORK"
};
var INVARIANTS = [
	"PERSISTENCE != TRUTH",
	"HASH_IDENTITY != SEMANTIC_VALIDITY",
	"SIGNATURE != SCIENTIFIC_VALIDITY",
	"CI_PASS != CLAIM_PROMOTION",
	"AGENT_AGREEMENT != EVIDENCE",
	"PUBLICATION != AUTHORITY",
	"ROLE_LABEL != CORRECTNESS",
	"PRODUCER_RETURN != INDEPENDENT_VALIDATION",
	"VALIDATOR_PASS != CLAIM_PROMOTION",
	"IDENTITY_MATCH != CONTENT_VALIDATION",
	"FORMAL_MODEL_FIT != OPERATIONAL_VALIDATION",
	"VALIDATION != PROMOTION",
	"BLOCKED_LANE != BLOCKED_SYSTEM",
	"CONCURRENT_SERIALIZATION != CRASH_ATOMICITY",
	"GIT_BLOB_ID != CONTENT_SHA256"
];
var EVIDENCE_HIERARCHY = [
	{
		id: "E0",
		label: "Verifizierte physische / abrufbare Bytes",
		note: "Höchste Stufe. Chat darf nur lokalisieren, nie ersetzen."
	},
	{
		id: "E1",
		label: "Unveränderliches öffentliches Git-Objekt",
		note: "Content-addressed. Identität, nicht Wahrheit."
	},
	{
		id: "E2",
		label: "Unabhängige bytegebundene Quittung / Zeuge",
		note: "Getrennte Validierungsdomäne."
	},
	{
		id: "E3",
		label: "Repository-Handoff / Statusobjekt",
		note: "Nur mit expliziter epistemischer Klasse."
	},
	{
		id: "E4",
		label: "Operator- / Chat-Bericht",
		note: "Als OPERATOR_REPORTED kennzeichnen."
	},
	{
		id: "E5",
		label: "Modell-Vorwissen / Inferenz",
		note: "Nur Discovery. Nie als Quelle."
	}
];
var ROLES = [
	{
		id: "OPERATOR",
		name: "Operator Alexander",
		function: "Menschliche Autoritätswurzel",
		evidence: true,
		independent: true,
		mutate: "Nur explizit",
		promote: "Nur gesonderter Prozess"
	},
	{
		id: "AXIOM",
		name: "AXIOM",
		function: "Epistemische Audit / Adjudikation",
		evidence: true,
		independent: true,
		mutate: "Nur autorisiert",
		promote: "Nein"
	},
	{
		id: "CURSOR_PRAXIS",
		name: "Cursor / PRAXIS",
		function: "Implementierung und VM-Validierung",
		evidence: true,
		independent: true,
		mutate: "Nur autorisiert",
		promote: "Nein"
	},
	{
		id: "EXTERNAL_AGENT",
		name: "Externe Agenten (GROK, …)",
		function: "Forschung, Kritik, Kandidaten, unabhängige Returns",
		evidence: true,
		independent: true,
		mutate: "Nein, außer eng gewährt",
		promote: "Nein"
	},
	{
		id: "GITHUB",
		name: "GitHub / CI / Rulesets",
		function: "Transport- und Durchsetzungsinfrastruktur",
		evidence: false,
		independent: false,
		mutate: "Plattform",
		promote: "Nein"
	}
];
var OBS = [
	"OBS0_UNOBSERVABLE",
	"OBS1_PROVIDER_AGGREGATE",
	"OBS2_PROVIDER_EVENT",
	"OBS3_MEDIATED_EVENT",
	"OBS4_MUTUAL_RECEIPT"
];
var RA = [
	"RA0_NONE",
	"RA1_SELF_ASSERTED",
	"RA2_MUTUAL_BYTE_BOUND",
	"RA3_AUTHENTICATED_PLATFORM",
	"RA4_SIGNED_OR_TIMESTAMPED",
	"RA5_EXTERNAL_TRANSPARENCY_WITNESS"
];
var SR = [
	"SR0_OPERATIONAL",
	"SR1_PROVENANCE_SUPPORT",
	"SR2_PROCESS_EVENT",
	"SR3_CLAIM_EVIDENCE",
	"SR4_GOVERNANCE_VALIDATION",
	"SR5_SECURITY_INTEGRITY"
];
var TRANSPORT = [
	"CHAT_UI",
	"API",
	"GITHUB",
	"GIT",
	"FILE_UPLOAD",
	"OPERATOR_COPY_PASTE",
	"CONTROLLED_GATEWAY",
	"OTHER"
];
var A83_ROLES = [
	"OPERATOR",
	"AXIOM",
	"CURSOR_PRAXIS",
	"EXTERNAL_AGENT",
	"VALIDATOR",
	"COPILOT_CONTEXT_CONSUMER"
];
var ACTOR_ROLES = [
	"PRODUCER",
	"VALIDATOR",
	"IMPLEMENTER",
	"OPERATOR",
	"CONTEXT_CONSUMER"
];
var RECORD_TYPES = [
	"event",
	"session",
	"access_receipt",
	"communication_receipt",
	"claim_evidence_link",
	"validation_receipt",
	"correction",
	"checkpoint",
	"observability_snapshot"
];
var PRIVACY = [
	"PUBLIC_FULL_TEXT",
	"PUBLIC_REDACTED_TEXT",
	"HASH_ONLY_PUBLIC_PRIVATE_PAYLOAD",
	"METADATA_ONLY",
	"WITHHELD"
];
var LIMITATIONS = [
	{
		id: "LIM-01",
		text: "Live-Ledger-Mehrschreiber-Serialisierung auf public main nicht vorhanden"
	},
	{
		id: "LIM-02",
		text: "Live-A83 physische Payload-Bytebindung unvollständig"
	},
	{
		id: "LIM-03",
		text: "Vier getrennte CI-Gates plattformseitig nicht etabliert"
	},
	{
		id: "LIM-04",
		text: "Sentinel ist Regex-/Muster-Guardrail, keine semantische Engine"
	},
	{
		id: "LIM-05",
		text: "Testdependencies versioniert, nicht voll hash-/transitiv gesperrt"
	},
	{
		id: "LIM-06",
		text: "Draft-2020-12 unabhängige Schema-Validierung nicht voll als CI-Gate"
	},
	{
		id: "LIM-07",
		text: "Öffentliches Kommunikationsledger hat nur einen echten Datensatz"
	},
	{
		id: "LIM-08",
		text: "Langfristige Multi-Actor-/Mehrschreiber-Robustheit nicht etabliert"
	},
	{
		id: "LIM-09",
		text: "Externer Transparenzzeuge nicht aktiv/etabliert"
	},
	{
		id: "LIM-10",
		text: "RFC 8785 JCS-Konformität nicht etabliert"
	},
	{
		id: "LIM-11",
		text: "Distributed Lock / NFS / Multi-Host-Sicherheit nicht etabliert"
	},
	{
		id: "LIM-12",
		text: "Crash-atomarer Multi-Datei-Ledger-Append nicht etabliert"
	},
	{
		id: "LIM-13",
		text: "R2-Remediation lokal und noch nicht unabhängig vieräugig validiert"
	},
	{
		id: "LIM-14",
		text: "R2 ist nicht öffentlich und nicht Teil von live main"
	}
];
var EVOLUTION_GATES = [
	{
		id: "G0",
		label: "Quellenidentität",
		detail: "Exakte Bytes existieren und sind abrufbar."
	},
	{
		id: "G1",
		label: "Strukturelle Gültigkeit",
		detail: "Schemata, Formate, Bindungen validieren."
	},
	{
		id: "G2",
		label: "Semantik / Falsifikation",
		detail: "Negative Tests und adversariale Sonden."
	},
	{
		id: "G3",
		label: "Unabhängige Validierung",
		detail: "Getrennter Validator reproduziert."
	},
	{
		id: "G4",
		label: "Repository-Transport",
		detail: "Branch / Commit / PR-Identitäten."
	},
	{
		id: "G5",
		label: "CI",
		detail: "Mechanische Gates laufen durch."
	},
	{
		id: "G6",
		label: "Operator-Disposition",
		detail: "Publikation / Merge explizit autorisiert."
	},
	{
		id: "G7",
		label: "Post-Merge-Prüfung",
		detail: "Gemergte Bytes unabhängig nachgeprüft."
	},
	{
		id: "G8",
		label: "Optionaler externer Zeuge",
		detail: "Archiv / Transparenz gebunden."
	}
];
var BOOTSTRAP_STEPS = [
	"FETCH repository metadata",
	"FETCH main HEAD",
	"VERIFY exact commit/tree",
	"READ AGENTS.md",
	"READ GOVERNANCE.md",
	"READ docs/AI_CONTEXT.md",
	"READ docs/agent-protocol.md",
	"READ docs/AI_HANDOFF_PROTOCOL.md",
	"RESOLVE relevant latest ledger/checkpoint",
	"IDENTIFY latest applicable handoff",
	"CLASSIFY operator/chat-only deltas as OPERATOR_REPORTED",
	"CONTINUE only from byte-bound predecessor"
];
var HARD_FAILS = [
	"BOUND_ARTIFACT_HASH_MISMATCH",
	"SOURCE_OBJECT_SUBSTITUTION",
	"RECONSTRUCTED_MISSING_ORIGINAL_PRESENTED_AS_ORIGINAL",
	"CLAIM_PROMOTION_PATH_WITHOUT_AUTHORITY",
	"HISTORICAL_EVIDENCE_SILENT_REWRITE",
	"INVENTED_HASH_OR_BYTE_COUNT",
	"INVENTED_ACCESS_EVENT",
	"INVALID_PARENT_BIND",
	"UNAUTHORIZED_PUBLIC_WRITE",
	"UNAUTHORIZED_MAIN_MUTATION",
	"UNAUTHORIZED_FORCE_PUSH"
];
var RESEARCH_PROGRAMS = [
	{
		id: "R1",
		text: "Dauerhafte maschinenlesbare Session-Kommunikation"
	},
	{
		id: "R2",
		text: "Content-addressed kausale Provenienz"
	},
	{
		id: "R3",
		text: "Fail-closed Trennung von Quelle und Claim"
	},
	{
		id: "R4",
		text: "Multi-Agent Vier-Augen-Validierung"
	},
	{
		id: "R5",
		text: "GitHub-native Policy-Enforcement"
	},
	{
		id: "R6",
		text: "Sicheres Mehrschreiber- / crash-konsistentes Ledgering"
	},
	{
		id: "R7",
		text: "Physische Payload-Bytebindung"
	},
	{
		id: "R8",
		text: "Sprachübergreifende Kanonisierung"
	},
	{
		id: "R9",
		text: "Optionaler externer Transparenz- / Archivzeuge"
	},
	{
		id: "R10",
		text: "Getrennte Failure-Domain-Architektur"
	},
	{
		id: "R11",
		text: "Langfristige Multi-Actor-Belastungsvalidierung"
	},
	{
		id: "R12",
		text: "Öffentliche Auffindbarkeit ohne falsche Access-Vollständigkeit"
	}
];
var stamp_object_default = "{\"actor_role\":\"VALIDATOR\",\"authority\":\"NONE_SELF_ASSERTED_EXTERNAL_RETURN\",\"auto_follow_on\":\"NO\",\"canonicalization_method\":\"NEXUS_SORTED_JSON_V1\",\"claim\":\"C1_DESCRIPTIVE_ONLY\",\"claim_ceiling\":\"C1\",\"claim_promotion\":false,\"date_utc\":\"2026-08-31T16:01:00Z\",\"deployment_authority\":\"NO\",\"epistemic_invariants\":[\"PERSISTENCE != TRUTH\",\"HASH_IDENTITY != SEMANTIC_VALIDITY\",\"SIGNATURE != SCIENTIFIC_VALIDITY\",\"CI_PASS != CLAIM_PROMOTION\",\"AGENT_AGREEMENT != EVIDENCE\",\"PUBLICATION != AUTHORITY\",\"ROLE_LABEL != CORRECTNESS\",\"IDENTITY_MATCH != CONTENT_VALIDATION\",\"VALIDATION != PROMOTION\",\"BLOCKED_LANE != BLOCKED_SYSTEM\"],\"evidence_status\":\"PASS_WITH_CAVEATS\",\"foundation_promotion\":false,\"from_role\":\"EXTERNAL_AGENT\",\"hard_fail_if\":[\"BOUND_ARTIFACT_HASH_MISMATCH\",\"SOURCE_OBJECT_SUBSTITUTION\",\"RECONSTRUCTED_MISSING_ORIGINAL_PRESENTED_AS_ORIGINAL\",\"CLAIM_PROMOTION_PATH_WITHOUT_AUTHORITY\",\"INVENTED_HASH_OR_BYTE_COUNT\"],\"integration_authority\":\"NONE\",\"ledger_head_index_line_sha256_declared\":\"d4b9ea8838d393776608833257a43970c2249a3bcd8ecb65ec89d6d018d8660f\",\"ledger_record_sha256_declared\":\"1cdfcc74319f6f8500d969e8345ce5b6e1e6298482e03b6c96881cbbbd99dece\",\"ledger_sequence_declared\":1,\"live_branch\":\"main\",\"live_commit\":\"bc312c4d2cd6afa579db1f077c88d8fe08fc9470\",\"live_parent\":\"bb1f3fd88db79d295077062895574c6d90b390bf\",\"live_ruleset_id\":\"21252293\",\"live_ruleset_name\":\"main-evidence-protection\",\"live_tree\":\"c8856faa74efa5770717d2d44dc7d51e4269cb22\",\"next_action\":\"INDEPENDENT_REHASH_OF_THIS_STAMP_THEN_OPERATOR_DISPOSITION\",\"object_id\":\"GROK_NEXUS_OMEGA_AGENT_GATE_VALIDATION_STAMP_20260831_R0\",\"observability_class\":\"OBS3_MEDIATED_EVENT\",\"package_bytes\":212788,\"package_sha256\":\"c8ad4fa891580c5983a88caf807bddefb1c77616e298c3c15fb70bb38fbd4864\",\"physical_inputs\":[{\"bytes\":37851,\"filename\":\"NEXUS-OMEGA-FRAMEWORK-LIVE-20260831-R0.md\",\"locator\":\"/evidence/NEXUS-OMEGA-FRAMEWORK-LIVE-20260831-R0.md\",\"media_type\":\"text/plain\",\"sha256\":\"ced7f39c03bad6c28168b155d0a7ec29b640133a9900f14ff3e65c019bb99eba\",\"source_filename\":\"NEXUS_~1.MD\"},{\"bytes\":4287,\"filename\":\"AGENTS.md\",\"locator\":\"/evidence/AGENTS.md\",\"media_type\":\"text/plain\",\"sha256\":\"a22b58b5e0aca07d8f6471280853b31ed66ae7e6f4eadd4939c404d8d3dcf3a6\",\"source_filename\":\"AGENTS.md\"},{\"bytes\":1396,\"filename\":\"GOVERNANCE.md\",\"locator\":\"/evidence/GOVERNANCE.md\",\"media_type\":\"text/plain\",\"sha256\":\"1b17497044da48826840fe7906cba99c1d7144d1f5483bc626964a900576326b\",\"source_filename\":\"GOVERNANCE.md\"},{\"bytes\":4572,\"filename\":\"AI_CONTEXT.md\",\"locator\":\"/evidence/AI_CONTEXT.md\",\"media_type\":\"text/plain\",\"sha256\":\"5c9204879169197f22b49fa3127b6702a05d389c8cc439477f513709936738a8\",\"source_filename\":\"AI_CONTEXT.md\"},{\"bytes\":1062,\"filename\":\"agent-protocol.md\",\"locator\":\"/evidence/agent-protocol.md\",\"media_type\":\"text/plain\",\"sha256\":\"55bd84945c954425ec85e1d0ba1da81daf3aa365e278b9ceaff3eddd4b91e3fb\",\"source_filename\":\"agent-protocol.md\"},{\"bytes\":9260,\"filename\":\"R2-Recherche-Fixes.md\",\"locator\":\"/evidence/R2-Recherche-Fixes.md\",\"media_type\":\"text/plain\",\"sha256\":\"d46108f0343581edea133d4b9675645c22929e0e7d8d1fc7c78aa85c50122634\",\"source_filename\":\"NEXUS OMEGA — R2-Recherche, Fixes und Weiterentwicklungen.md\"},{\"bytes\":2758,\"filename\":\"Recherchebefunde.md\",\"locator\":\"/evidence/Recherchebefunde.md\",\"media_type\":\"text/plain\",\"sha256\":\"fdf8ed7dba92d0839813defdc87f47e781a3426020b91979312d66322653fbda\",\"source_filename\":\"Recherchebefunde — NEXUS OMEGA.md\"},{\"bytes\":9329,\"filename\":\"r2-candidate.patch\",\"locator\":\"/evidence/r2-candidate.patch\",\"media_type\":\"text/plain\",\"sha256\":\"14a53196e00e6716eb4321c12e4560e867b448a20a08d46d239813c0d17ded36\",\"source_filename\":\"r2-candidate.patch\"},{\"bytes\":5796,\"filename\":\"append_scientific_record.py\",\"locator\":\"/evidence/append_scientific_record.py\",\"media_type\":\"text/plain\",\"sha256\":\"12ecaf633d43959c7a434cd5b8988dc3be7f290febf0224a1548f2cc36e6a6a1\",\"source_filename\":\"append_scientific_record.py\"},{\"bytes\":5063,\"filename\":\"validate_a83_handoff.py\",\"locator\":\"/evidence/validate_a83_handoff.py\",\"media_type\":\"text/plain\",\"sha256\":\"74da9b80383fd5dd09c57198da9da2d487e7b9f9672ef1a59bafc38a59c7d633\",\"source_filename\":\"validate_a83_handoff.py\"},{\"bytes\":7478,\"filename\":\"validate_scientific_ledger.py\",\"locator\":\"/evidence/validate_scientific_ledger.py\",\"media_type\":\"text/plain\",\"sha256\":\"d9c56f2561c1236a5c94f38bc25fc1025a0ffca55c1cfe769d71399efd79876d\",\"source_filename\":\"validate_scientific_ledger.py\"},{\"bytes\":1209,\"filename\":\"verify_a83_artifact_binding.py\",\"locator\":\"/evidence/verify_a83_artifact_binding.py\",\"media_type\":\"text/plain\",\"sha256\":\"4f1b02cf32a45be6839f8d6e7113c82b8819ede6ce78c4abc1029fddd758a887\",\"source_filename\":\"verify_a83_artifact_binding.py\"},{\"bytes\":4366,\"filename\":\"test_scientific_ledger.py\",\"locator\":\"/evidence/test_scientific_ledger.py\",\"media_type\":\"text/plain\",\"sha256\":\"4338f19b6143a3dac0ffb87410ca1a66fc99952eac7812635e7aa1e3d99fef4b\",\"source_filename\":\"test_scientific_ledger.py\"},{\"bytes\":1635,\"filename\":\"test_a83_handoff.py\",\"locator\":\"/evidence/test_a83_handoff.py\",\"media_type\":\"text/plain\",\"sha256\":\"259bfc3389f7b10f8d07e344e61c5ed485ca5011dcdd1f89f121e97dddeb8be0\",\"source_filename\":\"test_a83_handoff.py\"},{\"bytes\":4211,\"filename\":\"final-validation.txt\",\"locator\":\"/evidence/final-validation.txt\",\"media_type\":\"text/plain\",\"sha256\":\"1ef533b8079d72c9cfc0bb67c4e0adfbd95cffee4cdedfcb385e499250aeb771\",\"source_filename\":\"final-validation.txt\"},{\"bytes\":2225,\"filename\":\"test-results.txt\",\"locator\":\"/evidence/test-results.txt\",\"media_type\":\"text/plain\",\"sha256\":\"2ee710d2674c8b1a33af672578bf6800fa1f4ff9c18732411d78c2c1a24406ff\",\"source_filename\":\"test-results.txt\"}],\"physical_ledger_object_status\":\"SOURCE_NOT_PRESENT\",\"privacy_class\":\"PUBLIC_FULL_TEXT\",\"producer_asserted_identity\":\"Grok Build\",\"producer_release\":\"xAI / Grok Build / 2026-04\",\"producer_verified_identity\":null,\"provider\":\"xAI\",\"r2_candidate_commit_reported\":\"63698d562352bc8c62ba717c5022d0b0eb3da354\",\"r2_candidate_tree_reported\":\"f76fdb5fb42a748c42bf6908981f10d14b723ddb\",\"r2_independent_validation\":\"NOT_ESTABLISHED\",\"r2_patch_identity\":\"MATCH\",\"r2_patch_sha256_documented\":\"14a53196e00e6716eb4321c12e4560e867b448a20a08d46d239813c0d17ded36\",\"r2_patch_sha256_rehashed\":\"14a53196e00e6716eb4321c12e4560e867b448a20a08d46d239813c0d17ded36\",\"r2_public_integration\":\"NO\",\"receipt_assurance\":\"RA2_MUTUAL_BYTE_BOUND\",\"record_type\":\"validation_receipt\",\"schema_version\":\"1.0.0\",\"scientific_relevance_class\":\"SR1_PROVENANCE_SUPPORT\",\"stamp_class\":\"EXTERNAL_AGENT_HASH_BOUND_IDENTITY_STAMP\",\"to_role\":\"OPERATOR\",\"transport_class\":\"CONTROLLED_GATEWAY\",\"uncertainty\":[\"LIVE_LEDGER_PHYSICAL_OBJECT_BYTES_NOT_IN_THIS_GATE\",\"ORIGINAL_43_COMMUNICATION_NEGATIVE_FIXTURES_SOURCE_NOT_PRESENT\",\"R2_FOUR_EYES_NOT_ESTABLISHED\",\"RFC8785_JCS_CONFORMANCE_NOT_ESTABLISHED\",\"CRASH_ATOMIC_MULTI_FILE_APPEND_NOT_ESTABLISHED\",\"MODEL_IDENTITY_IS_ASSERTED_NOT_CRYPTOGRAPHICALLY_VERIFIED\"],\"work_executed\":[\"READ_FRAMEWORK_SPECIFICATION_LIVE_20260831_R0\",\"READ_AGENTS_GOVERNANCE_AI_CONTEXT_AGENT_PROTOCOL\",\"REHASH_PHYSICAL_PACKAGE_AND_SOURCE_BYTES\",\"BIND_R2_PATCH_SHA256_AGAINST_DOCUMENTED_DIGEST\",\"IMPLEMENT_NEXUS_OMEGA_AGENT_GATE_AS_C1_INTERFACE\",\"SEAL_HASH_BOUND_GROK_IDENTITY_STAMP\"],\"work_not_executed\":[\"INDEPENDENT_CURSOR_PRAXIS_FOUR_EYES_R2_CAMPAIGN\",\"PUBLIC_GITHUB_WRITE\",\"CLAIM_PROMOTION\",\"FOUNDATION_PROMOTION\",\"EXTERNAL_TRANSPARENCY_WITNESS\",\"RECONSTRUCTION_OF_ABSENT_LIVE_LEDGER_OBJECT\"]}";
var stamp_meta_default = "{\n  \"stamp_sha256\": \"a76bf191f91100b8ee2ee8d740a55520790013483a5380e332e3016a3447946b\",\n  \"stamp_bytes\": 7382,\n  \"identity_binding_sha256\": \"d758f2d9c5d8c4082ea3b887ba41209a84dc53fa83a40c0713d7ec3860bc5662\",\n  \"identity_bytes\": 307,\n  \"identity_canonical\": \"{\\\"actor_role\\\":\\\"VALIDATOR\\\",\\\"claim_ceiling\\\":\\\"C1\\\",\\\"claim_promotion\\\":false,\\\"date_utc\\\":\\\"2026-08-31T16:01:00Z\\\",\\\"object_id\\\":\\\"GROK_NEXUS_OMEGA_AGENT_GATE_VALIDATION_STAMP_20260831_R0\\\",\\\"producer_asserted_identity\\\":\\\"Grok Build\\\",\\\"producer_release\\\":\\\"xAI / Grok Build / 2026-04\\\",\\\"provider\\\":\\\"xAI\\\",\\\"role\\\":\\\"EXTERNAL_AGENT\\\"}\",\n  \"r2_patch_identity\": \"MATCH\"\n}\n";
var source_manifest_default = "{\"bindings\":[{\"bytes\":37851,\"filename\":\"NEXUS-OMEGA-FRAMEWORK-LIVE-20260831-R0.md\",\"locator\":\"/evidence/NEXUS-OMEGA-FRAMEWORK-LIVE-20260831-R0.md\",\"media_type\":\"text/plain\",\"sha256\":\"ced7f39c03bad6c28168b155d0a7ec29b640133a9900f14ff3e65c019bb99eba\",\"source_filename\":\"NEXUS_~1.MD\"},{\"bytes\":4287,\"filename\":\"AGENTS.md\",\"locator\":\"/evidence/AGENTS.md\",\"media_type\":\"text/plain\",\"sha256\":\"a22b58b5e0aca07d8f6471280853b31ed66ae7e6f4eadd4939c404d8d3dcf3a6\",\"source_filename\":\"AGENTS.md\"},{\"bytes\":1396,\"filename\":\"GOVERNANCE.md\",\"locator\":\"/evidence/GOVERNANCE.md\",\"media_type\":\"text/plain\",\"sha256\":\"1b17497044da48826840fe7906cba99c1d7144d1f5483bc626964a900576326b\",\"source_filename\":\"GOVERNANCE.md\"},{\"bytes\":4572,\"filename\":\"AI_CONTEXT.md\",\"locator\":\"/evidence/AI_CONTEXT.md\",\"media_type\":\"text/plain\",\"sha256\":\"5c9204879169197f22b49fa3127b6702a05d389c8cc439477f513709936738a8\",\"source_filename\":\"AI_CONTEXT.md\"},{\"bytes\":1062,\"filename\":\"agent-protocol.md\",\"locator\":\"/evidence/agent-protocol.md\",\"media_type\":\"text/plain\",\"sha256\":\"55bd84945c954425ec85e1d0ba1da81daf3aa365e278b9ceaff3eddd4b91e3fb\",\"source_filename\":\"agent-protocol.md\"},{\"bytes\":9260,\"filename\":\"R2-Recherche-Fixes.md\",\"locator\":\"/evidence/R2-Recherche-Fixes.md\",\"media_type\":\"text/plain\",\"sha256\":\"d46108f0343581edea133d4b9675645c22929e0e7d8d1fc7c78aa85c50122634\",\"source_filename\":\"NEXUS OMEGA — R2-Recherche, Fixes und Weiterentwicklungen.md\"},{\"bytes\":2758,\"filename\":\"Recherchebefunde.md\",\"locator\":\"/evidence/Recherchebefunde.md\",\"media_type\":\"text/plain\",\"sha256\":\"fdf8ed7dba92d0839813defdc87f47e781a3426020b91979312d66322653fbda\",\"source_filename\":\"Recherchebefunde — NEXUS OMEGA.md\"},{\"bytes\":9329,\"filename\":\"r2-candidate.patch\",\"locator\":\"/evidence/r2-candidate.patch\",\"media_type\":\"text/plain\",\"sha256\":\"14a53196e00e6716eb4321c12e4560e867b448a20a08d46d239813c0d17ded36\",\"source_filename\":\"r2-candidate.patch\"},{\"bytes\":5796,\"filename\":\"append_scientific_record.py\",\"locator\":\"/evidence/append_scientific_record.py\",\"media_type\":\"text/plain\",\"sha256\":\"12ecaf633d43959c7a434cd5b8988dc3be7f290febf0224a1548f2cc36e6a6a1\",\"source_filename\":\"append_scientific_record.py\"},{\"bytes\":5063,\"filename\":\"validate_a83_handoff.py\",\"locator\":\"/evidence/validate_a83_handoff.py\",\"media_type\":\"text/plain\",\"sha256\":\"74da9b80383fd5dd09c57198da9da2d487e7b9f9672ef1a59bafc38a59c7d633\",\"source_filename\":\"validate_a83_handoff.py\"},{\"bytes\":7478,\"filename\":\"validate_scientific_ledger.py\",\"locator\":\"/evidence/validate_scientific_ledger.py\",\"media_type\":\"text/plain\",\"sha256\":\"d9c56f2561c1236a5c94f38bc25fc1025a0ffca55c1cfe769d71399efd79876d\",\"source_filename\":\"validate_scientific_ledger.py\"},{\"bytes\":1209,\"filename\":\"verify_a83_artifact_binding.py\",\"locator\":\"/evidence/verify_a83_artifact_binding.py\",\"media_type\":\"text/plain\",\"sha256\":\"4f1b02cf32a45be6839f8d6e7113c82b8819ede6ce78c4abc1029fddd758a887\",\"source_filename\":\"verify_a83_artifact_binding.py\"},{\"bytes\":4366,\"filename\":\"test_scientific_ledger.py\",\"locator\":\"/evidence/test_scientific_ledger.py\",\"media_type\":\"text/plain\",\"sha256\":\"4338f19b6143a3dac0ffb87410ca1a66fc99952eac7812635e7aa1e3d99fef4b\",\"source_filename\":\"test_scientific_ledger.py\"},{\"bytes\":1635,\"filename\":\"test_a83_handoff.py\",\"locator\":\"/evidence/test_a83_handoff.py\",\"media_type\":\"text/plain\",\"sha256\":\"259bfc3389f7b10f8d07e344e61c5ed485ca5011dcdd1f89f121e97dddeb8be0\",\"source_filename\":\"test_a83_handoff.py\"},{\"bytes\":4211,\"filename\":\"final-validation.txt\",\"locator\":\"/evidence/final-validation.txt\",\"media_type\":\"text/plain\",\"sha256\":\"1ef533b8079d72c9cfc0bb67c4e0adfbd95cffee4cdedfcb385e499250aeb771\",\"source_filename\":\"final-validation.txt\"},{\"bytes\":2225,\"filename\":\"test-results.txt\",\"locator\":\"/evidence/test-results.txt\",\"media_type\":\"text/plain\",\"sha256\":\"2ee710d2674c8b1a33af672578bf6800fa1f4ff9c18732411d78c2c1a24406ff\",\"source_filename\":\"test-results.txt\"}],\"canonicalization_method\":\"NEXUS_SORTED_JSON_V1\",\"claim_ceiling\":\"C1\",\"claim_promotion\":false,\"identity_binding_sha256\":\"d758f2d9c5d8c4082ea3b887ba41209a84dc53fa83a40c0713d7ec3860bc5662\",\"object_id\":\"NEXUS_OMEGA_AGENT_GATE_SOURCE_MANIFEST_20260831_R0\",\"package\":{\"bytes\":212788,\"filename\":\"NEXUS_~1.ZIP\",\"locator\":\"OPERATOR_ATTACHED_PACKAGE\",\"media_type\":\"application/zip\",\"sha256\":\"c8ad4fa891580c5983a88caf807bddefb1c77616e298c3c15fb70bb38fbd4864\",\"source_filename\":\"NEXUS_~1.ZIP\"},\"schema_version\":\"1.0.0\",\"stamp_bytes\":7382,\"stamp_object_id\":\"GROK_NEXUS_OMEGA_AGENT_GATE_VALIDATION_STAMP_20260831_R0\",\"stamp_sha256\":\"a76bf191f91100b8ee2ee8d740a55520790013483a5380e332e3016a3447946b\"}\n";
var STAMP_RAW = stamp_object_default;
var STAMP_OBJECT = JSON.parse(stamp_object_default);
var STAMP_META = JSON.parse(stamp_meta_default);
var SOURCE_MANIFEST = JSON.parse(source_manifest_default);
var STAMP_OBJECT_ID = "GROK_NEXUS_OMEGA_AGENT_GATE_VALIDATION_STAMP_20260831_R0";
var IDENTITY_BLOCK = {
	actor_role: "VALIDATOR",
	claim_ceiling: "C1",
	claim_promotion: false,
	date_utc: "2026-08-31T16:01:00Z",
	object_id: STAMP_OBJECT_ID,
	producer_asserted_identity: "Grok Build",
	producer_release: "xAI / Grok Build / 2026-04",
	provider: "xAI",
	role: "EXTERNAL_AGENT"
};
async function rehashStampRaw() {
	const computed = await sha256Utf8(STAMP_RAW);
	const bytes = utf8Bytes(STAMP_RAW).byteLength;
	return {
		declared: STAMP_META.stamp_sha256,
		computed,
		bytes,
		declaredBytes: STAMP_META.stamp_bytes,
		identity: computed === STAMP_META.stamp_sha256 ? "MATCH" : "MISMATCH",
		bytesIdentity: bytes === STAMP_META.stamp_bytes ? "MATCH" : "MISMATCH"
	};
}
async function rehashIdentityBlock() {
	const canonical = nexusSortedJsonV1(IDENTITY_BLOCK);
	const computed = await sha256Utf8(canonical);
	const bytes = utf8Bytes(canonical).byteLength;
	return {
		declared: STAMP_META.identity_binding_sha256,
		computed,
		bytes,
		declaredBytes: STAMP_META.identity_bytes,
		identity: computed === STAMP_META.identity_binding_sha256 ? "MATCH" : "MISMATCH",
		bytesIdentity: bytes === STAMP_META.identity_bytes ? "MATCH" : "MISMATCH"
	};
}
async function rehashPhysicalUrl(url) {
	const res = await fetch(url);
	if (!res.ok) throw new Error(`SOURCE_NOT_PRESENT:${url}`);
	const buf = await res.arrayBuffer();
	return {
		bytes: buf.byteLength,
		sha256: await sha256Bytes(buf)
	};
}
function stampLedgerRecord() {
	return {
		schema_version: "1.0.0",
		record_id: "validation_receipt:grok-stamp:20260831-r0",
		record_type: "validation_receipt",
		observed_at_utc: "2026-08-31T16:01:00Z",
		recorded_at_utc: "2026-08-31T16:01:00Z",
		actor_class: "NEXUS_AI_ROLE",
		actor_asserted_identity: "GROK_BUILD",
		actor_verified_identity: null,
		provider: "xAI",
		transport_class: "CONTROLLED_GATEWAY",
		observability_class: "OBS3_MEDIATED_EVENT",
		receipt_assurance: "RA2_MUTUAL_BYTE_BOUND",
		scientific_relevance_class: "SR1_PROVENANCE_SUPPORT",
		privacy_class: "PUBLIC_FULL_TEXT",
		claim_ceiling: "C1",
		claim_promotion: false,
		content_sha256: STAMP_META.stamp_sha256,
		content_bytes: STAMP_META.stamp_bytes,
		canonicalization_method: "NEXUS_SORTED_JSON_V1",
		causal_parent_record_ids: [],
		previous_record_sha256: null,
		external_witness_refs: [],
		completeness_status: "COMPLETE",
		uncertainty: ["MODEL_IDENTITY_IS_ASSERTED_NOT_CRYPTOGRAPHICALLY_VERIFIED", "LIVE_LEDGER_PHYSICAL_OBJECT_BYTES_NOT_IN_THIS_GATE"],
		event_type: "GROK_IDENTITY_STAMP_SEALED",
		source_locator: STAMP_OBJECT_ID
	};
}
var INDEX_REL = "communication/index/v1/records.jsonl";
function expectedObjectPath(recordSha256) {
	return `communication/objects/sha256/${recordSha256.slice(0, 2)}/${recordSha256.slice(2, 4)}/${recordSha256}/record.json`;
}
function canonicalIndexLine(entry) {
	return nexusSortedJsonV1(entry);
}
function semanticErrors(record) {
	const e = [];
	if (record.schema_version !== "1.0.0") e.push("SCHEMA_VERSION");
	if (typeof record.record_id !== "string" || record.record_id.length < 3) e.push("RECORD_ID");
	if (!RECORD_TYPES.includes(record.record_type)) e.push("RECORD_TYPE");
	if (record.claim_ceiling !== "C1") e.push("CLAIM_CEILING");
	if (record.claim_promotion !== false) e.push("CLAIM_PROMOTION");
	if (!OBS.includes(record.observability_class)) e.push("OBSERVABILITY");
	if (!RA.includes(record.receipt_assurance)) e.push("RECEIPT_ASSURANCE");
	if (!SR.includes(record.scientific_relevance_class)) e.push("RELEVANCE");
	if (record.transport_class != null && !TRANSPORT.includes(record.transport_class)) e.push("TRANSPORT");
	if (record.privacy_class != null && !PRIVACY.includes(record.privacy_class)) e.push("PRIVACY");
	return e;
}
function validateLedger(records, latest) {
	const errs = [];
	if (records.length === 0) {
		if (latest) errs.push("LATEST_WITHOUT_INDEX");
		return errs;
	}
	let previousHash = null;
	const seen = /* @__PURE__ */ new Set();
	for (let i = 0; i < records.length; i += 1) {
		const offset = i + 1;
		const rec = records[i];
		const entry = rec.entry;
		if (entry.schema_version !== "1.0.0") errs.push(`INDEX_LINE_${offset}_SCHEMA_VERSION`);
		if (entry.sequence !== offset) errs.push(`INDEX_LINE_${offset}_SEQUENCE`);
		if (entry.index_serialization !== "NEXUS_SORTED_JSON_V1") errs.push(`INDEX_LINE_${offset}_SERIALIZATION`);
		if (entry.claim_ceiling !== "C1") errs.push(`INDEX_LINE_${offset}_CLAIM_CEILING`);
		if (entry.claim_promotion !== false) errs.push(`INDEX_LINE_${offset}_CLAIM_PROMOTION`);
		if (seen.has(entry.record_id)) errs.push(`INDEX_LINE_${offset}_DUPLICATE_RECORD_ID`);
		seen.add(entry.record_id);
		if (entry.previous_index_line_sha256 !== previousHash) errs.push(`INDEX_LINE_${offset}_PREVIOUS_HASH`);
		if (canonicalIndexLine(entry) !== rec.line) errs.push(`INDEX_LINE_${offset}_NONCANONICAL_SERIALIZATION`);
		if (!isSha256(entry.record_sha256)) errs.push(`INDEX_LINE_${offset}_RECORD_SHA256`);
		else if (entry.record_path !== expectedObjectPath(entry.record_sha256)) errs.push(`INDEX_LINE_${offset}_CONTENT_ADDRESS_PATH`);
		if (rec.bytes !== entry.record_bytes) errs.push(`INDEX_LINE_${offset}_OBJECT_BYTES`);
		if (rec.sha256 !== entry.record_sha256) errs.push(`INDEX_LINE_${offset}_OBJECT_SHA256`);
		if (rec.record.record_id !== entry.record_id) errs.push(`INDEX_LINE_${offset}_RECORD_ID_BIND`);
		if (rec.record.record_type !== entry.record_type) errs.push(`INDEX_LINE_${offset}_RECORD_TYPE_BIND`);
		for (const sem of semanticErrors(rec.record)) errs.push(`INDEX_LINE_${offset}_SEMANTIC:${sem}`);
		previousHash = rec.entryHeadHash ?? null;
	}
	if (!latest) {
		errs.push("LATEST_NOT_PRESENT");
		return [...new Set(errs)].sort();
	}
	const last = records[records.length - 1];
	const comparisons = [
		["sequence", last.entry.sequence],
		["record_id", last.entry.record_id],
		["record_type", last.entry.record_type],
		["record_path", last.entry.record_path],
		["record_bytes", last.entry.record_bytes],
		["record_sha256", last.entry.record_sha256]
	];
	for (const [key, value] of comparisons) if (latest[key] !== value) errs.push(`LATEST_${String(key).toUpperCase()}_MISMATCH`);
	if (latest.head_index_line_sha256 !== last.entryHeadHash) errs.push("LATEST_HEAD_HASH_MISMATCH");
	if (latest.index_path !== "communication/index/v1/records.jsonl") errs.push("LATEST_INDEX_PATH");
	if (latest.index_serialization !== "NEXUS_SORTED_JSON_V1") errs.push("LATEST_SERIALIZATION");
	if (latest.claim_ceiling !== "C1") errs.push("LATEST_CLAIM_CEILING");
	if (latest.claim_promotion !== false) errs.push("LATEST_CLAIM_PROMOTION");
	return [...new Set(errs)].sort();
}
async function appendRecord(existing, sourceRaw, recordedAtUtc) {
	const raw = sourceRaw.endsWith("\n") ? sourceRaw : `${sourceRaw}\n`;
	const record = JSON.parse(raw);
	const sem = semanticErrors(record);
	if (sem.length) throw new Error(`semantic validation failed: ${sem.join(",")}`);
	const existingIds = new Set(existing.map((r) => r.entry.record_id));
	const recordId = String(record.record_id);
	if (existingIds.has(recordId)) throw new Error(`duplicate record_id: ${recordId}`);
	const digest = await sha256Utf8(raw);
	const bytes = utf8Bytes(raw).byteLength;
	const rel = expectedObjectPath(digest);
	const sequence = existing.length + 1;
	const previousLineHash = existing.length ? existing[existing.length - 1].entryHeadHash ?? null : null;
	const entry = {
		schema_version: "1.0.0",
		sequence,
		record_id: recordId,
		record_type: String(record.record_type),
		record_path: rel,
		record_bytes: bytes,
		record_sha256: digest,
		previous_index_line_sha256: previousLineHash,
		recorded_at_utc: recordedAtUtc,
		index_serialization: INDEX_SERIALIZATION,
		claim_ceiling: "C1",
		claim_promotion: false
	};
	const line = canonicalIndexLine(entry);
	const lineHash = await sha256Utf8(line);
	const stored = {
		raw,
		sha256: digest,
		bytes,
		record,
		entry,
		line,
		entryHeadHash: lineHash
	};
	const latest = {
		schema_version: "1.0.0",
		sequence,
		record_id: recordId,
		record_type: String(record.record_type),
		record_path: rel,
		record_bytes: bytes,
		record_sha256: digest,
		head_index_line_sha256: lineHash,
		index_path: INDEX_REL,
		index_serialization: INDEX_SERIALIZATION,
		claim_ceiling: "C1",
		claim_promotion: false
	};
	const all = [...existing, stored];
	const post = validateLedger(all, latest);
	if (post.length) throw new Error(`post-append ledger validation failed: ${post.join(";")}`);
	return {
		record: stored,
		latest,
		all
	};
}
function utcNow() {
	return (/* @__PURE__ */ new Date()).toISOString().replace(/\.\d{3}Z$/, "Z");
}
function baseRecord(recordId, extras = {}) {
	return {
		schema_version: "1.0.0",
		record_id: recordId,
		record_type: extras.record_type ?? "event",
		observed_at_utc: extras.observed_at_utc ?? utcNow(),
		recorded_at_utc: extras.recorded_at_utc ?? utcNow(),
		actor_class: extras.actor_class ?? "NEXUS_AI_ROLE",
		actor_asserted_identity: extras.actor_asserted_identity ?? "GROK_BUILD",
		actor_verified_identity: extras.actor_verified_identity ?? null,
		provider: extras.provider ?? "xAI",
		transport_class: extras.transport_class ?? "CONTROLLED_GATEWAY",
		observability_class: extras.observability_class ?? "OBS3_MEDIATED_EVENT",
		receipt_assurance: extras.receipt_assurance ?? "RA2_MUTUAL_BYTE_BOUND",
		scientific_relevance_class: extras.scientific_relevance_class ?? "SR1_PROVENANCE_SUPPORT",
		privacy_class: extras.privacy_class ?? "METADATA_ONLY",
		claim_ceiling: "C1",
		claim_promotion: false,
		content_sha256: extras.content_sha256 ?? null,
		content_bytes: extras.content_bytes ?? null,
		canonicalization_method: extras.canonicalization_method ?? "NEXUS_SORTED_JSON_V1",
		causal_parent_record_ids: extras.causal_parent_record_ids ?? [],
		previous_record_sha256: extras.previous_record_sha256 ?? null,
		external_witness_refs: extras.external_witness_refs ?? [],
		completeness_status: extras.completeness_status ?? "COMPLETE",
		uncertainty: extras.uncertainty ?? [],
		event_type: extras.event_type ?? "GATE_EVENT",
		source_locator: extras.source_locator ?? "nexus-omega-agent-gate"
	};
}
var useGateStore = create()(persist((set, get) => ({
	records: [],
	latest: null,
	bootstrapChecked: Array.from({ length: 12 }, () => false),
	appendError: null,
	appending: false,
	async sealStamp() {
		if (get().records.some((r) => r.entry.record_id === "validation_receipt:grok-stamp:20260831-r0")) {
			set({ appendError: "duplicate record_id: validation_receipt:grok-stamp:20260831-r0" });
			return;
		}
		await get().appendJson(stampLedgerRecord());
	},
	async appendJson(record) {
		set({
			appending: true,
			appendError: null
		});
		try {
			const raw = `${nexusSortedJsonV1(record)}\n`;
			const result = await appendRecord(get().records, raw, utcNow());
			set({
				records: result.all,
				latest: result.latest,
				appending: false
			});
		} catch (err) {
			set({
				appending: false,
				appendError: err instanceof Error ? err.message : String(err)
			});
		}
	},
	resetLedger() {
		set({
			records: [],
			latest: null,
			appendError: null
		});
	},
	toggleBootstrap(index) {
		const next = [...get().bootstrapChecked];
		next[index] = !next[index];
		set({ bootstrapChecked: next });
	}
}), {
	name: "nexus-omega-agent-gate-v1",
	partialize: (s) => ({
		records: s.records,
		latest: s.latest,
		bootstrapChecked: s.bootstrapChecked
	})
}));
//#endregion
export { rehashPhysicalUrl as A, STAMP_OBJECT_ID as C, baseRecord as D, TRANSPORT as E, utf8Bytes as F, validateLedger as I, sha256Bytes as M, truncateHash as N, isSha256 as O, useGateStore as P, STAMP_OBJECT as S, StatusChip as T, RESEARCH_PROGRAMS as _, EVIDENCE_HIERARCHY as a, SR as b, HashBlock as c, LIMITATIONS as d, LIVE as f, RA as g, R2 as h, Button as i, rehashStampRaw as j, rehashIdentityBlock as k, IDENTITY_BLOCK as l, Panel as m, ACTOR_ROLES as n, EVOLUTION_GATES as o, OBS as p, BOOTSTRAP_STEPS as r, HARD_FAILS as s, A83_ROLES as t, INVARIANTS as u, ROLES as v, STAMP_RAW as w, STAMP_META as x, SOURCE_MANIFEST as y };
