import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as baseRecord, I as validateLedger, P as useGateStore, T as StatusChip, c as HashBlock, f as LIVE, i as Button, m as Panel } from "./store-CkzlrWW2.mjs";
import { n as Textarea, t as Input } from "./textarea-C5v4QppQ.mjs";
import { t as Kv } from "./kv-DizFxdeC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ledger-vIB5lAm9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LedgerPage() {
	const records = useGateStore((s) => s.records);
	const latest = useGateStore((s) => s.latest);
	const appendJson = useGateStore((s) => s.appendJson);
	const resetLedger = useGateStore((s) => s.resetLedger);
	const sealStamp = useGateStore((s) => s.sealStamp);
	const appending = useGateStore((s) => s.appending);
	const appendError = useGateStore((s) => s.appendError);
	const [recordId, setRecordId] = (0, import_react.useState)("event:gate-note:0001");
	const [note, setNote] = (0, import_react.useState)("C1 descriptive local event. No claim promotion.");
	const errors = (0, import_react.useMemo)(() => validateLedger(records, latest), [records, latest]);
	async function appendNote() {
		await appendJson(baseRecord(recordId, {
			event_type: "GATE_NOTE",
			source_locator: note.slice(0, 120),
			completeness_status: "COMPLETE"
		}));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[11px] tracking-[0.2em] text-steel uppercase",
					children: "Content-addressed Ledger"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 text-3xl font-medium tracking-tight",
					children: "Wissenschaftliches Ledger"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-2xl text-[15px] leading-relaxed text-muted",
					children: "Append-only. Korrekturen erzeugen neue Objekte. Der öffentliche Live-Head bleibt SOURCE_NOT_PRESENT — fehlende Bytes werden nicht rekonstruiert."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					kicker: "Public main",
					title: "Deklarierter Live-Head",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "SEQUENCE",
									value: LIVE.ledgerSequence
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "RECORD_ID",
									value: LIVE.ledgerRecordId
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "RECORD_BYTES",
									value: LIVE.ledgerRecordBytes
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "PHYSICAL_OBJECT",
									value: "SOURCE_NOT_PRESENT",
									chip: true
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashBlock, {
							className: "mt-2",
							label: "RECORD_SHA256",
							value: LIVE.ledgerRecordSha256
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashBlock, {
							className: "mt-2",
							label: "HEAD_INDEX_LINE_SHA256",
							value: LIVE.ledgerHeadIndexLineSha256
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					kicker: "Dieses Gate",
					title: "Lokaler Zustand",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, { value: errors.length ? "FAIL_CLOSED" : records.length ? "PASS" : "HOLD" }),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
								label: "LOCAL_SEQUENCE",
								value: latest?.sequence ?? 0
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
								label: "RECORDS",
								value: records.length
							})]
						}),
						latest ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashBlock, {
							className: "mt-2",
							label: "HEAD SHA256",
							value: latest.record_sha256
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashBlock, {
							className: "mt-2",
							label: "HEAD INDEX LINE",
							value: latest.head_index_line_sha256
						})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "Noch kein lokaler Datensatz."
						}),
						errors.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 space-y-1",
							children: errors.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "font-mono text-[12px] text-rust",
								children: e
							}, e))
						}) : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				kicker: "Append",
				title: "Datensatz anfügen",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-1.5 font-mono text-[10px] tracking-[0.14em] text-subtle uppercase",
							children: "record_id"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: recordId,
							onChange: (e) => setRecordId(e.target.value)
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-end gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => void appendNote(),
									disabled: appending,
									children: "Anfügen"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "secondary",
									onClick: () => void sealStamp(),
									disabled: appending,
									children: "Grok-Stempel siegeln"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									onClick: resetLedger,
									children: "Zurücksetzen"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-3 block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-1.5 font-mono text-[10px] tracking-[0.14em] text-subtle uppercase",
							children: "source_locator / note"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							className: "min-h-24 font-sans",
							value: note,
							onChange: (e) => setNote(e.target.value)
						})]
					}),
					appendError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-rust",
						children: appendError
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs leading-relaxed text-subtle",
						children: "Browser-Ledger ist einzelprozessig serialisiert. Das beweist keine Crash-Atomizität und keine POSIX-flock-Semantik (LIM-01, LIM-12)."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				kicker: "Index",
				title: "records.jsonl",
				children: records.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Leer. Negative Evidenz: kein lokaler Head."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "space-y-3",
					children: records.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-md bg-inset p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "font-mono text-[12px] text-steel",
									children: [
										"#",
										r.entry.sequence,
										" · ",
										r.entry.record_type
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, { value: "C1" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 text-sm text-fg",
								children: r.entry.record_id
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashBlock, {
								className: "mt-2",
								value: r.entry.record_sha256
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 font-mono text-[11px] text-subtle",
								children: [
									r.entry.record_bytes,
									" B · ",
									r.entry.recorded_at_utc
								]
							})
						]
					}, r.entry.record_id))
				})
			})
		]
	});
}
//#endregion
export { LedgerPage as component };
