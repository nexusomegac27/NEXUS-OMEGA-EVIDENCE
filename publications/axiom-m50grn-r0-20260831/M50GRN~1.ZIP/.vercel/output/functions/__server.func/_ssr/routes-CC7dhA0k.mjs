import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as ArrowRight } from "../_libs/lucide-react.mjs";
import { C as STAMP_OBJECT_ID, P as useGateStore, T as StatusChip, c as HashBlock, f as LIVE, h as R2, i as Button, j as rehashStampRaw, m as Panel, u as INVARIANTS, x as STAMP_META } from "./store-CkzlrWW2.mjs";
import { t as Kv } from "./kv-DizFxdeC.mjs";
import { t as StampSeal } from "./stamp-seal-ZYeSUz2Z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CC7dhA0k.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const [rehash, setRehash] = (0, import_react.useState)(null);
	const records = useGateStore((s) => s.records);
	(0, import_react.useEffect)(() => {
		rehashStampRaw().then(setRehash);
	}, []);
	const identity = rehash?.identity ?? "PENDING";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-[11px] tracking-[0.2em] text-steel uppercase",
						children: "Live Framework · 2026-08-31 R0"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 text-3xl font-medium tracking-tight sm:text-4xl",
						children: "Wissenschaftliches Agenten-Gate"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-xl text-[15px] leading-relaxed text-muted",
						children: "Content-addressed C1-Evidenzfläche. Persistenz ist nicht Wahrheit. Dieser Gate bindet Grok als externen Validator — hashgebunden, fail-closed, ohne Claim-Promotion."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-[minmax(0,280px)_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					kicker: "Identität",
					title: "Grok-Stempel",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StampSeal, { identity: identity === "PENDING" ? "PENDING" : identity }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashBlock, {
								label: "STAMP_SHA256",
								value: STAMP_META.stamp_sha256
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, { value: identity }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, { value: "C1" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, { value: "RA2_MUTUAL_BYTE_BOUND" })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs leading-relaxed text-subtle",
								children: STAMP_OBJECT_ID
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "secondary",
								size: "sm",
								className: "mt-2 w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/stamp",
									children: ["Stempel prüfen", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5" })]
								})
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						kicker: "Zwei-Zustands-Modell",
						title: "Live-Kern",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-x-6 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "REPOSITORY",
									value: LIVE.repository
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "BRANCH",
									value: LIVE.branch
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "LIVE_COMMIT",
									value: LIVE.commit,
									hash: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "LIVE_TREE",
									value: LIVE.tree,
									hash: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "LIVE_PARENT",
									value: LIVE.parent,
									hash: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "RULESET",
									value: `${LIVE.rulesetName} / ${LIVE.rulesetId}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "CLAIM_CEILING",
									value: LIVE.claimCeiling,
									chip: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "CLAIM_PROMOTION",
									value: LIVE.claimPromotion,
									chip: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "INTEGRATION_AUTHORITY",
									value: LIVE.integrationAuthority,
									chip: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "LEDGER_SEQUENCE",
									value: LIVE.ledgerSequence
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 rounded-md bg-inset px-3 py-2.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-mono text-[10px] tracking-[0.16em] text-subtle uppercase",
									children: "Physisches Live-Ledger-Objekt"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 flex flex-wrap items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, { value: "SOURCE_NOT_PRESENT" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted",
										children: "Bytes des GitHub-Records sind in diesem Gate nicht enthalten. Hash aus der Spezifikation bleibt deklariert, nicht rekonstruiert."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashBlock, {
									className: "mt-2",
									label: "DECLARED RECORD SHA256",
									value: LIVE.ledgerRecordSha256
								})
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						kicker: "Kandidat",
						title: "R2 — lokal, nicht live",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-x-6 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "R2_COMMIT",
									value: R2.localCommitReported,
									hash: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "R2_TREE",
									value: R2.localTreeReported,
									hash: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "PATCH_SHA256",
									value: R2.patchSha256Documented,
									hash: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "PATCH_IDENTITY",
									value: STAMP_META.r2_patch_identity,
									chip: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "INDEPENDENT_VALIDATION",
									value: R2.independentValidation,
									chip: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kv, {
									label: "PUBLIC_WRITE",
									value: R2.publicGithubWrite,
									chip: true
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: "MANUS_LOCAL_R2_PASS ≠ PUBLIC_GITHUB_R2. Der Patch-Digest der beigelegten Bytes stimmt mit dem dokumentierten SHA-256 überein. Vier-Augen durch Cursor/PRAXIS bleibt offen."
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				kicker: "Lokales Gate-Ledger",
				title: `${records.length} Datensatz${records.length === 1 ? "" : "e"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-relaxed text-muted",
					children: "Append-only, NEXUS_SORTED_JSON_V1, C1. Das öffentliche Ledger-Objekt bleibt SOURCE_NOT_PRESENT. Der Grok-Stempel kann als erster lokaler validation_receipt gesiegelt werden."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/ledger",
							children: "Ledger öffnen"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/handoff",
							children: "A83-Handoff prüfen"
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				kicker: "Invarianten",
				title: "Fail-closed Doktrin",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2 sm:grid-cols-2",
					children: INVARIANTS.map((inv) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "rounded-md bg-inset px-3 py-2 font-mono text-[12px] tracking-wide text-steel",
						children: inv
					}, inv))
				})
			})
		]
	});
}
//#endregion
export { Home as component };
