import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as cn } from "./router-CUOx3VDb.mjs";
import { T as StatusChip, c as HashBlock } from "./store-CkzlrWW2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kv-DizFxdeC.js
var import_jsx_runtime = require_jsx_runtime();
function Kv({ label, value, hash = false, chip = false, className }) {
	const text = value === null ? "null" : typeof value === "boolean" ? value ? "TRUE" : "FALSE" : String(value);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("min-w-0 py-2.5", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-mono text-[10px] tracking-[0.16em] text-subtle uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 min-w-0",
			children: hash && typeof value === "string" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashBlock, { value }) : chip ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, { value }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "break-all font-mono text-[13px] leading-relaxed text-fg",
				children: text
			})
		})]
	});
}
//#endregion
export { Kv as t };
