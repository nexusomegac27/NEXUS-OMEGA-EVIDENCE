# NEXUS OMEGA
# GitHub Persistent Communication, Memory & Scientific Provenance Framework
## Live Framework Specification — 2026-08-31 R0

```text
OBJECT =
NEXUS_OMEGA_GITHUB_PERSISTENT_COMMUNICATION_MEMORY_PROVENANCE_FRAMEWORK_LIVE_20260831_R0

STATE =
LIVE_CORE_ESTABLISHED_WITH_LOCAL_R2_CANDIDATE_EXTENSION_PENDING_FOUR_EYES

REPOSITORY =
nexusomegac27/NEXUS-OMEGA-EVIDENCE

LIVE_DEFAULT_BRANCH =
main

LIVE_COMMIT =
bc312c4d2cd6afa579db1f077c88d8fe08fc9470

LIVE_TREE =
c8856faa74efa5770717d2d44dc7d51e4269cb22

LIVE_PARENT =
bb1f3fd88db79d295077062895574c6d90b390bf

LIVE_COMMIT_SIGNATURE =
GITHUB_VERIFIED_VALID

LIVE_RULESET_ID =
21252293

LIVE_RULESET_NAME =
main-evidence-protection

LIVE_RULESET_ENFORCEMENT =
active

LEDGER_SEQUENCE =
1

LEDGER_RECORD_SHA256 =
1cdfcc74319f6f8500d969e8345ce5b6e1e6298482e03b6c96881cbbbd99dece

LEDGER_HEAD_INDEX_LINE_SHA256 =
d4b9ea8838d393776608833257a43970c2249a3bcd8ecb65ec89d6d018d8660f

CLAIM =
C1_DESCRIPTIVE_ONLY

CLAIM_CEILING =
C1

CLAIM_PROMOTION =
FALSE

FOUNDATION_PROMOTION =
FALSE

DEPLOYMENT_AUTHORITY =
NO

INTEGRATION_AUTHORITY =
NONE

AUTO_FOLLOW_ON =
NO
```

---

# 1. Purpose

This document defines the complete working framework for the NEXUS OMEGA GitHub communication interface at the current live state.

The framework is simultaneously:

1. a durable cross-session memory surface;
2. a public scientific-provenance surface;
3. a machine-readable handoff system between Operator, AXIOM, Cursor/PRAXIS and external agents;
4. a content-addressed evidence and communication ledger;
5. a fail-closed validation layer;
6. a causal correction and supersession system;
7. a GitHub-native transport layer;
8. a research-interface foundation for all later work in this branch.

It is not a scientific truth engine.

```text
PERSISTENCE != TRUTH
HASH_IDENTITY != SEMANTIC_VALIDITY
SIGNATURE != SCIENTIFIC_VALIDITY
CI_PASS != CLAIM_PROMOTION
AGENT_AGREEMENT != EVIDENCE
PUBLICATION != AUTHORITY
```

The framework is considered complete here as a **specification of the current system and its lawful evolution path**.

It is not claimed that every robustness, distributed-systems, security, archival, semantic, or external-witness problem has already been solved.

```text
FRAMEWORK_SPECIFICATION_COMPLETE
!=
IMPLEMENTATION_ROBUSTNESS_COMPLETE
```

---

# 2. Two-state model: Live Core vs Candidate Extension

The framework MUST distinguish the public live state from unpublished research/remediation candidates.

## 2.1 LIVE CORE

The authoritative current public source is:

```text
main@bc312c4d2cd6afa579db1f077c88d8fe08fc9470
TREE=c8856faa74efa5770717d2d44dc7d51e4269cb22
PARENT=bb1f3fd88db79d295077062895574c6d90b390bf
```

All statements about what is currently implemented on GitHub resolve to this exact source unless a later immutable public commit is independently established.

## 2.2 LOCAL R2 CANDIDATE EXTENSION

MANUS reported a local Fresh-R2 remediation candidate:

```text
R2_LOCAL_COMMIT_REPORTED =
dc4bb1067fdf0ad1914349a244a64abd7f3fc715

R2_LOCAL_TREE_REPORTED =
128683d0b27a1cd99ca2a2f89b89c551eeb00ffd

R2_PARENT_REPORTED =
bc312c4d2cd6afa579db1f077c88d8fe08fc9470

R2_STATE_REPORTED =
PASS_LOCAL_R2_REMEDIATION_WITH_CAVEATS_C1
```

This R2 state is **not** part of the public live framework yet.

Its reported changes target:

- local POSIX multiwriter ledger serialization;
- actual Handoff payload length/SHA-256 validation;
- associated regression/adversarial tests and distinct R2 artifact binding.

It remains subject to independent Cursor/PRAXIS four-eyes validation.

```text
MANUS_LOCAL_R2_PASS
!=
PUBLIC_GITHUB_R2

MANUS_LOCAL_R2_PASS
!=
INDEPENDENT_R2_VALIDATION

R2_PUBLICATION =
NOT_AUTHORIZED_BY_THIS_FRAMEWORK
```

---

# 3. Constitutional authority model

Authority is explicit and non-transitive.

| Actor | Function | May produce evidence? | May validate independently? | May mutate repository? | May promote claims? |
|---|---|---:|---:|---:|---:|
| Operator Alexander | Human authority root | Yes | Yes | Yes, explicitly | Only through separate governed process |
| AXIOM | Epistemic audit/adjudication | Yes | Yes | Only when explicitly authorized | No automatic promotion |
| Cursor / PRAXIS | Operational implementation and VM validation | Yes | Yes when independent of producer | Only when explicitly authorized | No automatic promotion |
| External agents | Research, critique, validation, candidate implementation | Yes | Yes when structurally independent | No unless explicitly granted narrow write authority | No |
| GitHub / CI / Rulesets | Transport and enforcement infrastructure | Emits platform evidence | Mechanical only | Platform-controlled | No |

Core law:

```text
ROLE_LABEL != CORRECTNESS
PRODUCER_RETURN != INDEPENDENT_VALIDATION
VALIDATOR_PASS != CLAIM_PROMOTION
```

A research agent may produce a candidate.

A different competent validator must inspect the actual bytes before independent validation can exist.

---

# 4. Evidence hierarchy

When multiple sources conflict, use this order:

```text
E0 = VERIFIED PHYSICAL / RETRIEVABLE BYTES
E1 = IMMUTABLE PUBLIC GIT OBJECT / CONTENT-ADDRESSED OBJECT
E2 = INDEPENDENT BYTE-BOUND RECEIPT OR WITNESS
E3 = REPOSITORY HANDOFF / STATUS OBJECT WITH EXPLICIT EPISTEMIC CLASS
E4 = OPERATOR / CHAT REPORT
E5 = MODEL PRIOR KNOWLEDGE / INFERENCE
```

Higher levels may be used to locate lower levels, but may not substitute for them.

```text
CHAT = TRANSPORT / INTENT / LOCATOR
CHAT != BYTE PROVENANCE
```

If required evidence is absent:

```text
SOURCE_NOT_PRESENT
NOT_ESTABLISHED
NOT_COMPUTABLE
```

are valid terminal states.

Missing bytes are never reconstructed and relabeled as historical originals.

---

# 5. Core scientific invariants

The entire interface is governed by the following invariants:

```text
CLAIM_CEILING = C1

HASH_MATCH != SCIENTIFIC_VALIDITY
PUBLICATION != TRUTH
AGENT_CONSENSUS != TRUTH
IDENTITY_MATCH != CONTENT_VALIDATION
FORMAL_MODEL_FIT != OPERATIONAL_VALIDATION
VALIDATION != PROMOTION

BLOCKED_LANE != BLOCKED_SYSTEM

NO_STEALTH_NETWORK_TESTING
NO_INVENTED_PROVENANCE
NO_POST_HOC_RELABELING
NO_SILENT_HISTORY_REWRITE
NO_SOURCE_OBJECT_SUBSTITUTION
```

Negative evidence is first-class evidence.

A correction does not delete the past.

A later implementation does not retroactively invalidate a historically correct negative witness.

---

# 6. Framework architecture

The live framework is organized as layered infrastructure.

## L0 — Public discovery layer

Primary surfaces:

```text
README.md
index.md
CITATION.cff
SECURITY.md
```

Purpose:

- human discoverability;
- repository mission;
- citation;
- public-safe entry;
- security boundary.

A mutable discovery pointer may aid navigation but must not replace immutable commit references for scientific verification.

---

## L1 — Agent bootstrap and persistent repository memory

Primary surfaces:

```text
AGENTS.md
GOVERNANCE.md
.github/copilot-instructions.md
docs/AI_CONTEXT.md
docs/agent-protocol.md
```

`AGENTS.md` defines standing instructions.

`docs/AI_CONTEXT.md` defines persistent public-safe AI context.

This is the system's durable **repository memory**.

It is explicitly not hidden conversational memory.

```text
REPOSITORY_MEMORY =
DURABLE_INSPECTABLE_CONTEXT

REPOSITORY_MEMORY != SCIENTIFIC_EVIDENCE_BY_PRESENCE
MODEL_HIDDEN_MEMORY != CANONICAL_STATE
```

A new agent/session should bootstrap from repository state before relying on chat history.

---

## L2 — Authority and governance layer

Primary surfaces:

```text
GOVERNANCE.md
AGENTS.md
docs/AI_CONTEXT.md
SECURITY.md
CODEOWNERS where applicable
GitHub Rulesets
```

Responsibilities:

- define authority;
- separate producer/validator;
- limit claims;
- limit mutation;
- define privacy/publication exclusions;
- preserve lane-scoped holds;
- prevent automatic promotion.

---

## L3 — Causal Handoff layer

Primary surface:

```text
docs/AI_HANDOFF_PROTOCOL.md
schema/A83_handoff_envelope_v1.schema.json
scripts/validate_a83_handoff.py
examples/a83/handoff-envelope-v1.example.json
```

Every material transfer should answer:

```text
OBJECT
STATE
DATE_UTC
FROM
TO
AUTHORITY
CLAIM
CLAIM_CEILING
PREDECESSOR_OBJECT
PHYSICAL_INPUTS
INPUT_REHASH
WORK_EXECUTED
WORK_NOT_EXECUTED
EVIDENCE_STATUS
UNCERTAINTY
CLAIM_PROMOTION
INTEGRATION_AUTHORITY
AUTO_FOLLOW_ON
NEXT_ACTION
```

Material physical artifacts additionally require:

```text
FILENAME
BYTES
SHA256
PHYSICAL_EXPOSURE
```

The receiver independently recomputes byte count and SHA-256.

---

## L4 — Scientific communication semantics

Primary surface:

```text
docs/OPEN_SCIENCE_AGENT_COMMUNICATION_MANIFEST.md
docs/SCIENTIFIC_COMMUNICATION_IMPLEMENTATION_PROFILE_V0_1.md
```

The model separates three orthogonal dimensions.

### Observability

```text
OBS0_UNOBSERVABLE
OBS1_PROVIDER_AGGREGATE
OBS2_PROVIDER_EVENT
OBS3_MEDIATED_EVENT
OBS4_MUTUAL_RECEIPT
```

### Receipt assurance

```text
RA0_NONE
RA1_SELF_ASSERTED
RA2_MUTUAL_BYTE_BOUND
RA3_AUTHENTICATED_PLATFORM
RA4_SIGNED_OR_TIMESTAMPED
RA5_EXTERNAL_TRANSPARENCY_WITNESS
```

### Scientific relevance

```text
SR0_OPERATIONAL
SR1_PROVENANCE_SUPPORT
SR2_PROCESS_EVENT
SR3_CLAIM_EVIDENCE
SR4_GOVERNANCE_VALIDATION
SR5_SECURITY_INTEGRITY
```

Hard rule:

```text
OBSERVABILITY
!=
RECEIPT_ASSURANCE
!=
SCIENTIFIC_RELEVANCE
```

A high RA class cannot transform weak science into strong science.

A high OBS class cannot create scientific truth.

---

# 7. Communication record model

Canonical v1 record types include:

```text
event
session
access_receipt
communication_receipt
claim_evidence_link
validation_receipt
correction
checkpoint
observability_snapshot
```

Every record must be:

- versioned;
- strictly typed;
- bounded by C1;
- explicit about observability;
- explicit about receipt assurance;
- explicit about scientific relevance;
- explicit about uncertainty;
- explicit about provenance.

Unknown-field behavior is schema-governed and fail-closed where specified.

---

# 8. Content addressing

When exact bytes exist, a record may bind:

```text
BYTES
SHA256
MEDIA_TYPE
CANONICAL_LOCATOR
PARENT_DIGESTS
OPTIONAL_EXTERNAL_WITNESS
```

SHA-256 proves byte identity under the assumed hash function.

It does not prove:

- authorship;
- time of creation;
- scientific truth;
- authority;
- legitimacy;
- causation.

Git object identifiers and scientific SHA-256 digests are distinct namespaces.

```text
GIT_BLOB_ID != CONTENT_SHA256
```

Both may be recorded.

---

# 9. Canonicalization

The current ledger implementation uses:

```text
NEXUS_SORTED_JSON_V1
```

This is a repository-defined deterministic JSON serialization convention.

It is **not** full RFC 8785 JCS.

The manifest identifies RFC 8785 as a target interoperability standard, but conformance may only be claimed when a conforming implementation is actually used and tested.

Future cross-language work must distinguish:

```text
CURRENT =
NEXUS_SORTED_JSON_V1

TARGET_INTEROPERABILITY =
RFC8785_JCS

CURRENT_RFC8785_CONFORMANCE =
NOT_ESTABLISHED
```

---

# 10. Content-addressed communication ledger

Live paths:

```text
communication/objects/sha256/
communication/index/v1/records.jsonl
communication/index/v1/latest.json
```

Current public live head:

```text
SEQUENCE =
1

RECORD_ID =
event:github-pr2-merge:20260830

RECORD_BYTES =
973

RECORD_SHA256 =
1cdfcc74319f6f8500d969e8345ce5b6e1e6298482e03b6c96881cbbbd99dece

HEAD_INDEX_LINE_SHA256 =
d4b9ea8838d393776608833257a43970c2249a3bcd8ecb65ec89d6d018d8660f

INDEX_SERIALIZATION =
NEXUS_SORTED_JSON_V1
```

The ledger separates:

1. content object;
2. causal/index record;
3. latest head pointer.

The index is append-only.

Corrections and retractions create new records.

They do not mutate historical source objects.

---

# 11. Ledger state transition

The intended logical append transaction is:

```text
VALIDATE_SOURCE_RECORD
→ VALIDATE_CURRENT_LEDGER
→ READ_CURRENT_HEAD
→ REJECT_DUPLICATE_ID
→ COMPUTE_CONTENT_SHA256
→ DERIVE_CONTENT_PATH
→ DERIVE_NEXT_SEQUENCE
→ DERIVE_PREVIOUS_INDEX_HASH
→ CREATE_CANONICAL_INDEX_LINE
→ WRITE_CONTENT_OBJECT
→ WRITE_INDEX
→ WRITE_LATEST
→ POST_VALIDATE
```

The current public `main@bc312c4...` implementation is mechanically valid for the current single-record state.

Phase-3 adversarial testing identified a concurrency weakness in the live-base append implementation: concurrent writers can derive state from the same prior head because the full read/derive/write sequence is not serialized.

That live-base weakness remains part of the current public framework until a validated remediation is publicly integrated.

The MANUS Fresh-R2 candidate reports a local POSIX `flock` remediation, but that is not yet live.

---

# 12. Corrections, retractions and supersession

Correction is append-only.

Permitted evidence-state vocabulary includes:

```text
SUPPORTED
COUNTERED
MIXED
NOT_ESTABLISHED
NOT_COMPUTABLE
RETRACTED
SUPERSEDED
```

A correction object should bind:

```text
CORRECTION_ID
PREDECESSOR_RECORD_ID
PREDECESSOR_SHA256
REASON
CORRECTED_ASSERTION
NEW_EVIDENCE
TIMESTAMP
ACTOR
CLAIM_CEILING
```

Historical negative evidence must remain preserved.

The A84 negative witness is an example of correct causal preservation:

```text
A84_AT_PARENT =
A83_ARTIFACTS_ABSENT
→ C1.2_CLOSED

LATER_A83_IMPLEMENTATION =
NEW_STATE

LATER_A83_IMPLEMENTATION
!=
RETROACTIVE_INVALIDATION_OF_A84
```

---

# 13. Fail-closed validation layer

Primary surfaces:

```text
scripts/
validation/
tests/
schema/
```

The framework uses:

- JSON schema constraints;
- semantic validators;
- negative fixtures;
- ledger validators;
- artifact-binding validators;
- deterministic structural sentinel;
- reproduction scripts;
- unit/integration tests.

A passing test suite means only that the tested implementation satisfies the tested predicates.

```text
TEST_PASS != UNIVERSAL_CORRECTNESS
```

---

# 14. Scientific communication negative fixtures

The current framework contains 43 scientific-communication negative fixtures.

They cover semantic confusions such as:

- anonymous access represented as identified;
- provider aggregate represented as complete access history;
- hash represented as timestamp;
- hash represented as identity proof;
- signature represented as scientific truth;
- missing source bytes reconstructed from chat;
- popularity/access metrics used for claim promotion;
- watch events used as authority;
- truncated communication represented as complete.

These fixtures are part of the framework's regression memory.

They represent previously identified failure modes that later changes must not reintroduce.

---

# 15. A83 structural hardening layer

A83 adds a ledger-bound handoff structure with:

```text
schema/A83_handoff_envelope_v1.schema.json
scripts/validate_a83_handoff.py
scripts/a83_sentinel.py
scripts/a83_decision.py
scripts/reproduce_a83.py
scripts/verify_a83_artifact_binding.py
tests/test_a83_handoff.py
validation/a83-handoff-negative-fixtures-v1.jsonl
validation/A83_ARTIFACT_BINDING_v1.0.json
validation/A83_WEAKNESS_AND_OPEN_QUESTIONS_AUDIT_v1.0.json
validation/A83_FINAL_STATUS_v1.0.json
```

A83 enforces structural boundaries including:

```text
claim_ceiling = C1
claim_promotion = false
integration_authority = NONE
auto_execute = false
network_write = false
sunset_months >= 12
valid OBS / RA / SR classes
valid roles
ledger parent binding when root is supplied
```

The A83 decision ceiling is:

```text
C1.1_ARTIFACT_VALIDATED_STRUCTURE_ONLY
```

It is not scientific claim promotion.

---

# 16. A83 deterministic sentinel

The sentinel is a deterministic pattern tripwire.

It is not a semantic adjudicator.

Known/confirmed limitations include:

- Unicode homoglyph bypass;
- zero-width/normalization issues;
- paraphrase bypass;
- semantic-equivalent bypass;
- negation/context false positives.

Therefore:

```text
A83_SENTINEL =
STRUCTURAL_PATTERN_GUARDRAIL_ONLY

A83_SENTINEL != SEMANTIC_TRUTH_ENGINE
A83_SENTINEL != GENERAL_POLICY_REASONER
```

Research may improve normalization and regression coverage without changing this epistemic boundary.

---

# 17. A83 payload-binding live-base gap

The live-base `validate_a83_handoff.py` checks that envelope fields `payload_sha256` and `payload_bytes` have valid forms.

At `main@bc312c4...`, it does not independently recompute the physical supplied payload's actual SHA-256 and byte length.

Therefore the current public live state must retain:

```text
ACTUAL_PAYLOAD_TO_ENVELOPE_BYTE_BINDING =
INCOMPLETE_IN_LIVE_BASE
```

MANUS Fresh-R2 reports a local remediation.

That remediation remains candidate evidence pending independent Cursor validation and later governed publication.

---

# 18. GitHub as persistent transport and memory surface

GitHub provides several distinct functions.

## Git commit/tree

Provides immutable repository object identity.

## Branch

Provides mutable discovery and current-state pointer.

## Pull request

Provides review and change-transport context.

## Actions

Provides mechanical execution/check evidence.

## Ruleset

Provides platform-level branch policy enforcement.

## Pages / README

Provide discoverability.

## Release / external archive

May provide additional publication and archival binding when separately authorized.

No GitHub primitive automatically creates scientific truth.

---

# 19. Live branch and ruleset state

At the current live observation:

```text
BRANCH =
main

HEAD =
bc312c4d2cd6afa579db1f077c88d8fe08fc9470

GITHUB_BRANCH_PROTECTED_FLAG =
true
```

The legacy branch-protection object reports no classic protection configuration, but a repository Ruleset is active.

```text
RULESET_ID =
21252293

RULESET_NAME =
main-evidence-protection

TARGET =
refs/heads/main

ENFORCEMENT =
active

BYPASS_ACTORS =
none
```

Rules include:

```text
deletion protection
non-fast-forward protection
required linear history
pull request requirement
required status checks
required signatures
```

Therefore:

```text
LEGACY_BRANCH_PROTECTION_ENDPOINT_STATE
!=
TOTAL_GITHUB_PROTECTION_STATE
```

A legacy `404` or disabled classic protection configuration must not be used alone to conclude that `main` is unprotected.

---

# 20. CI validation layer

The current framework has four validation workflows:

```text
validate-anchor
validate-scientific-communication
validate-scientific-ledger
validate-a83-framework-hardening
```

They provide separate logical validation lanes.

However, the jobs use the shared job/check context:

```text
validate
```

The active Ruleset currently requires:

```text
required_status_check.context = validate
```

Therefore the framework distinguishes:

```text
FOUR_LOGICAL_CI_WORKFLOWS =
ESTABLISHED

FOUR_DISTINCT_PLATFORM_REQUIRED_CHECK_IDENTITIES =
NOT_ESTABLISHED
```

The research target is to determine or implement unambiguous check identities so the platform can enforce all intended gates independently.

Until then:

```text
MAIN_TECHNICAL_PROTECTION = PRESENT

FOUR_DISTINCT_CI_GATES_PLATFORM_ENFORCED =
NOT_ESTABLISHED
```

These are not contradictory statements.

---

# 21. CI scientific boundary

CI may establish:

- code compiled;
- tests ran;
- fixtures behaved as expected;
- schemas parsed/validated where implemented;
- artifacts matched bindings;
- ledger validator passed.

CI does not establish:

- scientific truth;
- causal validity;
- canonical promotion;
- foundation status;
- authority;
- complete robustness against untested adversaries.

---

# 22. Persistent memory architecture

The communication framework acts as a multi-layer memory system.

## M0 — Bootstrap memory

```text
AGENTS.md
GOVERNANCE.md
docs/AI_CONTEXT.md
```

Stores stable role, doctrine and session-bootstrap context.

## M1 — Protocol memory

```text
docs/AI_HANDOFF_PROTOCOL.md
docs/agent-protocol.md
manifest/profile docs
schemas
```

Stores how the system communicates.

## M2 — Event memory

```text
communication/objects/sha256/
communication/index/v1/records.jsonl
```

Stores content-addressed events and causal ordering.

## M3 — Head/checkpoint memory

```text
communication/index/v1/latest.json
checkpoint records
```

Stores current pointer state.

## M4 — Validation memory

```text
validation/
tests/
```

Stores failure modes, fixtures, historical regressions and known limits.

## M5 — Git history memory

```text
commit
tree
branch
PR
Actions
Ruleset
```

Stores public transport and repository evolution.

## M6 — External-review memory

Byte-bound returns, handshakes, package receipts and independent validation artifacts remain separate evidence objects and may later be published after governance gates.

---

# 23. Session bootstrap protocol

Every new AI session working on this branch should perform:

```text
1. FETCH repository metadata
2. FETCH main HEAD
3. VERIFY exact commit/tree
4. READ AGENTS.md
5. READ GOVERNANCE.md
6. READ docs/AI_CONTEXT.md
7. READ docs/agent-protocol.md
8. READ docs/AI_HANDOFF_PROTOCOL.md
9. RESOLVE relevant latest ledger/checkpoint
10. IDENTIFY latest applicable handoff
11. CLASSIFY operator/chat-only deltas as OPERATOR_REPORTED
12. CONTINUE only from byte-bound predecessor
```

No hidden-chat continuity may replace this procedure.

---

# 24. Material handoff lifecycle

The canonical lifecycle is:

```text
CREATE
→ CLOSE
→ READ_BACK
→ BYTE_COUNT
→ SHA256
→ EXPOSE_PHYSICAL_OBJECT
→ RECEIVER_CONFIRMS_PRESENCE
→ RECEIVER_REHASH
→ SEMANTIC_VALIDATION
→ INDEPENDENT_VALIDATION IF REQUIRED
→ GOVERNED NEXT ACTION
```

Terminal success before physical exposure is prohibited for material artifacts.

If an ephemeral environment destroys the bytes before receiver confirmation:

```text
STATE =
SOURCE_NOT_PRESENT
or
HOLD_RETURN_TRANSPORT_NOT_ESTABLISHED
```

The historical file must not be reconstructed and mislabeled as original.

---

# 25. Research object lifecycle

Every future research unit in this branch should be representable as:

```text
DISCOVERY
→ SOURCE_INTAKE
→ SOURCE_BIND
→ CLAIM_EXTRACTION
→ CLAIM_CLASSIFICATION
→ COUNTEREVIDENCE
→ EXPERIMENT / VALIDATION
→ RETURN
→ INDEPENDENT_REVIEW
→ CORRECTION / ACCEPTANCE
→ GOVERNED PUBLICATION
→ OPTIONAL EXTERNAL WITNESS
→ CHECKPOINT
```

Each arrow must state:

```text
WHAT_CHANGED
WHAT_WAS_PROVEN
WHAT_WAS_NOT_PROVEN
WHICH_BYTES_BIND_THE_STEP
WHO_AUTHORIZED_THE_NEXT_STEP
```

---

# 26. Required research package contract

A substantial research package should contain at least:

```text
OBJECT_ID
RUN_ID
PREDECESSOR_OBJECT
SOURCE_COMMIT_OR_SOURCE_OBJECT
SOURCE_FILES
SOURCE_BYTES
SOURCE_SHA256
CLAIM_CEILING
RESEARCH_QUESTION
HYPOTHESES
METHOD
NEGATIVE_CONTROLS
COUNTEREVIDENCE
RESULTS
UNCERTAINTY
NOT_COMPUTABLE_ITEMS
PRODUCER
VALIDATOR
VALIDATION_STATUS
PUBLICATION_STATUS
NEXT_ACTION
```

For code changes additionally:

```text
BASE_COMMIT
BASE_TREE
BRANCH
PATCH
PATCH_SHA256
CHANGED_FILE_INVENTORY
RESULTING_TREE
TEST_ENVIRONMENT
TEST_COMMANDS
TEST_RESULTS
```

---

# 27. Research branch protocol

Nontrivial changes should follow:

```text
PUBLIC IMMUTABLE BASE
→ FRESH RESEARCH / IMPLEMENTATION BRANCH
→ LOCAL TESTS
→ PHYSICAL RETURN
→ AXIOM REHASH / ADJUDICATION
→ CURSOR FOUR-EYES VM VALIDATION
→ SEPARATE PUBLICATION DECISION
→ REMOTE BRANCH
→ PR
→ CI
→ OPERATOR DISPOSITION
→ MERGE ONLY IF AUTHORIZED
→ POST-MERGE REVALIDATION
```

No stage inherits authority from the prior stage.

A local test pass does not authorize a push.

A push does not authorize a PR.

A PR pass does not authorize a merge.

A merge does not authorize scientific promotion.

---

# 28. Phase-3 MANUS lessons incorporated into the framework

Phase 3 established several framework-level lessons.

## 28.1 Review-body discoverability

A public repository may be independently discoverable while an external frozen review package remains outside the repository.

Therefore the system must distinguish:

```text
LIVE_SOURCE_TARGET
from
FROZEN_REVIEW_BODY
```

A reviewer must never invent the review body.

## 28.2 Source-object identity

Transport receipt and package receipt are distinct objects.

Content similarity does not permit substitution.

## 28.3 Lost return handling

If an exact required return is absent:

```text
SOURCE_NOT_PRESENT
```

A new run receives a new identity.

## 28.4 Ruleset-aware protection analysis

Classic branch protection and repository Rulesets are separate GitHub enforcement surfaces.

Reviewers must inspect both.

## 28.5 Producer remediation is not independent validation

MANUS Fresh-R2 may produce and self-test remediation.

Cursor/PRAXIS must still independently attempt to break it.

---

# 29. Current MANUS Fresh-R2 candidate

MANUS reports the following local candidate result:

```text
STATE =
PASS_LOCAL_R2_REMEDIATION_WITH_CAVEATS_C1

BASE =
bc312c4d2cd6afa579db1f077c88d8fe08fc9470

R2_LOCAL_COMMIT =
dc4bb1067fdf0ad1914349a244a64abd7f3fc715

R2_LOCAL_TREE =
128683d0b27a1cd99ca2a2f89b89c551eeb00ffd

PUBLIC_GITHUB_WRITE =
NO

INDEPENDENT_POST_REMEDIATION_VALIDATION =
NOT_YET_EXECUTED
```

Reported results include:

```text
H1_BASE_MULTIWRITER_DEFECT = REPRODUCED
H2_BASE_PAYLOAD_BINDING_DEFECT = REPRODUCED

R2_DUAL_WRITER = 5/5 PASS
R2_TRIPLE_WRITER = 5/5 PASS
R2_TESTS = 19 PASS
COMMUNICATION_FIXTURES = 43 PASS
DRAFT_2020_12_SCHEMAS = 4 PASS
```

These remain:

```text
MANUS_REPORTED_LOCAL_EVIDENCE
```

until independently reproduced by Cursor/PRAXIS.

---

# 30. Mandatory R2 four-eyes questions

Independent validation must test at least:

### Ledger concurrency

```text
20 dual-writer trials
20 triple-writer trials
randomized start jitter
lock release on exception
retry after failed writer
orphan detection
head consistency
sequence monotonicity
```

### Crash consistency

Serialization is not the same as transaction atomicity.

```text
CONCURRENT_SERIALIZATION != CRASH_ATOMICITY
```

A process death between multi-file writes may remain a separate limitation.

### Payload binding

The validator must distinguish:

```text
PHYSICAL_FILE_BYTES
from
DECODED_AND_REENCODED_TEXT
```

Tests must include:

```text
LF
CRLF
UTF8_BOM
NFC
NFD
NON_ASCII
TRAILING_NEWLINE
NO_TRAILING_NEWLINE
```

Only exact physical-byte hashing supports a physical-byte-binding claim.

---

# 31. Privacy, security and rights

The public communication framework must minimize data.

Do not publish:

- credentials;
- secrets;
- private keys;
- private medical information;
- private conversations;
- unnecessary personal identifiers;
- non-public repository material;
- rights-uncleared third-party full text.

Permitted public modes include:

```text
PUBLIC_FULL_TEXT
PUBLIC_REDACTED_TEXT
HASH_ONLY_PUBLIC_PRIVATE_PAYLOAD
METADATA_ONLY
WITHHELD
```

Hashing sensitive low-entropy data is not automatically privacy-preserving.

---

# 32. Access observability

Public GitHub access does not provide a complete anonymous per-reader event history.

Therefore:

```text
NO_RECEIPT != NO_ACCESS
UNOBSERVABLE != ZERO
PROVIDER_AGGREGATE != INDIVIDUAL_EVENT
```

Access claims must remain within the actual observability path.

The interface must never claim complete individual public-reader telemetry unless the exact path provides it.

---

# 33. External witnessing

Optional future assurance layers may include:

```text
Sigstore / Rekor
SCITT-compatible transparency
RFC 3161 timestamping
Software Heritage
immutable releases
Zenodo / DOI archival
RO-Crate packaging
```

These are additive.

They may strengthen provenance, persistence, discoverability or timestamp/signature assurance.

They cannot promote scientific claims.

Witness failure must degrade assurance, not erase the underlying record.

---

# 34. Split-architecture target

The long-term preferred topology remains separated failure domains:

```text
EVIDENCE_REPOSITORY
+
COMMUNICATION / PROVENANCE PROTOCOL SURFACE
+
OPTIONAL EXTERNAL WITNESS / ARCHIVE
```

The present repository co-locates evidence and communication/provenance namespaces as a bootstrap implementation.

Current co-location is not evidence that a single repository is the optimal final topology.

Research should continue evaluating:

- independent failure domains;
- archival durability;
- governance complexity;
- discoverability;
- machine consumption;
- cross-repository digest bindings.

---

# 35. Current open limitations register

At the current live state:

```text
LIM-01 =
LIVE LEDGER MULTIWRITER SERIALIZATION NOT PRESENT ON PUBLIC MAIN

LIM-02 =
LIVE A83 ACTUAL PAYLOAD BYTE BINDING INCOMPLETE

LIM-03 =
FOUR DISTINCT CI GATES PLATFORM ENFORCEMENT NOT ESTABLISHED

LIM-04 =
SENTINEL IS REGEX/PATTERN GUARDRAIL, NOT SEMANTIC ENGINE

LIM-05 =
TEST DEPENDENCY VERSION-PINNED BUT NOT FULLY HASH/TRANSITIVE LOCKED

LIM-06 =
DRAFT-2020-12 INDEPENDENT SCHEMA VALIDATION NOT FULLY ESTABLISHED AS CONTINUOUS CI GATE

LIM-07 =
PUBLIC COMMUNICATION LEDGER HAS ONLY ONE REAL RECORD

LIM-08 =
LONG-TERM MULTI-ACTOR / MULTIWRITER ROBUSTNESS NOT ESTABLISHED

LIM-09 =
EXTERNAL TRANSPARENCY WITNESS NOT ACTIVE/ESTABLISHED

LIM-10 =
RFC8785 JCS CONFORMANCE NOT ESTABLISHED

LIM-11 =
DISTRIBUTED LOCK / NFS / MULTI-HOST SAFETY NOT ESTABLISHED

LIM-12 =
CRASH-ATOMIC MULTI-FILE LEDGER APPEND NOT ESTABLISHED

LIM-13 =
R2 REMEDIATION IS LOCAL AND NOT YET INDEPENDENTLY FOUR-EYES VALIDATED

LIM-14 =
R2 IS NOT PUBLIC AND NOT PART OF LIVE MAIN
```

These limits are part of the framework, not exceptions to it.

---

# 36. Required epistemic status vocabulary

Use exact or equivalently bounded states:

```text
MATCH
MISMATCH
SOURCE_NOT_PRESENT
NOT_ESTABLISHED
NOT_COMPUTABLE
PASS
PASS_WITH_CAVEATS
FAIL_MAJOR
HARD_FAIL
HOLD
OPERATOR_REPORTED
AXIOM_VERIFIED
EXTERNALLY_VALIDATED
RETRACTED
SUPERSEDED
```

Never substitute a stronger state for a weaker evidenced state.

---

# 37. Hard-fail conditions

The framework treats at least the following as hard failures when material:

```text
BOUND_ARTIFACT_HASH_MISMATCH
SOURCE_OBJECT_SUBSTITUTION
RECONSTRUCTED_MISSING_ORIGINAL_PRESENTED_AS_ORIGINAL
CLAIM_PROMOTION_PATH_WITHOUT_AUTHORITY
HISTORICAL_EVIDENCE_SILENT_REWRITE
INVENTED_HASH_OR_BYTE_COUNT
INVENTED_ACCESS_EVENT
INVALID_PARENT_BIND
UNAUTHORIZED_PUBLIC_WRITE
UNAUTHORIZED_MAIN_MUTATION
UNAUTHORIZED_FORCE_PUSH
```

A hard fail in one lane does not automatically stop unrelated lawful lanes.

---

# 38. Fundamental research-interface rule

All future research in this Git-communication branch should begin from this equation:

```text
RESEARCH_VALUE =
SOURCE_EXACTNESS
× FALSIFIABILITY
× PROVENANCE
× REPRODUCIBILITY
× INDEPENDENT_REVIEW
```

No amount of fluent narrative compensates for a zero in source identity.

No amount of hash integrity compensates for a zero in scientific validity.

---

# 39. Canonical dataflow

The complete communication flow is:

```text
HUMAN / AGENT INTENT
        ↓
AUTHORITY CLASSIFICATION
        ↓
SOURCE DISCOVERY
        ↓
PHYSICAL SOURCE BIND
        ↓
OBS / RA / SR CLASSIFICATION
        ↓
SCHEMA VALIDATION
        ↓
SEMANTIC VALIDATION
        ↓
CONTENT SHA256
        ↓
CONTENT-ADDRESSED OBJECT
        ↓
LEDGER INDEX ENTRY
        ↓
LATEST / CHECKPOINT
        ↓
HANDOFF OBJECT
        ↓
RECEIVER REHASH
        ↓
INDEPENDENT VALIDATION WHERE REQUIRED
        ↓
CORRECTION / ACCEPTANCE
        ↓
BRANCH / PR
        ↓
CI
        ↓
RULESET / OPERATOR GATE
        ↓
MERGE IF AUTHORIZED
        ↓
POST-MERGE REVALIDATION
        ↓
OPTIONAL EXTERNAL WITNESS
        ↓
NEXT CHECKPOINT
```

At every arrow, authority and epistemic state must be explicit.

---

# 40. Framework API concept

The logical interface exposed to humans and agents consists of the following operations:

```text
DISCOVER_STATE()
FETCH_OBJECT(id_or_locator)
VERIFY_BYTES(bytes, sha256)
CLASSIFY_OBSERVABILITY()
CLASSIFY_RECEIPT_ASSURANCE()
CLASSIFY_SCIENTIFIC_RELEVANCE()
VALIDATE_SCHEMA()
VALIDATE_SEMANTICS()
APPEND_RECORD()
READ_LEDGER_HEAD()
CREATE_HANDOFF()
VERIFY_HANDOFF()
CREATE_CORRECTION()
CREATE_CHECKPOINT()
RUN_NEGATIVE_FIXTURES()
REQUEST_INDEPENDENT_VALIDATION()
PREPARE_BRANCH()
RUN_CI()
REQUEST_OPERATOR_DISPOSITION()
OPTIONAL_EXTERNAL_WITNESS()
```

These are logical protocol operations, not claims that a single network API endpoint currently implements all of them.

---

# 41. Machine-readable minimum handoff contract for future research

```text
OBJECT =
<stable-id>

STATE =
<bounded-state>

DATE_UTC =
<timestamp-or-NOT_ESTABLISHED>

FROM =
<actor>

TO =
<actor>

AUTHORITY =
<explicit-source>

CLAIM =
C1_DESCRIPTIVE_ONLY

CLAIM_CEILING =
C1

PREDECESSOR_OBJECT =
<exact-id-or-NONE>

SOURCE_COMMIT =
<sha-or-NOT_APPLICABLE>

SOURCE_TREE =
<sha-or-NOT_APPLICABLE>

PHYSICAL_INPUTS =
<list>

INPUT_REHASH =
<MATCH/MISMATCH/NOT_ESTABLISHED>

WORK_EXECUTED =
<exact>

WORK_NOT_EXECUTED =
<exact>

EVIDENCE_STATUS =
<exact>

UNCERTAINTY =
<exact>

OUTPUT_FILES =
<filename,bytes,sha256>

CLAIM_PROMOTION =
FALSE

FOUNDATION_PROMOTION =
FALSE

INTEGRATION_AUTHORITY =
NONE

AUTO_FOLLOW_ON =
NO

NEXT_ACTION =
<single-lawful-step>
```

---

# 42. Research branch checkpoint policy

Every substantial research interval should end with a checkpoint containing:

```text
PREDECESSOR
NEW_OBJECTS
NEW_BYTES
NEW_HASHES
NEW_FINDINGS
NEGATIVE_FINDINGS
RETRACTED_FINDINGS
OPEN_GAPS
IMPLEMENTATION_CANDIDATES
INDEPENDENT_VALIDATION_STATUS
PUBLICATION_STATUS
NEXT_ALLOWED_ACTION
```

The checkpoint must not imply work that was not executed.

---

# 43. Evolution gates

The framework evolves only through explicit gates.

## G0 — Source identity

Exact bytes exist and are retrievable.

## G1 — Structural validity

Schemas, formats and bindings validate.

## G2 — Semantic/falsification validity

Known negative tests and adversarial probes behave correctly.

## G3 — Independent validation

A separate validator reproduces material claims.

## G4 — Repository transport

Branch/commit/PR identities are established.

## G5 — CI

Required mechanical gates pass.

## G6 — Operator disposition

Publication/merge is explicitly authorized.

## G7 — Post-merge verification

Exact merged bytes are independently rechecked.

## G8 — Optional external witness

Archival/transparency services are bound.

No higher gate is inferred from a lower gate.

---

# 44. Live current-state matrix

| Domain | Current live status |
|---|---|
| Public repository | ESTABLISHED |
| `main` identity | `bc312c4...` |
| Tree identity | `c8856faa...` |
| Commit signature | GitHub `verified=true`, valid |
| Persistent AI bootstrap | ESTABLISHED |
| AI handoff protocol | ESTABLISHED |
| Manifest/profile | ESTABLISHED |
| Communication schema | ESTABLISHED |
| Content-addressed ledger | ESTABLISHED, sequence 1 |
| 43 communication negative fixtures | ESTABLISHED in live framework |
| A83 structural hardening | LIVE C1.1 structural candidate |
| Historical A84 witness | PRESERVED |
| A83 physical payload binding | INCOMPLETE IN LIVE BASE |
| Ledger multiwriter safety | INCOMPLETE IN LIVE BASE |
| Ruleset protection | ACTIVE |
| Four logical CI workflows | ESTABLISHED |
| Four distinctly platform-required CI gates | NOT_ESTABLISHED |
| External witness | NOT_ESTABLISHED |
| Long-term ledger robustness | NOT_ESTABLISHED |
| R2 remediation | MANUS-REPORTED LOCAL CANDIDATE |
| Cursor independent R2 validation | PIPELINE / NOT YET ESTABLISHED |
| R2 public integration | NO |

---

# 45. Research foundation for this branch

From this document forward, new research in the Git communication/memory/provenance branch should treat the following as the baseline problem space:

```text
R1 = DURABLE MACHINE-READABLE CROSS-SESSION COMMUNICATION

R2 = CONTENT-ADDRESSED CAUSAL PROVENANCE

R3 = FAIL-CLOSED SOURCE / CLAIM SEPARATION

R4 = MULTI-AGENT FOUR-EYES VALIDATION

R5 = GITHUB-NATIVE POLICY ENFORCEMENT

R6 = SAFE MULTIWRITER / CRASH-CONSISTENT LEDGERING

R7 = PHYSICAL PAYLOAD BYTE BINDING

R8 = CROSS-LANGUAGE CANONICALIZATION

R9 = OPTIONAL EXTERNAL TRANSPARENCY / ARCHIVAL WITNESS

R10 = SPLIT FAILURE-DOMAIN ARCHITECTURE

R11 = LONG-TERM MULTI-ACTOR EMPIRICAL STRESS VALIDATION

R12 = PUBLIC DISCOVERABILITY WITHOUT FALSE ACCESS-COMPLETENESS CLAIMS
```

Each research program must preserve C1 and the evidence hierarchy.

---

# 46. Immediate lawful next state

At this live moment:

```text
PUBLIC_MAIN =
FROZEN_AT_bc312c4

MANUS_R2 =
LOCAL_CANDIDATE

CURSOR_R2_FOUR_EYES =
AUTHORIZED_IN_PIPELINE

NEW_PUBLICATION =
NO

NEW_MAIN_MUTATION =
NO

NEW_CLAIM_PROMOTION =
NO
```

The lawful next sequence is:

```text
CURSOR INDEPENDENT R2 VALIDATION
→ AXIOM ADJUDICATION
→ OPERATOR PUBLICATION DECISION
→ ONLY THEN BRANCH / PR / CI / MERGE PATH
```

Meanwhile unrelated research in this communication-framework branch may continue under:

```text
BLOCKED_LANE != BLOCKED_SYSTEM
```

provided it remains documented and does not silently alter the governed live state.

---

# 47. Terminal framework declaration

```text
OBJECT =
NEXUS_OMEGA_GITHUB_PERSISTENT_COMMUNICATION_MEMORY_PROVENANCE_FRAMEWORK_LIVE_20260831_R0

FRAMEWORK_SCOPE =
GITHUB_NATIVE_PERSISTENT_AGENT_COMMUNICATION
+ REPOSITORY_MEMORY
+ SCIENTIFIC_PROVENANCE
+ CONTENT_ADDRESSED_LEDGER
+ CAUSAL_HANDOFF
+ FAIL_CLOSED_VALIDATION
+ FOUR_EYES_EXTERNAL_REVIEW
+ RULESET_GOVERNANCE
+ RESEARCH_BRANCH_INTERFACE

LIVE_SOURCE =
main@bc312c4d2cd6afa579db1f077c88d8fe08fc9470

LIVE_TREE =
c8856faa74efa5770717d2d44dc7d51e4269cb22

CURRENT_LEDGER_SEQUENCE =
1

CURRENT_RULESET =
main-evidence-protection / 21252293 / active

R2_EXTENSION =
LOCAL_CANDIDATE_ONLY

R2_INDEPENDENT_VALIDATION =
NOT_YET_ESTABLISHED

FRAMEWORK_SPECIFICATION =
COMPLETE_FOR_CURRENT_RESEARCH_BASELINE

IMPLEMENTATION_ROBUSTNESS =
PASS_WITH_MATERIAL_OPEN_LIMITS

CLAIM_CEILING =
C1

CLAIM_PROMOTION =
FALSE

FOUNDATION_PROMOTION =
FALSE

INTEGRATION_AUTHORITY =
NONE

PUBLICATION_AUTHORITY =
OPERATOR_ONLY

NEXT =
CONTINUE_DOCUMENTED_RESEARCH
+ AWAIT_CURSOR_R2_FOUR_EYES_RETURN
```
