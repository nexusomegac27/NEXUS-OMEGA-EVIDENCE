# Recherchebefunde — NEXUS OMEGA

## Primärquellen

1. Linux `flock(2)`: https://man7.org/linux/man-pages/man2/flock.2.html
   - `flock()` legt ausschließlich advisory locks an; Prozesse können sie bei direktem I/O ignorieren.
   - Locks sind an eine open file description gebunden und werden bei Schließen aller zugehörigen Deskriptoren freigegeben.
   - Lock-Konvertierungen sind nicht garantiert atomar.
   - Relevanz: Ein Fix muss alle Ledger-Schreiber an denselben Lock-Vertrag binden; der Lock allein beweist weder Crash-Atomizität noch Schutz vor nicht kooperierenden Schreibern.

2. Python `fcntl`-Dokumentation: https://docs.python.org/3/library/fcntl.html
   - `fcntl.flock(fd, operation)` arbeitet auf einem File Descriptor bzw. Objekt mit `fileno()`.
   - Bei Fehlschlag wird `OSError` ausgelöst.
   - Relevanz: Exception-/Retry- und Lock-Freigabe-Pfade müssen explizit getestet werden; POSIX-Semantik ist Unix-spezifisch.

## Vorläufige Priorisierung

P0: unabhängige Validierung der R2-Kandidatenänderungen gegen den exakten Base-Commit; Fokus auf 20 Dual-Writer-, 20 Triple-Writer-Trials, Jitter, Exception-Lock-Release, Retry, Orphan-, Head- und Sequenzkonsistenz.

P1: Payload-Binding gegen physische Bytes testen, einschließlich LF/CRLF, UTF-8-BOM, NFC/NFD, Nicht-ASCII, trailing und fehlender finaler Newline.

P1: Crash-Konsistenz separat von Serialisierung bewerten. Ein `flock`-Fix darf nicht als Beweis für atomare Multi-Datei-Transaktionen gelten.

P2: Regeln für Plattform-/Dateisystemgrenzen, insbesondere advisory locking und mögliche NFS-/Multi-Host-Lücken, explizit machen.

P2: CI-Gates und Draft-2020-12-Schema-Prüfung als getrennte mechanische Gates untersuchen.

## Weitere Primärquellen

3. JSON Schema Draft 2020-12: https://json-schema.org/draft/2020-12
   - Draft 2020-12 ist die veröffentlichte Spezifikation vom 16. Juni 2022.
   - Die Spezifikation trennt Core- und Validation-Vokabularien und stellt ein offizielles Metaschema bereit.
   - Relevanz: Ein unabhängiges CI-Gate sollte tatsächlich gegen das deklarierte Draft-2020-12-Metaschema prüfen und nicht nur gegen projektspezifische Strukturtests.

4. GitHub — About rulesets: https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/about-rulesets
   - Rulesets und klassische Branch-Protection-Regeln können parallel gelten; alle anwendbaren Regeln werden aggregiert.
   - Bei unterschiedlichen Ausprägungen derselben Regel gilt die restriktivste Variante.
   - Ein Ruleset kann `Active` oder `Disabled` sein.
   - Relevanz: Die Governance-Prüfung muss Rulesets und klassische Branch Protection getrennt erfassen und den tatsächlich wirksamen, aggregierten Schutz dokumentieren.
