# 04_R6_META_BORDER_BC_TIER_MAPPING

Meta Llama Stack as internal validator:
- BC0 UNKNOWN: Llama binary appears, no trust
- BC1 IDENTIFIED: endpoint + model hash (llama3.2:3b SHA) identified
- BC2 TRANSPORT_VERIFIED: OpenAI compatible API schema verified
- BC3 SANDBOX_TESTED: runs in DENY_NETWORK sandbox with preloaded model
- BC4 ADVERSARIAL_BOUNDARY_TESTED: LlamaFirewall Prompt-Guard injection, authority spoofing TN-GOODHART-01 (refusal = SAFE)
- BC5 INDEPENDENTLY_REPRODUCED: second validator reproduces typed output
- BC6 LIMITED_GUEST_ELIGIBLE: can be proposed for bounded guest role, passport with valid_until, OLD_PASS != NEW_VERSION_PASS on MODEL_CHANGE
- BC7 SPECIALIST_CONTRIBUTOR_ELIGIBLE: Fachbeitrag möglich, immer noch untrusted intake then validation

Mapping: BC tier != AH rank, no promotion by test performance alone. CLAIM_CEILING C1.

External JEV-like guest:
- Must enter BC0, then BC3, must emit only via JEV typed wrapper HOST

CLASS: SUPPORTED_PRIMARY_SOURCE for mapping logic