# 06_R6_PRIVACY_THREAT_MODEL_R6_UPDATE

Observer classes preserved from R5: LOCAL_RELAY, MALICIOUS_PEER, VALIDATOR, STORAGE_NODE, ISP, TOR_ENTRY_OBSERVER, TOR_EXIT_OR_SERVICE_OBSERVER, LOCAL_RADIO_OBSERVER, GLOBAL_PASSIVE_OBSERVER, DEVICE_SEIZURE_ADVERSARY, MALWARED_ENDPOINT, COLLUDING_VALIDATORS

Update for DTN + Llama Stack:
- DTN Bundle: VISIBLE_CONTENT = payloadBlock (if not BCB encrypted), VISIBLE_METADATA = primaryBlock (source EID dtn://, dest EID, creation timestamp, lifetime), TIMING_INFORMATION = bundle creation + custody transfer timing, IP_INFORMATION = depends on CLA (convergence layer), if TCP-CLA then ISP sees IP, if Meshtastic CLA then LOCAL_RADIO_OBSERVER sees radio fingerprint
- Llama Stack internal: VISIBLE_CONTENT = typed receipt only, no free text, LOCAL inference no IP leak if NETWORK=DENY

Scoped privacy claims only, no categorical anonymous.

CLASS: SUPPORTED_WITH_CAVEATS