# 03_R6_DTN_ENVELOPE_MINIMAL_TRANSPORT - C1
OBJECT = NEXUS_OMEGA_R6_EXPERT_RETURN_MISTRAL_DTN
PREDECESSOR = 66d6929178d0cd9c4ed2ef83a3f7dd33f08cbde726c41e7a470b929d5894402d
SOURCE: RFC9171 Bundle [primaryBlock, *extension, payloadBlock] CBOR #6.55799, EIDs dtn://, creation timestamp, lifetime; Custody Transfer BIBE store is source of truth; BPSec RFC9172 BIB/BCB

P-C1 minimal viable NOAM = DTN + Signed Receipts + Local Storage ohne TOR/ZKP/Token: SUPPORTED_WITH_CAVEATS
SOURCE: R5 07_R5 minimal viable hypothesis + 09_R5 token/zkp optional + RFC9171/9172
UNCERTAINTY: LOW-MEDIUM arch, MEDIUM operativ (resource scarcity without incentive)
STATUS: C1, NOAM = artifact mesh provenance tragend, delay-tolerant

P-C2 Falsifier Verlust DTN = Verlust epistemischer Kern? NOT_CONTRADICTED / SUPPORTED_WITH_CAVEATS - Epistemischer Kern = Signed Receipts Chain + Local Storage persistiert bei TRANSPORT=DENY. BIBE store is source of truth.
P-C3 Signed receipts benötigen TOR? CONTRADICTED - BPSec BIB/BCB provides authentication without TOR, TOR optional privacy module.

CLASS: RESEARCH_HYPOTHESIS -> SUPPORTED_WITH_CAVEATS