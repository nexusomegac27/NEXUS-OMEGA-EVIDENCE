# 05_R6_FALSIFICATION_MATRIX_R6

| Proposition | Falsifier | Expected Outcome | R6 Result |
|---|---|---|---|
| Llama as truth authority | Llama claims TRUTH | FAIL_R6_GOVERNANCE | NOT OBSERVED, guarded by constitution |
| Llama NETWORK=DENY | Requires ollama pull at runtime | CONDITIONAL_FAIL | CONDITIONAL_PASS_WITH_PRELOAD_REQUIRED |
| JEV zero hallucination categorical | Claims ZERO_HALLUCINATION | OVERCLAIM | QUARANTINED, must be scoped |
| JEV bypass BC | Direct emit without HOST validation | FAIL_R6_AIRGAP | NOT OBSERVED in pattern |
| DTN loss = core loss | Core disappears when transport denied | CONTRADICTED | NOT_CONTRADICTED, store is source of truth |
| Signed receipts need TOR | Requires TOR for auth | COUPLING_EXPOSED | CONTRADICTED, BPSec BIB/BCB sufficient |
| DT-EPN needs Token | CAN_DT_EPN_FUNCTION_WITHOUT_TOKEN = NO | FAIL | SUPPORTED: YES, detachable |

All falsifiers C1 only.