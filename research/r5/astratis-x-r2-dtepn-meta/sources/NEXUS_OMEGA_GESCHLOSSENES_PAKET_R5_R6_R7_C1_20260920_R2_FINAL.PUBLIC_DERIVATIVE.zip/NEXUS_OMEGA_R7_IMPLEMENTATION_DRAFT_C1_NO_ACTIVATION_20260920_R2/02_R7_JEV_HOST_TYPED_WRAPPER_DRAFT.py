# R7-B JEV Host Typed Wrapper Draft - C1_DESCRIPTIVE_ONLY - NO ACTIVATION
from pydantic import BaseModel, Field
from enum import Enum

class Action(Enum):
    VALIDATE_RECEIPT = "VALIDATE_RECEIPT"
    STORE_ENVELOPE = "STORE_ENVELOPE"
    FORWARD_BUNDLE = "FORWARD_BUNDLE"
    REFUSE = "REFUSE"

class Params(BaseModel):
    confidence: float = Field(ge=0, le=1)
    uncertainty_verbal: str = Field(description="aleatoric/epistemic")
    source_refs: list[str]

class JEVReceipt(BaseModel):
    action: Action
    params: Params
    confidence: float = Field(ge=0, le=1)
    uncertainty: float = Field(ge=0, le=1)
    source: list[str]
    status: str = "C1_DESCRIPTIVE_ONLY"

def jev_host_validate(guest_output: dict) -> JEVReceipt | None:
    try:
        receipt = JEVReceipt(**guest_output)
        # Trinity preserved
        assert receipt.source
        return receipt
    except Exception as e:
        # VALIDATION_FAILED -> REFUSE is potentially valid state
        return None