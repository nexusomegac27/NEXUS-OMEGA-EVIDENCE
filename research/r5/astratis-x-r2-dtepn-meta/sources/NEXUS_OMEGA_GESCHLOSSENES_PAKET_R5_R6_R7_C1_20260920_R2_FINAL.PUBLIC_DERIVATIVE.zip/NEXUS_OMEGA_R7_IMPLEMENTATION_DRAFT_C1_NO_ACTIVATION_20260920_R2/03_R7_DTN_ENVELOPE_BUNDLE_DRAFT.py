# R7-C DTN Envelope Bundle Draft - C1_DESCRIPTIVE_ONLY - NO ACTIVATION
# RFC9171 + RFC9172 BPSec
bundle_draft = {
    "primaryBlock": {
        "version": 7,
        "bundleControlFlags": 0,
        "crcType": 1,
        "destinationEID": "dtn://node-2/artifact-mesh",
        "sourceEID": "dtn://node-1/artifact-mesh",
        "reportEID": "dtn:none",
        "creationTimestamp": {"time": 0, "seq": 0},
        "lifetime": 86400
    },
    "payloadBlock": {
        "type": 1,
        "data": b"signed_receipt_chain_c1"  # Signed Receipts = CORE
    },
    "bibBlock": {  # Block Integrity Block RFC9172
        "type": 11,
        "auth": "BPSec BIB - auth without TOR"
    },
    "bibe": {
        "note": "Store is source of truth, custody transfer, loss of transport != loss of core"
    }
}