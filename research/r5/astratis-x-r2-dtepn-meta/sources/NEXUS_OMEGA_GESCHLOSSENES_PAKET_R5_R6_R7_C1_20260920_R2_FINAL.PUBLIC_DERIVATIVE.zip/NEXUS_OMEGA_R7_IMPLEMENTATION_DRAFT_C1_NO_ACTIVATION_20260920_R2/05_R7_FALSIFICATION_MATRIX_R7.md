# R7 Falsification Matrix

| Proposition | Falsifier | R7 Draft Status |
|---|---|---|
| Llama airgap | Requires HF_TOKEN/network at runtime | CONDITIONAL_PASS_WITH_PRELOAD - preloaded weights fix |
| JEV typed only | Emits free string | FAIL if not enforced by HOST |
| DTN minimal viable | Needs TOR for auth | CONTRADICTED - BPSec BIB sufficient |
| Core survives transport loss | Core lost when DTN denied | NOT_CONTRADICTED - store is source of truth |
| Token mandatory | Needs token to function | CONTRADICTED - YES detachable |
| Implementation activates | ACTIVATION=YES | FAIL - must stay NO until AXIOM seal |