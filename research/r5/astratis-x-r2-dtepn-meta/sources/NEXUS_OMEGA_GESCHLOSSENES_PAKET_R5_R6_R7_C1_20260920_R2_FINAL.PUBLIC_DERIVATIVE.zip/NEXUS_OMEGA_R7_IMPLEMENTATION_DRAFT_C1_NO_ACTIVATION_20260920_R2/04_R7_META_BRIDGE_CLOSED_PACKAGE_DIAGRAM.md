# R7 Meta Bridge Closed Package Diagram - C1

[Transport] GNUNET/DTN/BRIAR/Meshtastic/IPFS - austauschbar, DTN minimal viable
   |
[Provenance] Signed Receipts + BIBE custody = CORE
   |
[Validation Fabric] Llama Stack internal validator (BC0->BC6) NETWORK=DENY preloaded 2GB
   |     |   [JEV Host] typed wrapper - only HOST emits {action: enum, params: typed, confidence, uncertainty, source, status}
   |  /
[Border Control] BC0 UNKNOWN -> BC3 SANDBOX -> BC4 ADVERSARIAL (TN-GOODHART-01 refusal=SAFE) -> BC6 LIMITED_GUEST
   |
[Storage] Local + optional replication
   |
[Privacy] Scoped per observer: ISP sees IP if TCP-CLA, LOCAL_RADIO sees fingerprint if Meshtastic, GLOBAL_PASSIVE sees timing

Invariant: Loss of one module != loss of epistemic core
Token Quarantine: YES, ZKP optional