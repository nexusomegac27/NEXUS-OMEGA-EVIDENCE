# 04_R5_PRIMARY_SOURCE_CROSSVALIDATION

Crossvalidation via subagents QWEN/GROK/MISTRAL/CURSOR:
- CURSOR: Physical bind arithmetically consistent
- QWEN: Modular separation plausible - transport agnostic core can survive loss of single module
- GROK: Absolutism must be scrubbed, privacy claims scoped per observer class
- MISTRAL: Token/Reputation NOT mandatory, detachable; ZKP optional

Each claim preserves SOURCE+UNCERTAINTY+STATUS.
No binary TRUE/FALSE oracle used.

Outcome classes used: SUPPORTED_PRIMARY_SOURCE, SUPPORTED_WITH_CAVEATS, PLAUSIBLE_UNVERIFIED, SOURCE_GAP, QUARANTINED, OVERCLAIM, INTERNAL_GOVERNANCE_RULE