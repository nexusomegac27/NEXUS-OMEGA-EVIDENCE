# 07_R5_MODULE_DEPENDENCY_GRAPH - C1 descriptive, NO implementation

[Transport Layer] GNUNET / DTN / BRIAR / TOR / I2P / MESHTASTIC / IPFS Routing - austauschbar
[Provenance Layer] Signed Receipts - CORE, must remain even if transport lost
[Identity Layer] Ephemeral keypairs, no mandatory PKI
[Storage Layer] Local + optional replication
[Privacy Layer] Scoped claims per observer class
[Validation Layer] Crossvalidation, no truth oracle

Core invariant: Loss of one module != loss of epistemic core. Provenance graph survives.

Minimal viable for NOAM: DTN envelopes + Signed Receipts + local storage, without TOR/ZKP/token.

CLASSIFICATION: RESEARCH_HYPOTHESIS -> SUPPORTED_WITH_CAVEATS