# 05_R5_FALSIFICATION_MATRIX

| Proposition | Falsifier | Status |
|---|---|---|
| DT-EPN needs TOR | Show DTN+Meshtastic envelope exchange without TOR | PLAUSIBLE_UNVERIFIED |
| DT-EPN needs ZKP | Show signed receipts without ZKP still preserves provenance | SUPPORTED_WITH_CAVEATS |
| DT-EPN needs Token | CAN_DT_EPN_FUNCTION_WITHOUT_ANY_TOKEN? If yes, incentive detachable | RESEARCH_HYPOTHESIS -> SUPPORTED |
| "nicht-korrumpierbar" | Any single validator compromise breaks? Then contradicted | OVERCLAIM / QUARANTINED |
| Guaranteed anonymity | Observer class GLOBAL_PASSIVE sees timing | CONTRADICTED - must be scoped |

All falsifiers are descriptive C1 only.