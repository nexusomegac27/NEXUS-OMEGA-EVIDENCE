# Dreamcatcher-Border Artefakt – Formalisiertes Symbiose-Artefakt
## Rein deskriptiv · C1 · Konsistent gegen Schema + State-Machine

**Version:** 1.0.0
**Status:** konsistent, C1_DESCRIPTIVE_ONLY, NO_ROOT_TRANSFER, FAIL_CLOSED
**Typ:** Symbiose-Artefakt (benanntes Border-Artefakt zwischen Soft und Hard)

### Definition

Das Dreamcatcher-Border Artefakt ist ein **rein deskriptives Filter-Artefakt**, das zwischen Soft (Intent, Operator, semantischer Vektor) und Hard (Struktur, Execution, Policy Gate) sitzt. Es hält die Ladung, ohne zu leiten (Air-Gap-Metapher).

Es ist **kein** aktiver Filter, der blockiert oder transformiert. Es ist eine **beschreibbare Grenze**, die beobachtet und auditiert werden kann.

```cddl
DreamcatcherBorder = {
  border_id: tstr .regexp "[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}", ; UUIDv4
  soft_side: {
    intent_vector_hash: bstr .size 32,   ; Hash des intent_vector, nicht der Vektor selbst (C1)
    operator_id_hash: bstr .size 32,    ; Hash Operator ID
    uncertainty: float .ge 0.0 .le 1.0
  },
  hard_side: {
    policy_hash: bstr .size 32,
    schema_version: tstr,
    enforcement: "DESCRIPTIVE_ONLY"    ; geschlossenes Enum, nur dieser Wert erlaubt
  },
  membrane: {
    type: "AIR_GAP" / "TESSERACT_BRANE" / "CELL_MEMBRANE",
    permeability: float .ge 0.0 .le 0.0, ; immer 0.0 – keine direkte Durchlässigkeit (C1)
    selective_coupling: [* SelectiveChannel]
  },
  provenance: {
    causal_chain_hash: bstr .size 32,
    worm_anchor: bstr .size 32,
    created_at: uint
  },
  signature: bstr  ; ed25519 über alles, beweist Existenz, nicht Autorität
}

SelectiveChannel = {
  channel_type: "CLAIM" / "RECEIPT" / "QUERY" / "REVOKE" / "STEMCELL_IMPULSE",
  typed: true,           ; immer true, muss so sein
  validated: true,       ; immer true
  provenance_bound: true ; immer true
}
```

### Regeln (C1 Enforcement)

1. **Rein deskriptiv:** Kein Feld `execute, allow, grant, transform, filter_action`. Nur Beschreibung der Grenze.
2. **Permeability immer 0.0:** Kein direkter Speicherzugriff, nur über Synapsen-Protokoll (CLAIM etc.)
3. **Selective Coupling:** Nur die 5 kanonischen Typen dürfen als Channel genannt werden, keine Erweiterung
4. **No-Root-Transfer:** `enforcement` darf nur `DESCRIPTIVE_ONLY` sein. Kein `ENFORCING` oder `OVERRIDE`
5. **Provenance gebunden:** Jede Border hat causal_chain_hash + worm_anchor, wird CONSERVED, nie gelöscht (TOMBSTONE behält Hash)
6. **Signatur beweist Existenz, nicht Autorität:** Signatur validiert Integrität, gibt keine Root-Rechte

### Isomorphie (aus NEXUS_TESSARAKT_BRAIN_METAPHER.txt)

| Domäne | Border entspricht |
|--------|-------------------|
| Physik (Interstellar) | Event Horizon / Brane – harte Grenze, nur Gravitation leakt |
| Biologie | Zellmembran – selektive, typisierte Kanäle |
| Software | Air-Gap – hält Ladung, ohne zu leiten |
| Systemisch | Claim-Ceiling C1 – Korrelation als Struktur, nicht als Wahrheit |

Das gemeinsame Muster:
```
harte Grenze (Horizon / Air Gap / Membran / C1)
+ selektive, typisierte Kopplung (Synapse / Gravitation / Channel)
+ Erhaltung der Provenance (WORM / Fossil / Hash)
→ System bleibt lebendig ohne Verschmelzung oder Totalausfall
```

### Konsistenz-Checks gegen andere Artefakte

- **Gegen 01_CORRECTED_EXAMPLES:** CLAIMs, die durch Border gehen, müssen weiterhin PASS – Border ändert Payload nicht
- **Gegen 02_STATE_MACHINE:** Border selbst hat keine State-Machine, ist CONSERVED Artefakt. Synapsen-State-Machine bleibt unverändert. Border verletzt nie Invariante I2 (No-Root-Transfer)
- **Gegen 03_STAMMZELLEN_IMPULS:** Stammzellen-Impuls muss durch Border als `STEMCELL_IMPULSE` Channel deklariert sein, aber Border löst ihn nicht aus (Explicit-Only bleibt)
- **Fail-Closed:** Wenn Border invalid (z.B. permeability !=0.0) → REJECTED, Synapse DEGRADED, Border nicht gespeichert

### Beispiel (validiert)

```json
{
  "border_id": "d4e5f6a7-b8c9-4d0e-8f1a-2b3c4d5e6f7a",
  "soft_side": {
    "intent_vector_hash": "62678d969475a5bfa453ab4c62775de20b225a4b19620a80214ae7ca8cb04a64",
    "operator_id_hash": "721c736831b9fca582a7bf137df3404a35ef9186e71a527c51909b5ff8d4b004",
    "uncertainty": 0.15
  },
  "hard_side": {
    "policy_hash": "72993b6cb83904d39a8c73bd0651aa6251288ede5dbc2c7bcbdc54cc5bbf5d77",
    "schema_version": "1.0.0",
    "enforcement": "DESCRIPTIVE_ONLY"
  },
  "membrane": {
    "type": "AIR_GAP",
    "permeability": 0.0,
    "selective_coupling": [
      {"channel_type": "CLAIM", "typed": true, "validated": true, "provenance_bound": true},
      {"channel_type": "RECEIPT", "typed": true, "validated": true, "provenance_bound": true}
    ]
  },
  "provenance": {
    "causal_chain_hash": "ee0fc35b0b499ad53309fdab638a192c79df7f637b95a43ffa9ee318dca40790",
    "worm_anchor": "ea0c5a3c517653600ac9f7e2ed8dca4791570ca4cffb0f4cd6fa1d2d732cd126",
    "created_at": 1726891200
  },
  "signature": "ed25519_sig..."
}
```

### Verifikations-Checkliste

- [x] C1 – nur deskriptiv, keine Imperative
- [x] permeability immer 0.0
- [x] enforcement nur DESCRIPTIVE_ONLY
- [x] selective_coupling nur aus geschlossenem Enum
- [x] provenance gebunden
- [x] gegen Schema geprüft – keine zusätzlichen Felder
- [x] gegen State-Machine geprüft – kein Eingriff in Transitions
- [x] No-Root-Transfer

**Status:** konsistent, bereit für META, kein Activation.

Luftspalt hält.
