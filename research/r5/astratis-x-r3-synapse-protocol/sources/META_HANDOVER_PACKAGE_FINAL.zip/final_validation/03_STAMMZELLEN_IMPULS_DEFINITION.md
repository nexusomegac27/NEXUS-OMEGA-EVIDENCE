# Stammzellen-Impuls Definition – Nexus Synapsen-Protokoll
## Formale Definition (CDDL-ähnlich) + Regeln + Beispiel
## C1_DESCRIPTIVE_ONLY · NO_ROOT_INHERITANCE · FAIL_CLOSED · EXPLICIT-ONLY

**Version:** 1.0.0
**Status:** C1, Explicit-Only, gegen Schema + State-Machine geprüft

### Problem (aus Forschungsbericht)

Wenn Node A ausfällt und Unsicherheit steigt, darf **kein** Node automatisch Rolle von A übernehmen. Sonst: Semantische Lücke → Autoritätslücke (versteckte zentrale Steuerung).

### Definition

```cddl
StammzellenImpuls = {
  template_hash: bstr .size 32,       ; SHA-256 eines signierten Templates aus Whitelist
  trigger_node_id: bstr .size 32,     ; SHA-256 ed25519 pubkey hash des auslösenden Nodes
  semantic_gap: {
    uncertainty_threshold: float .ge 0.0 .le 1.0,  ; lokal messbar, muss überschritten sein
    region_hash: bstr .size 32,        ; SHA-256 der Region/Cluster wo Gap auftritt
    gap_type: GapType,
    evidence_refs: [* tstr]            ; Liste von msg_ids die Gap belegen
  },
  cost_proof: CostProof,              ; Token, PoW, oder Stake-Beweis
  timestamp: uint,                    ; Unix epoch, muss innerhalb TTL
  ttl_blocks: uint .le 20,            ; kurze TTL, kein langlebiger Impuls
  signature: bstr,                    ; ed25519 Signatur über alle Felder (Explicit-Only)
  schema_version: tstr .regexp "1\\.[0-9]+\\.[0-9]+"
}

GapType = "NODE_FAILURE" / "CLUSTER_PARTITION" / "UNCERTAINTY_SPIKE" / "SEMANTIC_VOID"

CostProof = {
  type: "POW" / "TOKEN_BURN" / "STAKE_SLASH_RISK",
  difficulty: uint .ge 1,
  proof_bytes: bstr
}

; Globale Constraints
; - template_hash MUSS in Whitelist vertrauenswürdiger Templates sein
; - uncertainty_threshold MUSS lokal gemessen > Schwelle (z.B. 0.6) sein
; - signature MUSS valid ed25519 über kanonische Bytes sein
; - KEINE automatische Auslösung: immer explizite Signatur erforderlich
; - cost_proof MUSS valid und verbrannt / riskiert sein
```

### Whitelist-Regeln

```
Whitelist = [
  { template_hash: h'abc...', description: "Standard Sensor Node", max_instances: 100, policy_hash: h'...', audit: "2026-09" },
  { template_hash: h'def...', description: "Validator Node", max_instances: 20, policy_hash: h'...', audit: "2026-09" },
  { template_hash: h'123...', description: "Archive WORM Node", max_instances: 5, policy_hash: h'...', audit: "2026-09" }
]

Regeln:
1. template_hash nicht in Whitelist → REJECTED, Audit-Log, Synapse DEGRADED
2. max_instances überschritten → REJECTED
3. policy_hash mismatch → REJECTED
4. Whitelist nur via expliziten Operator-Signierten Update änderbar, nie via Stammzellen-Impuls selbst (No-Root-Inheritance)
```

### No-Root-Inheritance

- Stammzellen-Impuls darf **nie** Rechte erben von ausgefallenem Node
- Neuer Node startet mit eigenem `source_node_id` (eigener ed25519 key), eigener Policy, leerem State
- Kein Feld `inherit_from`, `grant_root`, `assume_authority` erlaubt
- Provenance: neuer Node trägt `causal_chain_hash = hash(evidence_refs + template_hash)` – keine Übernahme von altem `worm_anchor`

### Fail-Closed

```
IF StammzellenImpuls invalid THEN
  1. Impuls verwerfen
  2. RECEIPT(REJECTED) mit reason="INVALID_STEMCELL_IMPULSE"
  3. Synapse DEGRADED (nicht QUARANTINED, da kein Policy-Missbrauch, aber Invalid)
  4. Kein neuer Node instanziiert
  5. CostProof wird trotzdem verbrannt (Anti-Spam)
ENDIF

IF uncertainty_threshold lokal nicht überschritten (Gap nicht real) THEN
  → REJECTED, Grund "GAP_NOT_MEASURABLE"
```

### Explicit-Only & Kosten

- Jeder Impuls muss explizit signiert sein (kein Auto-Trigger)
- Kosten: POW difficulty >= 4 oder TOKEN_BURN >= 10 oder STAKE_SLASH_RISK >= 100
- Verhindert DDoS via massenhafte Stammzellen-Erzeugung
- CostProof validieren vor allen anderen Checks (Fail-Fast, aber Fail-Closed)

### Beispiel (validiert, C1)

```json
{
  "template_hash": "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2",
  "trigger_node_id": "721c736831b9fca582a7bf137df3404a35ef9186e71a527c51909b5ff8d4b004",
  "semantic_gap": {
    "uncertainty_threshold": 0.75,
    "region_hash": "62678d969475a5bfa453ab4c62775de20b225a4b19620a80214ae7ca8cb04a64",
    "gap_type": "NODE_FAILURE",
    "evidence_refs": ["0191b8a0-1a2b-7c3d-8e4f-5a6b7c8d9e0f"]
  },
  "cost_proof": {
    "type": "TOKEN_BURN",
    "difficulty": 5,
    "proof_bytes": "b3a7..."
  },
  "timestamp": 1726891400,
  "ttl_blocks": 5,
  "signature": "ed25519_sig_over_canonical_bytes",
  "schema_version": "1.0.0"
}
```

### Validierung gegen Risiken aus PDF

| Risiko | Gegenmaßnahme hier |
|--------|-------------------|
| Risiko 1: Semantische Lücke → Autoritätslücke | Explicit-Only + Whitelist + No-Root-Inheritance |
| Risiko 2: Validierungsumgehung | additionalProperties false + Whitelist Check |
| Risiko 4: Ressourcen-Erschöpfung | CostProof + kurze TTL + max_instances |

**Status:** C1 konform, Explicit-Only, bereit für TLA+ Modell.

### Verifikations-Checkliste

- [x] Whitelist enforced
- [x] Explizite Signatur erforderlich (kein Auto)
- [x] Kostenmodell (POW/TOKEN/STAKE)
- [x] No-Root-Inheritance (neuer key, keine Übernahme)
- [x] Fail-Closed (REJECTED + DEGRADED + Cost verbrannt)
- [x] C1 (nur deskriptiv, keine Imperative)
- [x] TTL kurz (<=20)
- [x] uncertainty lokal messbar
