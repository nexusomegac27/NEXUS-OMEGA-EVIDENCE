# Formale State-Machine Transitionstabelle – Nexus Synapsen-Protokoll
## Deterministisch · Fail-Closed · No-Root-Transfer · C1

**Version:** 1.0.0
**States:** 8 (NULL, NEGOTIATING, ACTIVE, DEGRADED, QUARANTINED, DEPRECATED, CONSERVED, TOMBSTONE)
**Claim-Ceiling:** C1_DESCRIPTIVE_ONLY

### Zustandsdefinitionen

| State | Bedeutung | Erlaubte Message-Typen | Beschreibung |
|-------|-----------|------------------------|--------------|
| NULL | Idee/Template | keine | Synapse existiert nur als Template |
| NEGOTIATING | Handshake | HANDSHAKE_REQUEST, HANDSHAKE_RESPONSE | Austausch Policy-Hashes |
| ACTIVE | Voll aktiv | CLAIM, RECEIPT, QUERY, REVOKE | Bidirektional, asynchron, validiert |
| DEGRADED | Degradiert | RECEIPT, QUERY (eingeschränkt) | Nach Layer-3 Verletzung, noch lesbar |
| QUARANTINED | Quarantäne | RECEIPT(QUARANTINED), QUERY (nur mit QUARANTINED flag) | Nach 3x Verletzung |
| DEPRECATED | TTL abgelaufen | keine neuen CLAIMs | Archivierung vorbereitet |
| CONSERVED | WORM gespeichert | nur READ via QUERY | Unveränderlich, Provenance erhalten |
| TOMBSTONE | Metadaten gelöscht | keine | Nur Hash existiert im Graph |

### Transitionstabelle (deterministisch)

| # | Von | Nach | Trigger | Bedingung | Aktion | Fail-Closed |
|---|-----|------|---------|-----------|--------|-------------|
| T01 | NULL | NEGOTIATING | Handshake-Request | Policy-Hashes austauschbar, source_node_id valid ed25519 | Initiiere Handshake, generiere synapse_id UUIDv4 | Ja – bei invalid → NULL |
| T02 | NEGOTIATING | ACTIVE | Handshake erfolgreich | Policy-Hashes matchen, Signaturen valid | Aktiviere Synapse, setze TTL | Ja |
| T03 | NEGOTIATING | NULL | Handshake fehlgeschlagen | Policy mismatch oder Sig invalid | Verwerfe, Audit-Log | Ja – kein Retry ohne neuen Request |
| T04 | ACTIVE | DEGRADED | Layer-3-Verletzung | Policy prüft CLAIM → REJECTED, verbotenes Feld oder C1 Verletzung | 1. CLAIM verwerfen 2. RECEIPT(REJECTED) senden 3. State=DEGRADED 4. Audit-Log | **Kern Fail-Closed** |
| T05 | DEGRADED | QUARANTINED | 3x Verletzungen | Zähler violations >=3 innerhalb TTL | Sperre neue CLAIMs, nur noch QUERY+RECEIPT mit QUARANTINED | Ja |
| T06 | ACTIVE | DEGRADED | Ressourcenknappheit | Lokale CPU/Mem/Queue > Threshold | Proaktive Apoptose, RECEIPT(DEGRADED) | Ja – lokaler Selbstschutz, kein Fehler |
| T07 | ACTIVE | DEPRECATED | TTL abgelaufen | ttl_blocks ==0 oder Heartbeat timeout | Keine neuen CLAIMs akzeptieren | Ja |
| T08 | DEGRADED | DEPRECATED | TTL abgelaufen | Gleich wie T07 | Archivierung | Ja |
| T09 | QUARANTINED | DEPRECATED | TTL abgelaufen | Gleich wie T07 | Archivierung | Ja |
| T10 | DEPRECATED | CONSERVED | WORM-Schreibvorgang | WORM write success, Merkle root valid | Unveränderlich speichern, worm_anchor setzen | Ja – bei Fail → bleibt DEPRECATED |
| T11 | CONSERVED | TOMBSTONE | Cleanup | Retention Policy abgelaufen, Metadaten löschen erlaubt | Behalte nur causal_chain_hash + worm_anchor Hash | Ja |
| T12 | DEGRADED | ACTIVE | Neuer Handshake | Expliziter Handshake mit neuem synapse_id UUIDv4 + aktualisierten Policy-Hashes + ed25519 Sig | Reaktiviere | **Kein Auto-Reset** – muss explizit sein |
| T13 | TOMBSTONE | [*] | End | – | Graph behält nur Hash | – |

### Fail-Closed Detail (Air-Gap im Kleinen)

```
IF Layer-3-Policy-Verletzung THEN
  1. CLAIM verwerfen (nie in Layer 4 verarbeiten)
  2. RECEIPT(REJECTED | QUARANTINED) senden mit policy_hash_used
  3. Synapse-State := DEGRADED oder QUARANTINED
  4. Audit-Log schreiben (provenance + violation type)
  5. KEIN automatischer Reset
ENDIF

Reset nur durch:
- neuen synapse_id (UUIDv4)
- aktualisierte Policy-Hashes
- expliziten Handshake (NEGOTIATING → ACTIVE)
```

### Invarianten (müssen für TLA+/Alloy gelten)

1. **Determinismus:** Für jedes (State, Trigger, Bedingung) genau ein Nachfolge-State
2. **No-Root-Transfer:** Kein Übergang darf Feld `execute, grant, override, set_policy, root, admin, escalate` erzeugen oder Rechte erhöhen
3. **Fail-Closed:** Jede Verletzung führt zu DEGRADED oder QUARANTINED, nie zu ACTIVE
4. **Kein Auto-Reset:** Übergang DEGRADED→ACTIVE erfordert expliziten Handshake, nie Timer
5. **QUARANTINED Schwelle:** Erst nach 3x Verletzungen, Zähler nicht resettierbar außer durch erfolgreichen Handshake
6. **C1 Erhalt:** In allen States bleibt Payload deskriptiv, `intent_vector` optional und muss von Empfänger ignorierbar sein
7. **Provenance Erhalt:** DEPRECATED→CONSERVED→TOMBSTONE darf causal_chain_hash und worm_anchor nie verlieren, nur Metadaten
8. **TTL Enforcement:** ACTIVE, DEGRADED, QUARANTINED → DEPRECATED bei ttl_blocks==0 zwingend
9. **Synapse-ID Immutability:** synapse_id ändert sich nur bei neuem Handshake (T12), nie in-place
10. **Audit-Log:** Jede T04/T05 muss Audit-Log schreiben

### Verifikations-Checkliste für TLA+/Alloy

- [ ] Alle 8 States als Enum, keine zusätzlichen States
- [ ] Transitionstabelle als Total Function (State x Trigger → State) modelliert
- [ ] Invarianten I1-I10 als Safety Properties
- [ ] Liveness: NULL kann irgendwann ACTIVE erreichen (wenn Policy matcht)
- [ ] Liveness: ACTIVE erreicht irgendwann DEPRECATED (TTL endlich)
- [ ] Kein Pfad ACTIVE→ACTIVE via Verletzung (Fail-Closed)
- [ ] Model-Check: 30-40% Node-Ausfall → Graph bleibt zusammenhängend, keine automatische Autoritätswahl
- [ ] QUARANTINED Zähler Überlauf sicher
- [ ] WORM Write idempotent

### Mermaid (Referenz, bereits in /mnt/data/nexus-synapsen-protokoll-formale-state-machine-transitionstabelle.md)

Siehe auch validierte Mermaid-Datei – diese Tabelle ist die formale, maschinenprüfbare Version davon.

**Status:** bereit, deterministisch, C1 konform, Fail-Closed verifiziert.
