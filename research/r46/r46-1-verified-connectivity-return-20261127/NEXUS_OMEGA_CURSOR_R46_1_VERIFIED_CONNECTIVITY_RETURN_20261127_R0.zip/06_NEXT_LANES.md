# NEXT ALLOWED DELTAS (per lane)

| Lane | Status | Next allowed |
|------|--------|--------------|
| Offline contract fixtures | GO_OFFLINE_PREP | Expand typed nested projection tests |
| Mock E2E outbox | GO_OFFLINE_PREP | Add STOP/epoch fixtures under disposable workspace |
| WWW BodyTwin | VERIFIED_READ_ONLY | No write; optional second-party witness order |
| OPPO physical | HOLD | Requires separate owner approval; ALT_D DO_NOT_RUN |
| Hostinger | HOLD_SCOPE | Requires scoped WRITE_ACK |
| AutoCLAW custody | SOURCE_GAP | Supply missing 7 originals |
| Claim fidelity | RESEARCH_CONTRACT | No claim promotion |
