| Lane | Class | Evidence |
|---|---|---|
| G0 Order | MATCH | 20378 / f2654f18… |
| G0 R46-1 rehash | MATCH | 12306 / 7abb…e301 |
| G1 ADB | PASS_READ_ONLY_C1 | CPH2219 + maps 1.3.11-vc15 |
| G2 APP source | PRESENT | nexus-mobile |
| G2 local APK | BUILD_SUCCESS | 23008509 / 99bc2fab… |
| G2 APK install | NOT_AUTHORIZED | — |
| G3 WWW source | PRESENT | public/bodytwin + out |
| G3 live write | NO | — |
| G4 historical raw | SOURCE_GAP | APKs only |
| G4 14 gates | HOLD 0/14 | R39 contract |
| G4 one-shot | HOLD | template partial |
