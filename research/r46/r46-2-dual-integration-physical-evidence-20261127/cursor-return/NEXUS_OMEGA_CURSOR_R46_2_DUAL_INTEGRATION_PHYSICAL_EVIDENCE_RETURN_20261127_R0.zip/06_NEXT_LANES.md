1. Keep OPPO connected/unmoved for further READ_ONLY checks if needed
2. Supply or locate authorized private raw ACC/GYRO originals for private replay
3. Freeze protocol digest + independent angle reference; then owner one-shot
4. WWW local browser/mobile checks continue; no Hostinger write
5. APK install remains NOT authorized until separate order
6. ALT_D remains until separate exact amendment after gate evidence
