﻿# NEXUS_OMEGA_CURSOR_R46_2_FINAL_EXECUTION_AND_EXTERNAL_RESEARCH_RELEASE_RETURN_20261127_R0

OBJECT = NEXUS_OMEGA_CURSOR_R46_2_FINAL_EXECUTION_AND_EXTERNAL_RESEARCH_RELEASE_RETURN_20261127_R0
PARENT_ORDER = NEXUS_OMEGA_AXIOM_CURSOR_R46_2_FINAL_EXECUTION_AND_EXTERNAL_RESEARCH_RELEASE_20261127_R0
ISSUE_COMMENT_ORDER = 7217553626
PARENT_R1 = 13861 / ea2661af0800d375284f1ac7a1a1f346cc56f5c874d76af16459342da3c3dd2b
AUTHORITY = OPERATOR_ALEXANDER_VIA_AXIOM
CLAIM_CEILING = C1_DESCRIPTIVE_ONLY
STATE = PASS_WITH_MATERIAL_CAVEATS_C1_FINAL_DELTA_EXTERNAL_RESEARCH_READY_HISTORICAL

## DONE (authorized lanes)

1. PHYSICAL R21 REPLAY (historical Nov 9)
   - Package+segment REHASH MATCH
   - NDJSON lines 14020 = ACC 7014 + GYRO 7004 + 2 non-sensor (open/close)
   - Historical 7014+7004 MATCH
   - Requested 100 Hz; actual ~100.15 Hz; duration ~70 s; gaps_gt_5x_median = 0
   - NIS/NEES NOT_COMPUTED (no innovation model / no independent angle reference)
   - Public-safe aggregates only; raw private; no device serial in public package

2. APP BUILD IDENTITY
   - CaptureEngine L0/L1/L3 consumer binding present in source
   - Unit tests reported PASS (see MACHINE)
   - Forced rebuild APK bytes=22946537 sha256=f191dd09e619e958273eacc3c6085de2d56554cc9deccf3acb33889b9029b6ab
   - Prior R1 APK candidate differed (hash change demonstrates source-driven rebuild; HOLD_BUILD_BIND closed for identity mismatch caveat)
   - Signer SHA-256 034a69d8… MATCH debug cert
   - APK_INSTALL = NO

3. WWW / BodyTwin browser acceptance (local)
   - Local static server 127.0.0.1:8765
   - Routes: / 200, /bodytwin/ 200 (77166/e9b3c574…), /research/bodytwin/ 200, missing 404
   - Desktop+mobile browser render observed; Soft-View present; BODYTWIN_VALIDATED=YES absent
   - Synthetic fixture -> typed projection -> independent readback PASS
   - WWW_LIVE_WRITE = NO; rollout prep + rollback only

4. STATIONARY ONE-SHOT PREP
   - Bundled operator freigabe packet filled (D1 install / D2 stationary / D3 www)
   - OWNER_ONE_SHOT = NOT_READY; effects not executed
   - PHYSICAL_14_GATES = 0_OF_14; ALT_D = ACTIVE preserved
   - Protocol digest bound

## HOLDS / residual

- NEW_CAPTURE = NO
- APK_INSTALL = NO
- WWW_LIVE_WRITE = NO
- BODYTWIN_VALIDATED = NO
- PFV_COMMIT = NO_DEFAULT (local sensor sources untracked/modified; not committed)
- Controlled roll = HOLD
- Privacy: public package sanitized; private R21 aggregate remains under TRANSFER private locus

## EXTERNAL

EXTERNAL_RESEARCH_READY = YES_FOR_HISTORICAL_PHYSICAL_C1_AGGREGATES
DESK_RESEARCH_ONLY = NOT_REQUIRED (historical replay available)
NEW_PHYSICAL_SESSION = AWAITING_BUNDLED_OWNER_DECISIONS
CURSOR_ACTION = NONE
NEXT = EXTERNAL_RESEARCH_LANE_WITH_HISTORICAL_C1_PLUS_OWNER_ONE_SHOT_IF_ANY

NEXUS Ω OMEGA
