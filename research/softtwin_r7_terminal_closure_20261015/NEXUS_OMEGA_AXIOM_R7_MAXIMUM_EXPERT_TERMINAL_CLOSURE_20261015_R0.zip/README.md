# NEXUS OMEGA / AXIOM — R7 Terminal Foundation Expert MAXI (prepared 2026-10-15)

**STATE:** `R7_MAXI_ORDER_PREPARED_C1_NOT_DISPATCHED`. This package is a research/expert **order**, not an R7 expert result, a production authorization, a cryptographic signature, or a claim that R7 has closed.

**Core goal:** close NEXUS Softtwin **C1 epistemic/static-evidence foundation** and, if actual evidence warrants, a **strictly scoped POSIX offline triage module**. Runtime REA/MCP/Windows/Hostinger activation remains **NOT_AUTHORIZED**.

Start with `docs/NEXUS_OMEGA_AXIOM_R7_MAXIMUM_EXPERT_TERMINAL_CLOSURE_ORDER_20261015_R0.md` (complete one-pass order). Read `docs/R7_CLOSURE_BOUNDARY_AND_PRIORITIES.md` (what remains) and `docs/R7_EXPERT_ASSIGNMENT_AND_SINGLE_RETURN.md` (independent expert division), then `schema/R7_CLOSURE_GATE_MATRIX.json` and `schema/R7_EXTERNAL_FINAL_RETURN_SCHEMA.json`.

Use `schema/R7_FINAL_RETURN_TEMPLATE.json` as a **HOLD-by-default** input. `tools/r7_closure_preflight.py` and its 20 tests validate transport/closure-envelope structure only; they do not prove the security of REA or grant authority.

## Reproducible local prep tests

```sh
python3 -m unittest discover -s tests -v
python3 tools/r7_closure_preflight.py --root . --return-json schema/R7_FINAL_RETURN_TEMPLATE.json
```

The second command intentionally yields structural suitability with HOLD gates; it is not a successful R7 scientific closure. Run actual V0.4 tests only inside a disposable owned POSIX test environment using the separately source-pinned R6 V0.4 capsule; do **not** run REA MCP, Ghidra, unknown binaries, or deploy Hostinger.

## Input evidence vs operator action

R6 private original remains PRIVATE; public experts use the public-safe R6 V0.4 branch described in the master order. A private ZIP source gap for outside experts does not invalidate accessible public-source exact bytes. Git publication is **not** a Cursor receiver ACK. There is no need for a local ZIP path search.

**Exactly one external consolidated R7 return. No microorders.** Upon receipt AXIOM independently adjudicates against G0–G9, and only then is foundation and/or module closure decided.
