import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
import r7_closure_preflight as c


class EnvelopePreflightTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name)
        self.content=b'R7 OWNED SYNTHETIC SOURCE\n'
        (self.root/'source.txt').write_bytes(self.content)
        t=Path(__file__).resolve().parents[1] / 'schema/R7_FINAL_RETURN_TEMPLATE.json'
        self.o=json.loads(t.read_text())
        self.o['sources']=[{'path':'source.txt','sha256':hashlib.sha256(self.content).hexdigest(), 'bytes':len(self.content),'evidence_class':'ACTUAL_BYTES_REHASHED'}]

    def tearDown(self):self.temp.cleanup()

    def result(self, obj=None):return c.evaluate(self.root, self.o if obj is None else obj)

    def full(self):
        for g in self.o['gates']:
            g['status']='PASS_PROVED_AND_SOURCE_BOUND' if g['id'] in ('G5','G6') else 'PASS_EXECUTED_AND_REVIEWED'
            g['reason']='SOURCE_EXACT_CONFORMANCE_REQUIRES_REAL_REVIEW'
            g['evidence_refs']=['source.txt']
            g['independent_reviewer']='SYNTHETIC_REVIEWER_NOT_REAL'
        # G8 is a performance gate and must remain scope-excluded in static mode
        self.o['gates'][8]['status']='SCOPE_EXCLUDED_NOT_AUTHORIZED'
        self.o['gates'][8]['reason']='NO_PERFORMANCE_CLAIM'
        self.o['gates'][8]['evidence_refs']=[]
        self.o['scope']['foundation']='RECOMMEND_CLOSE_F1'
        self.o['scope']['module']='RECOMMEND_CLOSE_M1'

    def test_01_template_holds_without_fabricated_pass(self):
        r=self.result();self.assertEqual(r['state'],'SCHEMA_SUITABLE_NOT_ADJUDICATED');self.assertFalse(r['foundation_recommendation_eligible'])
    def test_02_all_nominal_pass_remains_only_review_eligible(self):
        self.full();r=self.result();self.assertEqual(r['state'],'SCHEMA_SUITABLE_NOT_ADJUDICATED');self.assertTrue(r['module_recommendation_eligible']);self.assertEqual(r['scientific_or_security_proof_by_this_tool'],'NO')
    def test_03_source_tamper_rejected(self):
        (self.root/'source.txt').write_bytes(b'OTHER');self.assertIn('SOURCE_HASH_OR_SIZE_MISMATCH_0',self.result()['errors'])
    def test_04_no_autoexec(self):
        self.o['permissions']['cursor_autostart']=True;self.assertIn('PERMISSION_ESCALATION',self.result()['errors'])
    def test_05_hostinger_denied(self):
        self.o['permissions']['hostinger_write']=True;self.assertIn('PERMISSION_ESCALATION',self.result()['errors'])
    def test_06_no_false_foundation_closure(self):
        self.o['scope']['foundation']='RECOMMEND_CLOSE_F1';self.assertIn('FALSE_FOUNDATION_CLOSURE',self.result()['errors'])
    def test_07_no_false_module_closure(self):
        self.o['scope']['module']='RECOMMEND_CLOSE_M1';self.assertIn('FALSE_MODULE_CLOSURE',self.result()['errors'])
    def test_08_missing_gate(self):
        self.o['gates'].pop();self.assertIn('GATES_NOT_EXACT_G0_G9',self.result()['errors'])
    def test_09_duplicate_gate(self):
        self.o['gates'][1]['id']='G0';self.assertIn('GATES_NOT_EXACT_G0_G9',self.result()['errors'])
    def test_10_invalid_static_proof_for_runtime_gate(self):
        self.o['gates'][1].update(status='PASS_PROVED_AND_SOURCE_BOUND',evidence_refs=['source.txt'],independent_reviewer='fixture');self.assertIn('STATIC_PROOF_NOT_ALLOWED_G1',self.result()['errors'])
    def test_11_pass_without_proof_rejected(self):
        self.o['gates'][1]['status']='PASS_EXECUTED_AND_REVIEWED';self.assertIn('PASS_WITHOUT_REFERENCED_REVIEW_G1',self.result()['errors'])
    def test_12_absolute_path_rejected(self):
        self.o['sources'][0]['path']='/etc/passwd';self.assertIn('SOURCE_NOT_BOUND_0_ValueError',self.result()['errors'])
    def test_13_parent_traversal_rejected(self):
        self.o['sources'][0]['path']='../elsewhere';self.assertIn('SOURCE_NOT_BOUND_0_ValueError',self.result()['errors'])
    def test_14_symlink_rejected(self):
        (self.root/'link').symlink_to('source.txt');self.o['sources'][0]['path']='link';self.assertIn('SOURCE_NOT_BOUND_0_ValueError',self.result()['errors'])
    def test_15_bad_claim_ceiling(self):
        self.o['claim_ceiling']='C2';self.assertIn('CEILING_MISMATCH',self.result()['errors'])
    def test_16_false_ack_rejected(self):
        self.o['transport']['receiver_ack']='ACTUAL_BYTE_RECEIPT_WITH_PROOF';self.assertIn('INVENTED_RECEIVER_ACK',self.result()['errors'])
    def test_17_missing_hold_reason(self):
        self.o['gates'][0]['reason']='';self.assertIn('MISSING_HOLD_REASON_G0',self.result()['errors'])
    def test_18_unsigned_receiver_not_required(self):
        self.assertNotIn('INVENTED_RECEIVER_ACK',self.result()['errors'])
    def test_19_missing_source_not_silently_passed(self):
        (self.root/'source.txt').unlink();self.assertIn('SOURCE_NOT_BOUND_0_FileNotFoundError',self.result()['errors'])
    def test_20_both_scopes_separate(self):
        self.full();self.o['gates'][2]['status']='HOLD_WITH_PRECISE_REASON';self.o['gates'][2]['reason']='PARSER_NOT_RERUN';self.o['scope']['module']='HOLD_M1';r=self.result();self.assertTrue(r['foundation_recommendation_eligible']);self.assertFalse(r['module_recommendation_eligible'])

if __name__=='__main__':unittest.main()
