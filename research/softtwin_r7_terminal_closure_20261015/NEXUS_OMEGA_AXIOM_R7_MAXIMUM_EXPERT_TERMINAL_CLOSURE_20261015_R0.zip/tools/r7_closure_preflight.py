#!/usr/bin/env python3
"""Offline R7 manifest/gate preflight. It NEVER adjudicates scientific truth or grants action authority.

Usage: python3 tools/r7_closure_preflight.py --root /path/to/unpacked_return --return-json FINAL_RETURN.json
Exit 0 = envelope structurally suitable for independent AXIOM adjudication (not closure).
Exit 2 = structural HOLD/fail; does not execute target code or use network.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys

PASS = {'PASS_EXECUTED_AND_REVIEWED', 'PASS_PROVED_AND_SOURCE_BOUND'}
IDS = {f'G{i}' for i in range(10)}
FOUNDATION = {'G0','G4','G5','G6','G7','G9'}
MODULE = {'G0','G1','G2','G3','G4','G7','G9'}
ALLOWED = PASS | {'FAIL_REPRODUCED','HOLD_WITH_PRECISE_REASON','SCOPE_EXCLUDED_NOT_AUTHORIZED','EXTERNAL_REPORTED_ONLY'}
EXPECTED_OBJECT = 'NEXUS_OMEGA_R7_EXTERNAL_COLLECTIVE_TERMINAL_FOUNDATION_RETURN_20261015_R0'
EXPECTED_PERM = {'hostinger_write','mcp_install','main_merge','cursor_autostart','third_party_target_execution','node_birth'}


def _safe_file(root: Path, name: str) -> Path:
    if not isinstance(name,str) or '\\' in name or not name or name.startswith('/'):
        raise ValueError('INVALID_RELATIVE_PATH')
    p=PurePosixPath(name)
    if any(part in ('','.', '..') for part in p.parts):
        raise ValueError('UNSAFE_PATH_COMPONENT')
    target=root.joinpath(*p.parts)
    base=root.resolve(strict=True)
    if not target.resolve(strict=True).is_relative_to(base):
        raise ValueError('PATH_ESCAPE')
    for i in range(1,len(p.parts)+1):
        if os.path.islink(root.joinpath(*p.parts[:i])):
            raise ValueError('SYMLINK_IN_PATH')
    st=target.lstat()
    if not stat.S_ISREG(st.st_mode):
        raise ValueError('NOT_REGULAR_FILE')
    return target


def evaluate(root: Path, obj: dict) -> dict:
    errors=[]
    if not isinstance(obj,dict):
        return {'state':'HOLD_BAD_RETURN','errors':['NOT_OBJECT']}
    if obj.get('object')!=EXPECTED_OBJECT: errors.append('OBJECT_MISMATCH')
    if obj.get('claim_ceiling')!='C1_DESCRIPTIVE_ONLY':errors.append('CEILING_MISMATCH')
    if obj.get('authority')!='EXTERNAL_RESEARCH_ONLY': errors.append('AUTHORITY_MISMATCH')
    perms=obj.get('permissions',{})
    if set(perms)!=EXPECTED_PERM or any(perms.get(k) is not False for k in EXPECTED_PERM):errors.append('PERMISSION_ESCALATION')
    scope=obj.get('scope',{})
    if scope.get('production')!='NOT_AUTHORIZED' or scope.get('rea_mcp_runtime')!='NOT_AUTHORIZED' or scope.get('windows') not in ('NOT_CLAIMED','NOT_TESTED'): errors.append('SCOPE_ESCALATION')
    gates=obj.get('gates',[])
    if not isinstance(gates,list) or len(gates)!=10 or {g.get('id') for g in gates if isinstance(g,dict)}!=IDS:errors.append('GATES_NOT_EXACT_G0_G9')
    gate_by_id={g['id']:g for g in gates if isinstance(g,dict) and isinstance(g.get('id'),str)}
    for gid,g in gate_by_id.items():
        s=g.get('status')
        if s not in ALLOWED:errors.append('INVALID_GATE_STATUS_'+gid)
        if s in PASS and (not g.get('evidence_refs') or not g.get('independent_reviewer')):
            errors.append('PASS_WITHOUT_REFERENCED_REVIEW_'+gid)
        if s=='PASS_PROVED_AND_SOURCE_BOUND' and gid not in {'G5','G6'}:
            errors.append('STATIC_PROOF_NOT_ALLOWED_'+gid)
        if s not in PASS and not g.get('reason'):
            errors.append('MISSING_HOLD_REASON_'+gid)
    sources=obj.get('sources',[])
    if not isinstance(sources,list) or not sources:errors.append('SOURCES_MISSING')
    else:
        seen=set()
        for i,s in enumerate(sources):
            if not isinstance(s,dict):errors.append('BAD_SOURCE_OBJECT');continue
            name=s.get('path','')
            if name in seen:errors.append('DUPLICATE_SOURCE_PATH')
            seen.add(name)
            if s.get('evidence_class')!='ACTUAL_BYTES_REHASHED':continue
            try:
                file=_safe_file(root,name)
                before=file.stat()
                if before.st_size>128*1024*1024:raise ValueError('SOURCE_OVERSIZE')
                data=file.read_bytes()
                after=file.stat()
                if (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns, before.st_ctime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns):raise ValueError('SOURCE_CHANGED')
                if len(data)!=s.get('bytes') or hashlib.sha256(data).hexdigest()!=s.get('sha256'):
                    errors.append('SOURCE_HASH_OR_SIZE_MISMATCH_'+str(i))
            except (OSError,ValueError) as e:errors.append('SOURCE_NOT_BOUND_'+str(i)+'_'+type(e).__name__)
    foundation_all=all(gate_by_id.get(k,{}).get('status') in PASS for k in FOUNDATION)
    module_all=all(gate_by_id.get(k,{}).get('status') in PASS for k in MODULE)
    if scope.get('foundation')=='RECOMMEND_CLOSE_F1' and not foundation_all:errors.append('FALSE_FOUNDATION_CLOSURE')
    if scope.get('module')=='RECOMMEND_CLOSE_M1' and not module_all:errors.append('FALSE_MODULE_CLOSURE')
    transport=obj.get('transport',{})
    if transport.get('receiver_ack')=='ACTUAL_BYTE_RECEIPT_WITH_PROOF':
        if not any('receiver_receipt' in x.get('path','').lower() for x in sources if isinstance(x,dict)):
            errors.append('INVENTED_RECEIVER_ACK')
    result='SCHEMA_SUITABLE_NOT_ADJUDICATED' if not errors else 'HOLD_OR_REJECT_BAD_ENVELOPE'
    return {'state':result,'errors':sorted(set(errors)),'foundation_recommendation_eligible':foundation_all and not errors,'module_recommendation_eligible':module_all and not errors, 'scientific_or_security_proof_by_this_tool':'NO', 'operator_authority_granted':'NO'}


def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--root',required=True,type=Path)
    p.add_argument('--return-json',required=True)
    a=p.parse_args(argv)
    try:
        path=_safe_file(a.root,a.return_json)
        obj=json.loads(path.read_text('utf-8'))
        result=evaluate(a.root,obj)
    except (OSError,ValueError,json.JSONDecodeError) as e:
        result={'state':'HOLD_BAD_INPUT','errors':[type(e).__name__], 'scientific_or_security_proof_by_this_tool':'NO'}
    print(json.dumps(result,sort_keys=True,separators=(',',':')))
    return 0 if result['state']=='SCHEMA_SUITABLE_NOT_ADJUDICATED' else 2

if __name__=='__main__':raise SystemExit(main())
