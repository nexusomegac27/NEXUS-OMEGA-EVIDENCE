# Expert assignment — maximum independent epistemic yield

One umbrella order; specialists can work in parallel. Roles express **requested competence**, not an assertion that particular providers possess professional accreditation or will execute. All must be independently source-bound.

| Independent expert role | Evidence obligation | How to falsify own favorite conclusion |
|---|---|---|
| Low-level Linux/POSIX security specialist | root-fd admission, /proc fd use, fcntl lease and SIGIO semantics, filesystem and privilege gates, concurrent-writer experiments | demonstrate a successful same-scope bypass, or explicitly narrow security claim and show gate is enforced |
| Archive/parser reverse engineer | ZIP APPNOTE normative interpretation, independent parser differential, EOCD/CD/local/data-descriptor/ZIP64 boundaries; bounded decompression | construct an accepted contradictory archive whose structure isn't inventoried, or prove strict valid-format policy rejection is deliberate |
| Formal methods/MCP capability-security specialist | typed evidence union, NoAuthority invariants, event/replay/CAS design; executable adversarial tests, optional TLC rerun | find a source text or forged tool reply that changes authority/persistence; construct same-CAS-key distinct observations |
| Mathematical controls/estimation expert | proof with sharp signed-λ gain, initial transient, c0/l2 witness, negative λ counterexample, matrix limitation | find missing hypothesis or a finite counterexample to the updated theorem; prove canonical erratum really bound |
| Provenance/supply-chain/legal expert | R6 exact source custody, npm/Git not conflated, legal scope, rights/redaction, signer separation | demonstrate wrong git object/content, forged ACK, legal case mismatch, or redaction of private bytes |
| CPU/experimental-design expert | predeclared baseline and conditional performance protocol; no fabricated measurements | construct stronger cheaper null model or detect task/oracle leakage; do not infer KVM2 performance from synthetic tests |
| Adversarial integrating reviewer (not lane author) | rerun critical code/tests and challenge strongest finding; return unified machine manifest | reject majority agreement when one byte-bound counterexample disagrees |

## Review quality controls

Each lane includes: `QUESTION`, `NULL_MODEL`, `STRONGEST_COUNTERHYPOTHESIS`, `PRIMARY_BYTES`, `TOOLCHAIN`, `EXECUTED_COMMANDS`, `FIXTURES`, `EXPECTED_AND_ACTUAL`, `NEGATIVE_CONTROL`, `FALSE_POSITIVE_RISK`, `DIFFERENTIAL_BEFORE_AFTER`, `UNCERTAINTY`, `CLAIM_SCOPE`, `NEXT_NOT_REQUIRED_IF_CLOSED`. Distinguish observation/inference. Require each expert to separately sign their **authorship declaration** in prose; this is not a cryptographic signature. If an independent second opinion comes from the same model/session, state that fact.

The R7 integrator scores factual closure, not words/tokens: accepted new falsifications, repaired with both failing predecessor and passing successor, runtime control failures, unreproduced claims rejected, and operator touches avoided. Scores are secondary and may never compensate a failed critical gate.

No unsolicited multi-turn feedback loop. On target tool limits, the expert returns the entire technically possible scoped finding and `HOLD_WITH_PRECISE_REASON`. R7 completes one research cycle even if framework closure remains HOLD.
