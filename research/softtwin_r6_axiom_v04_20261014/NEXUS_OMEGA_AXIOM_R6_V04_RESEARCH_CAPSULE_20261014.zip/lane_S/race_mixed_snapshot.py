"""S12/S13/S5: in-place hostile writer vs fd-bound snapshot. OWNED_SYNTHETIC_LOCAL.
Writer process alternately pwrite()s full content A or B (same size) into the same inode.
A result whose sha256 is neither sha(A) nor sha(B) and which was NOT denied = undetected mixed snapshot."""
import hashlib, multiprocessing as mp, os, sys, tempfile, time, json, importlib
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'src'))
SIZE = int(os.environ.get('RACE_SIZE', 4*1024*1024)); N = int(os.environ.get('RACE_N', 300))
def writer(path, A, B, stop):
    reopen = os.environ.get('RACE_REOPEN') == '1'; i = 0
    fd = None if reopen else os.open(path, os.O_WRONLY)
    while not stop.is_set():
        if reopen: fd = os.open(path, os.O_WRONLY)   # may block on a read lease until the reader releases
        os.pwrite(fd, A if i % 2 else B, 0); i += 1
        if reopen: os.close(fd); time.sleep(0.0005)
    if not reopen: os.close(fd)
def run(modname):
    m = importlib.import_module(modname)
    d = tempfile.mkdtemp(); root = Path(d); p = root/'x.bin'
    A = b'A'*SIZE; B = b'B'*SIZE; p.write_bytes(A)
    ha, hb = hashlib.sha256(A).hexdigest(), hashlib.sha256(B).hexdigest()
    stop = mp.Event(); w = mp.Process(target=writer, args=(str(p), A, B, stop)); w.start(); time.sleep(0.05)
    res = {'clean_A_or_B': 0, 'denied': 0, 'undetected_mixed': 0, 'other_error': 0}
    for _ in range(N):
        try:
            r = m.triage(root, p, 'NEXUS_R6_RACE_FIXTURE')
            res['clean_A_or_B' if r['source_sha256'] in (ha, hb) else 'undetected_mixed'] += 1
        except m.Denied: res['denied'] += 1
        except Exception: res['other_error'] += 1
    stop.set(); w.join()
    return res
if __name__ == '__main__':
    out = {mod: run(mod) for mod in sys.argv[1:]}
    out['params'] = {'size': SIZE, 'iterations': N, 'mode': 'ACTUAL_EXECUTED', 'fs_block': os.statvfs('/tmp').f_bsize, 'writer_reopen_each_write': os.environ.get('RACE_REOPEN') == '1'}
    print(json.dumps(out, sort_keys=True))
