"""Deterministic mutation fuzz (seeded): which versions leak non-Denied exceptions from ZIP parsing? OWNED_SYNTHETIC_LOCAL."""
import io, json, random, sys, tempfile, zipfile, importlib
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'src'))
def seed_zip():
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('a.txt', b'hello world ' * 50); z.writestr('d/', b''); z.writestr('d/b.bin', bytes(range(256)))
    return b.getvalue()
N = int(sys.argv[1]) if len(sys.argv) > 1 else 3000
base = seed_zip(); out = {}
for v in ['nexus_artifact_triage_v0','nexus_artifact_triage_v01','nexus_artifact_triage_v02','nexus_artifact_triage_v03','nexus_artifact_triage_v04']:
    m = importlib.import_module(v); rng = random.Random(20261014); stats = {'accepted':0,'denied':0,'unhandled':{}}
    with tempfile.TemporaryDirectory() as d:
        root = Path(d); p = root/'f.zip'
        for _ in range(N):
            b = bytearray(base)
            for _ in range(rng.randint(1, 4)): b[rng.randrange(4, len(b))] = rng.randrange(256)
            p.write_bytes(bytes(b))
            try: m.triage(root, p, 'NEXUS_R6_FUZZ_CASE'); stats['accepted'] += 1
            except m.Denied: stats['denied'] += 1
            except Exception as e:
                k = type(e).__name__; stats['unhandled'][k] = stats['unhandled'].get(k, 0) + 1
    out[v.split('_')[-1]] = stats
out['params'] = {'mutations': N, 'seed': 20261014, 'mode': 'ACTUAL_EXECUTED', 'seed_zip_sha256': __import__('hashlib').sha256(base).hexdigest()}
print(json.dumps(out, sort_keys=True))
