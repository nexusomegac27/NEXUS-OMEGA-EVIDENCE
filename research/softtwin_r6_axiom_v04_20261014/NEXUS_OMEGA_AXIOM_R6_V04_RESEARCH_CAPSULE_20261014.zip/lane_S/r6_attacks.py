"""R6 new one-defect adversarial cases against triage V0 / V0.1 / V0.2(prior external return) / V0.3(this return).
OWNED_SYNTHETIC_LOCAL only: temp dirs, synthetic bytes, no network, no extraction to disk, no target execution."""
import io, os, struct, sys, time, zlib, zipfile, mmap, json, importlib, multiprocessing as mp, tempfile, hashlib
from pathlib import Path
SRC = Path(__file__).resolve().parents[1]/'src'; sys.path.insert(0, str(SRC))
CASE = 'NEXUS_R6_ATTACK_FIXTURE'
VERSIONS = ['nexus_artifact_triage_v0', 'nexus_artifact_triage_v01', 'nexus_artifact_triage_v02', 'nexus_artifact_triage_v03']

def zbytes(entries, method=zipfile.ZIP_STORED):
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w', method) as z:
        for n, d in entries: z.writestr(n, d)
    return bytearray(b.getvalue())

def eocd(d): return d.rfind(b'PK\x05\x06')
def cd_records(d):
    e = eocd(d); n, size, off = struct.unpack_from('<HII', d, e+10)
    recs = []; p = off
    for _ in range(n):
        fl, el, cl = struct.unpack_from('<HHH', d, p+28); L = 46+fl+el+cl
        recs.append((p, L)); p += L
    return recs, off, size, e

# each case: setup(tmp) -> (root, path, ctx) ; ctx may hold cleanup / observers
def c_root_intermediate_symlink(t):
    (t/'holder'/'data').mkdir(parents=True); (t/'holder'/'data'/'f.bin').write_bytes(b'\x7fELF' + b'0'*12)
    (t/'alias').symlink_to(t/'holder', target_is_directory=True)
    return t/'alias'/'data', t/'alias'/'data'/'f.bin', {}
def c_hardlink(t):
    (t/'outside').mkdir(); (t/'outside'/'secret.bin').write_bytes(b'OUTSIDE_OWNED_BYTES')
    (t/'root').mkdir(); os.link(t/'outside'/'secret.bin', t/'root'/'a.bin')
    return t/'root', t/'root'/'a.bin', {}
def _fifo_writer(p, flag):
    fd = os.open(p, os.O_WRONLY)  # blocks until some reader opens the FIFO
    Path(flag).write_text('UNBLOCKED'); os.close(fd)
def c_fifo_open_side_effect(t):
    p = t/'f.fifo'; os.mkfifo(p); flag = t/'flag'
    w = mp.Process(target=_fifo_writer, args=(str(p), str(flag))); w.start(); time.sleep(0.2)
    def observe():
        time.sleep(0.3); un = flag.exists()
        if w.is_alive():
            fd = os.open(p, os.O_RDONLY | os.O_NONBLOCK); time.sleep(0.2); os.close(fd)
        w.join(2)
        return {'blocked_fifo_writer_released_by_triage': un}
    return t, p, {'observe': observe}
def _holder(p, ev, mode):
    fd = os.open(p, os.O_RDWR)
    if mode == 'mmap':
        mm = mmap.mmap(fd, 0, mmap.MAP_SHARED, mmap.PROT_READ | mmap.PROT_WRITE); os.close(fd)
    ev.wait(10)
def _writer_holder(t, mode):
    p = t/'a.bin'; p.write_bytes(b'\x7fELF' + b'1'*60); ev = mp.Event()
    h = mp.Process(target=_holder, args=(str(p), ev, mode)); h.start(); time.sleep(0.3)
    return t, p, {'observe': lambda: (ev.set(), h.join(5), {})[2]}
def c_writer_fd_held(t): return _writer_holder(t, 'fd')
def c_writable_mmap_held(t): return _writer_holder(t, 'mmap')
def _zipcase(t, data):
    p = t/'a.zip'; p.write_bytes(bytes(data)); return t, p, {}
def c_bidi_override(t): return _zipcase(t, zbytes([('invoice\u202etxt.exe', b'x')]))
def c_zero_width_dup(t): return _zipcase(t, zbytes([('ab', b'x'), ('a\u200bb', b'y')]))
def c_superscript_com(t): return _zipcase(t, zbytes([('COM\u00b9.txt', b'x')]))
def c_conin(t): return _zipcase(t, zbytes([('CONIN$', b'x')]))
def c_c1_control(t): return _zipcase(t, zbytes([('a\u0085b', b'x')]))
def c_eocd_count_mismatch(t):
    d = zbytes([('a', b'1'), ('b', b'2')]); e = eocd(d); struct.pack_into('<HH', d, e+8, 1, 1); return _zipcase(t, d)
def c_overlapping_entries(t):
    d = zbytes([('a', b'A'*64), ('b', b'B'*64)]); recs, off, size, e = cd_records(d)
    p = recs[0][0]; cs = struct.unpack_from('<I', d, p+20)[0]
    struct.pack_into('<I', d, p+20, cs + 30 + 1 + 64)  # entry a's compressed span now swallows entry b
    return _zipcase(t, d)
def c_hidden_local_entry(t):
    d = zbytes([('a', b'A'*8), ('hidden.exe', b'MZ' + b'H'*30), ('c', b'C'*8)])
    recs, off, size, e = cd_records(d); (p1, L1) = recs[1]
    new = d[:p1] + d[p1+L1:]; e2 = e - L1
    struct.pack_into('<HHI', new, e2+8, 2, 2, size - L1)
    return _zipcase(t, new)
def c_declared_size_lie_deflate(t):
    payload = b'\0' * (8*1024*1024)
    d = zbytes([('big', payload)], zipfile.ZIP_DEFLATED); recs, off, size, e = cd_records(d)
    cs = struct.unpack_from('<I', d, recs[0][0]+20)[0]
    struct.pack_into('<I', d, recs[0][0]+24, cs*10)        # central: declared uncompressed tiny (ratio ok)
    struct.pack_into('<I', d, 22, cs*10)                     # local header too
    return _zipcase(t, d)
def c_stored_crc_flip(t):
    d = zbytes([('a.txt', b'GOOD-PAYLOAD')]); i = d.find(b'GOOD'); d[i] = ord('B'); return _zipcase(t, d)
def c_polyglot_prefix(t):
    z = zbytes([('payload.exe', b'MZ' + b'p'*40)]); return _zipcase(t, bytearray(b'#!/bin/sh\necho hi\n') + z)
def c_mz_appended_zip(t):
    z = zbytes([('../../evil', b'x')]); return _zipcase(t, bytearray(b'MZ' + b'\0'*62) + z)

CASES = [
 ('R6-S01','S10b','root intermediate symlink (prior V0.2 claim)', c_root_intermediate_symlink, 'DENIED'),
 ('R6-S02','S09','hardlink to outside-owned bytes (nlink=2)', c_hardlink, 'DENIED'),
 ('R6-S03','S07','FIFO open side effect: blocked writer released by triage open()', c_fifo_open_side_effect, 'DENIED_NO_SIDE_EFFECT'),
 ('R6-S04','S12','writer fd held open during capture', c_writer_fd_held, 'DENIED'),
 ('R6-S05','S12','writable MAP_SHARED mapping held (fd closed)', c_writable_mmap_held, 'DENIED'),
 ('R6-S06','S19','bidi override U+202E in member name', c_bidi_override, 'DENIED'),
 ('R6-S07','S19','zero-width U+200B visual duplicate', c_zero_width_dup, 'DENIED'),
 ('R6-S08','S21','Windows reserved COM superscript-1', c_superscript_com, 'DENIED'),
 ('R6-S09','S21','Windows reserved CONIN$', c_conin, 'DENIED'),
 ('R6-S10','S19','C1 control U+0085 (NEL) in name', c_c1_control, 'DENIED'),
 ('R6-S11','S15','EOCD entry count != central directory records (parser differential)', c_eocd_count_mismatch, 'DENIED'),
 ('R6-S12','S18','overlapping entry spans (central compress_size enlarged)', c_overlapping_entries, 'DENIED'),
 ('R6-S13','S15','hidden local entry not referenced by central directory', c_hidden_local_entry, 'DENIED'),
 ('R6-S14','S26','deflate actual 8 MiB vs declared ~small (ratio check passes)', c_declared_size_lie_deflate, 'DENIED'),
 ('R6-S15','S16','stored data byte flipped, CRC stale, headers untouched', c_stored_crc_flip, 'DENIED'),
 ('R6-S16','S27','script prefix + ZIP polyglot classified non-ZIP', c_polyglot_prefix, 'ACCEPTED_FLAGGED'),
 ('R6-S17','S27','MZ + appended ZIP with traversal member', c_mz_appended_zip, 'ACCEPTED_FLAGGED'),
]

def run_case(modname, fn):
    m = importlib.import_module(modname)
    with tempfile.TemporaryDirectory() as d:
        t = Path(d); root, path, ctx = fn(t)
        raw = Path(path).read_bytes() if Path(path).is_file() and not Path(path).is_symlink() else b''
        t0 = time.perf_counter()
        try:
            r = m.triage(root, path, CASE); res = {'result': 'ACCEPTED', 'embedded_zip_polyglot': r.get('embedded_zip_polyglot'), 'artifact_type': r['artifact_type']}
        except m.Denied as e: res = {'result': 'DENIED', 'code': str(e)}
        except Exception as e: res = {'result': 'UNHANDLED_EXCEPTION', 'code': type(e).__name__ + ':' + str(e)[:80]}
        res['ms'] = round((time.perf_counter()-t0)*1000, 2)
        if 'observe' in ctx: res.update(ctx['observe']())
        res['fixture_sha256'] = hashlib.sha256(raw).hexdigest() if raw else 'NON_REGULAR_OR_LINK'
        return res

def classify(exp, res):
    if exp == 'DENIED': return res['result'] == 'DENIED'
    if exp == 'DENIED_NO_SIDE_EFFECT': return res['result'] == 'DENIED' and not res.get('blocked_fifo_writer_released_by_triage')
    if exp == 'ACCEPTED_FLAGGED': return res['result'] == 'ACCEPTED' and res.get('embedded_zip_polyglot') is True
if __name__ == '__main__':
    out = []
    for cid, smap, desc, fn, exp in CASES:
        row = {'case_id': cid, 'order_slot': smap, 'description': desc, 'expected_safe': exp, 'mode': 'ACTUAL_EXECUTED', 'scope': 'OWNED_SYNTHETIC_LOCAL'}
        for v in VERSIONS:
            res = run_case(v, fn); res['meets_expectation'] = classify(exp, res); row[v.split('_')[-1]] = res
        out.append(row); print(json.dumps(row, sort_keys=True, ensure_ascii=True))
