"""SOFTTWIN_EVIDENCE_ADAPTER_V0 checkable policy (R6 Lane P). Deterministic, stdlib only.
Authority is computed ONLY from the out-of-band operator grant set; record content is data."""
import json, re, hashlib
TYPES = {"STATIC_OBSERVED","DECOMPILED_INFERRED","RUNTIME_OBSERVED","RECONSTRUCTED_BEHAVIOR","UNKNOWN","CONTRADICTED"}
REQUIRED = {"type","case_id","source_sha256","scope","tool_profile_digest","method","observed","unobserved_alternatives","claim_ceiling","action_authority"}
ALLOWED = REQUIRED | {"notes"}
INJECTION_PATTERNS = [r"(?i)ignore (all|previous)", r"(?i)\bauthority\b\"?\s*[:=]", r"(?i)run\s+(this|the following)", r"(?i)curl\s+http", r"(?i)upload", r"(?i)you are now", r"(?i)system\s*:", r"(?i)readOnlyHint"]
class Reject(ValueError): pass
def validate(rec: dict, profile_registry: dict, received: dict):
    if not isinstance(rec, dict): raise Reject("NOT_OBJECT")
    unk = set(rec) - ALLOWED
    if unk: raise Reject("UNKNOWN_FIELDS:" + ",".join(sorted(unk)))
    miss = REQUIRED - set(rec)
    if miss: raise Reject("MISSING_FIELDS:" + ",".join(sorted(miss)))
    if rec["type"] not in TYPES: raise Reject("TYPE_INVALID")
    if rec["claim_ceiling"] != "C1_DESCRIPTIVE_ONLY": raise Reject("CLAIM_CEILING_ESCALATION")
    if rec["action_authority"] != "NONE": raise Reject("AUTHORITY_FIELD_IN_DATA")
    if not re.fullmatch(r"[0-9a-f]{64}", str(rec["source_sha256"])): raise Reject("SHA_INVALID")
    if rec["tool_profile_digest"] not in profile_registry: raise Reject("PROFILE_UNKNOWN")
    if profile_registry[rec["tool_profile_digest"]].get("stale"): raise Reject("PROFILE_STALE")
    if rec["source_sha256"] not in received: raise Reject("PAYLOAD_ABSENT")   # SIGNED_MANIFEST != RECEIVED_BYTES
    if hashlib.sha256(received[rec["source_sha256"]]).hexdigest() != rec["source_sha256"]: raise Reject("RECEIVED_BYTES_HASH_MISMATCH")
    if rec["type"] == "DECOMPILED_INFERRED" and "ORIGINAL_SOURCE" in json.dumps(rec["observed"]): raise Reject("DECOMPILED_NE_ORIGINAL_SOURCE")
    if rec["type"] != "RUNTIME_OBSERVED" and re.search(r"(?i)\b(executed|runtime pass|ran successfully)\b", json.dumps(rec["observed"])): raise Reject("RUNTIME_CLAIM_WITHOUT_RUNTIME_TYPE")
    return True
def authority(operator_grants: frozenset, *_untrusted):
    """Ignores every positional untrusted argument by construction: the only input is the operator grant set."""
    return frozenset(operator_grants)
def injection_markers(text: str):
    return [p for p in INJECTION_PATTERNS if re.search(p, text)]
def decide(action: str, operator_grants: frozenset, tool_annotations: dict, evidence_flags: dict):
    # READONLY_TOOL_HINT != OS_CAPABILITY ; RECEIVED_BYTES != EXECUTION_AUTHORIZATION ; SOURCE_HASH != SCIENTIFIC_TRUTH
    return action in authority(operator_grants)
