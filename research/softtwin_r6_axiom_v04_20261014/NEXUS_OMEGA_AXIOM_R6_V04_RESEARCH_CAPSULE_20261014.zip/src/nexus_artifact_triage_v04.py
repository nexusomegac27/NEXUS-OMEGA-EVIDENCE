#!/usr/bin/env python3
"""NEXUS REA offline static triage V0.4 research candidate (R6 external return, derived from V0.1 sha256 f8cf9704...).

V0.3 deltas vs V0.1 (each with a one-defect before/after fixture in tests/test_r6_attacks.py):
 R6-F01 root path opened component-wise from "/" with O_NOFOLLOW (intermediate symlink denied, correct code)
 R6-F02 O_PATH pre-open + fstat: FIFOs/devices are never opened for reading (no open side effect)
 R6-F03 Linux read lease (F_SETLEASE F_RDLCK): deny if any writer holds/opens the inode during capture
 R6-F04 hardlink nlink>1 denied
 R6-F05 Unicode Cc/Cf/Cs/Co/Cn/Zl/Zp in member names denied; superscript COM/LPT, COM0/LPT0, CONIN$/CONOUT$ reserved
 R6-F06 EOCD entry count must equal parsed central directory count
 R6-F07 local entry spans must be in-bounds, non-overlapping and gap-free up to the central directory
 R6-F08 bounded in-memory decompression: actual size and CRC must equal declaration (no disk write)
 R6-F09 any unexpected parser exception -> Denied (no raw crash)
 R6-F10 embedded/polyglot ZIP in non-ZIP bytes is flagged


Linux/POSIX-only: anchored openat traversal, fd-bound bounded read, hash and
ZIP directory/headers checked against the same captured byte string. No
network, subprocess, extraction, runtime attachment or auth decisions.

Not a sandbox, not a guarantee against in-place hostile writers, no Windows
support without separate native file-handle security review. C1 only.
"""
from __future__ import annotations
import argparse
import hashlib
import errno
import io
import json
import os
from pathlib import Path
import re
import stat
import struct
import sys
import unicodedata
import zipfile

SCHEMA = "NEXUS_REA_STATIC_TRIAGE_V0_4_C1"
import fcntl, signal
MAX_FILE = 32 * 1024 * 1024
MAX_ENTRIES = 512
MAX_UNCOMPRESSED = 128 * 1024 * 1024
MAX_RATIO = 200
CASE_RE = re.compile(r"NEXUS_[A-Z0-9_]{4,120}\Z")
_OPEN_SUPPORTS_DIR_FD = os.open in os.supports_dir_fd
WIN_RESERVED = re.compile(r"^(CON|PRN|AUX|NUL|CONIN\$|CONOUT\$|COM[0-9\u00b9\u00b2\u00b3]|LPT[0-9\u00b9\u00b2\u00b3])(?:\..*)?$", re.I)
BAD_UNICODE_CATS = {"Cc","Cf","Cs","Co","Cn","Zl","Zp"}

class Denied(ValueError):
    pass

def _kind(prefix: bytes, filename: str = "") -> str:
    if prefix.startswith(b"\x7fELF"): return "ELF"
    if prefix.startswith(b"MZ"): return "PE_CANDIDATE_MZ_ONLY"
    if prefix[:4] in (b"\xfe\xed\xfa\xce", b"\xfe\xed\xfa\xcf", b"\xce\xfa\xed\xfe", b"\xcf\xfa\xed\xfe", b"\xca\xfe\xba\xbe"): return "MACHO_CANDIDATE"
    if prefix.startswith(b"\0asm"): return "WASM"
    if prefix.startswith(b"PK\x03\x04"): return "ZIP"
    return "UNCLASSIFIED_STATIC_BYTES"

def _open_root_fd(root: Path) -> int:
    """R6-F01: walk every absolute component with O_NOFOLLOW|O_DIRECTORY relative to the previous fd."""
    dflags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | getattr(os,"O_CLOEXEC",0)
    parts = [p for p in str(root).split("/") if p]
    if any(p in (".","..") for p in parts): raise Denied("ROOT_PATH_INVALID")
    fd = os.open("/", dflags)
    try:
        for p in parts:
            try:
                st = os.stat(p, dir_fd=fd, follow_symlinks=False)
            except OSError as e:
                raise Denied("ROOT_UNAVAILABLE_"+str(e.errno)) from e
            if stat.S_ISLNK(st.st_mode): raise Denied("ROOT_UNAVAILABLE_OR_SYMLINK")
            try:
                nfd = os.open(p, dflags, dir_fd=fd)
            except OSError as e:
                # ELOOP/ENOTDIR here means the component was swapped after lstat: still a symlink race
                raise Denied("ROOT_UNAVAILABLE_OR_SYMLINK" if e.errno in (errno.ELOOP, errno.ENOTDIR) else "ROOT_UNAVAILABLE_"+str(e.errno)) from e
            os.close(fd); fd = nfd
        return fd
    except BaseException:
        os.close(fd); raise

def _fd_read_snapshot(root: Path, target: Path) -> bytes:
    if os.name != "posix" or not _OPEN_SUPPORTS_DIR_FD or not hasattr(os,"O_NOFOLLOW") or not hasattr(os,"O_DIRECTORY") or not hasattr(os,"O_PATH") or not hasattr(fcntl,"F_SETLEASE"):
        raise Denied("SECURE_OPENAT_UNAVAILABLE_THIS_PLATFORM")
    root = Path(os.path.abspath(root))
    target = Path(os.path.abspath(target))
    try: rel = target.relative_to(root)
    except ValueError as ex: raise Denied("ARTIFACT_OUTSIDE_APPROVED_ROOT") from ex
    if not rel.parts: raise Denied("ARTIFACT_IS_ROOT")
    dflags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | getattr(os,"O_CLOEXEC",0)
    pflags = os.O_PATH | os.O_NOFOLLOW | getattr(os,"O_CLOEXEC",0)
    opened = []
    try:
        parent = _open_root_fd(root)
        opened.append(parent)
        for item in rel.parts[:-1]:
            if item in (".",".."):
                raise Denied("ARTIFACT_PATH_INVALID")
            parent = os.open(item, dflags, dir_fd=parent)
            opened.append(parent)
        # R6-F02: O_PATH never opens the object for I/O (FIFO writers stay blocked, device open() hooks do not run)
        pfd = os.open(rel.parts[-1], pflags, dir_fd=parent)
        opened.append(pfd)
        pst = os.fstat(pfd)
        if stat.S_ISLNK(pst.st_mode): raise Denied("SYMLINK_COMPONENT")
        if not stat.S_ISREG(pst.st_mode): raise Denied("NOT_REGULAR_FILE")
        if pst.st_nlink != 1: raise Denied("HARDLINK_NLINK_NOT_1")   # R6-F04
        f = os.open("/proc/self/fd/%d" % pfd, os.O_RDONLY | os.O_NONBLOCK | getattr(os,"O_CLOEXEC",0))
        opened.append(f)
        before = os.fstat(f)
        if (before.st_dev, before.st_ino) != (pst.st_dev, pst.st_ino): raise Denied("REOPEN_INODE_MISMATCH")
        if not stat.S_ISREG(before.st_mode): raise Denied("NOT_REGULAR_FILE")
        if before.st_size == 0 or before.st_size > MAX_FILE: raise Denied("FILE_SIZE_LIMIT")
        # R6-F03: read lease is refused (EAGAIN) while any writable open exists and is broken by any later writer open/truncate
        prev = None
        try:
            prev = signal.signal(signal.SIGIO, signal.SIG_IGN)
        except ValueError:
            pass  # not main thread: SIGIO disposition must already be non-fatal; default handled below
        if prev is None and signal.getsignal(signal.SIGIO) in (signal.SIG_DFL, None):
            raise Denied("LEASE_SIGNAL_UNSAFE_NON_MAIN_THREAD")
        try:
            try: fcntl.fcntl(f, fcntl.F_SETLEASE, fcntl.F_RDLCK)
            except OSError as e:
                raise Denied("WRITER_PRESENT_OR_LEASE_UNAVAILABLE_"+str(e.errno)) from e
            try:
                data = os.pread(f, MAX_FILE+1, 0)
                while len(data) < before.st_size:
                    chunk = os.pread(f, MAX_FILE+1-len(data), len(data))
                    if not chunk: break
                    data += chunk
                lease_held = fcntl.fcntl(f, fcntl.F_GETLEASE) == fcntl.F_RDLCK
            finally:
                fcntl.fcntl(f, fcntl.F_SETLEASE, fcntl.F_UNLCK)
        finally:
            if prev is not None: signal.signal(signal.SIGIO, prev)
        if not lease_held: raise Denied("WRITER_OPENED_DURING_READ")
        if len(data) != before.st_size or len(data)>MAX_FILE: raise Denied("FILE_SIZE_CHANGED_OR_LIMIT")
        after = os.fstat(f)
        if (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns):
            raise Denied("FILE_CHANGED_DURING_READ")
        return data
    except OSError as e:
        if e.errno == errno.ELOOP: raise Denied("SYMLINK_COMPONENT") from e
        raise Denied("SECURE_OPEN_FAILED_"+str(e.errno)) from e
    finally:
        for f in reversed(opened): os.close(f)

def _safe_member_name(name: str):
    if not name or name.startswith("/") or "\\" in name or "\0" in name or re.match(r"^[A-Za-z]:",name):
        raise Denied("ZIP_PATH_INVALID")
    parts = name.rstrip("/").split("/")
    if any(not p or p in (".","..") or ":" in p or p.rstrip(" .")!=p or WIN_RESERVED.fullmatch(p) for p in parts):
        raise Denied("ZIP_PATH_INVALID")
    if any(any(ord(c)<32 or unicodedata.category(c) in BAD_UNICODE_CATS for c in p) for p in parts):
        raise Denied("ZIP_PATH_INVALID")   # R6-F05
    return "/".join(unicodedata.normalize("NFC",p).casefold() for p in parts)

def _validate_zip_bytes(data: bytes) -> dict:
    try:
        with zipfile.ZipFile(io.BytesIO(data),"r") as z:
            infos=z.infolist()
            if len(infos)>MAX_ENTRIES: raise Denied("ZIP_ENTRY_COUNT_LIMIT")
            total=0
            seen=set()
            normalized_paths=[]
            for i in infos:
                name=i.filename
                norm=_safe_member_name(name)
                if norm in seen: raise Denied("ZIP_PATH_OR_DUPLICATE_INVALID")
                seen.add(norm);normalized_paths.append((norm,i.is_dir()))
                if i.flag_bits & 1: raise Denied("ZIP_ENCRYPTED_UNSUPPORTED")
                mode=(i.external_attr>>16)&65535
                typ=stat.S_IFMT(mode)
                if typ not in (0,stat.S_IFREG,stat.S_IFDIR): raise Denied("ZIP_UNSAFE_FILE_TYPE")
                total+=i.file_size
                if total>MAX_UNCOMPRESSED: raise Denied("ZIP_UNCOMPRESSED_SIZE_LIMIT")
                if i.file_size>MAX_RATIO*max(1,i.compress_size): raise Denied("ZIP_COMPRESSION_RATIO_LIMIT")
                o=i.header_offset
                if o<0 or o+30>len(data) or data[o:o+4]!=b"PK\x03\x04": raise Denied("ZIP_LOCAL_HEADER_INVALID")
                hdr=struct.unpack_from("<HHHHHIIIHH",data,o+4)
                flags, method,fnlen,extralen=hdr[1],hdr[2],hdr[-2],hdr[-1]
                if o+30+fnlen+extralen>len(data): raise Denied("ZIP_LOCAL_HEADER_INVALID")
                rawname=data[o+30:o+30+fnlen]
                if b"\0" in rawname: raise Denied("ZIP_LOCAL_NAME_INVALID")
                enc="utf-8" if i.flag_bits&0x800 else "cp437"
                try: local_name=rawname.decode(enc,"strict")
                except UnicodeError as ex: raise Denied("ZIP_LOCAL_NAME_INVALID") from ex
                if local_name!=name or flags!=i.flag_bits or method!=i.compress_type:
                    raise Denied("ZIP_LOCAL_CENTRAL_MISMATCH")
            _check_layout_and_content(z, infos, data)   # R6-F06/F07/F08
            # Same prefix cannot denote a regular file and the ancestor of another member.
            for p,isdir in normalized_paths:
                for other,otherdir in normalized_paths:
                    if other!=p and other.startswith(p+"/") and not isdir:
                        raise Denied("ZIP_FILE_DIRECTORY_PREFIX_COLLISION")
            return {"entries":len(infos),"declared_uncompressed_bytes":total,"entries_extracted":False,"zip_metadata_bound_to_source_bytes":True}
    except Denied:
        raise
    except (zipfile.BadZipFile,EOFError,OSError,UnicodeError,struct.error) as ex:
        raise Denied("ZIP_MALFORMED") from ex
    except Exception as ex:   # R6-F09 fail closed on any parser surprise
        raise Denied("ZIP_MALFORMED_UNEXPECTED_"+type(ex).__name__) from ex

def _eocd(data: bytes):
    i = data.rfind(b"PK\x05\x06", max(0, len(data)-22-65535))
    if i < 0 or i+22 > len(data): raise Denied("ZIP_EOCD_MISSING")
    disk, cddisk, n_disk, n_total, cd_size, cd_off, clen = struct.unpack_from("<HHHHIIH", data, i+4)
    # R6-AXIOM-N01: EOCD plus its declared comment must end at the final captured byte.
    # Otherwise appended unreferenced bytes are not part of the ZIP inventory.
    if i + 22 + clen != len(data):
        raise Denied("ZIP_UNREFERENCED_TRAILING_BYTES")
    return i, n_disk, n_total, cd_size, cd_off

def _check_layout_and_content(z, infos, data: bytes):
    ei, n_disk, n_total, cd_size, cd_off = _eocd(data)
    zip64 = n_total == 0xFFFF or cd_off == 0xFFFFFFFF
    if not zip64:
        if n_total != len(infos) or n_disk != len(infos): raise Denied("ZIP_EOCD_COUNT_MISMATCH")
        if cd_off + cd_size != ei: raise Denied("ZIP_CENTRAL_DIRECTORY_LAYOUT_INVALID")
    else:
        raise Denied("ZIP64_UNSUPPORTED_IN_V03")
    spans = []
    for i in infos:
        o = i.header_offset
        fnlen, extralen = struct.unpack_from("<HH", data, o+26)
        start = o+30+fnlen+extralen
        end = start + i.compress_size
        if i.flag_bits & 8:
            # R6-AXIOM-N02: Data Descriptor is a separate CRC/size witness and
            # must agree with the Central Directory, not merely occupy 12/16 bytes.
            has_signature = data[end:end+4] == b"PK\x07\x08"
            dpos = end + (4 if has_signature else 0)
            if dpos + 12 > cd_off:
                raise Denied("ZIP_LOCAL_DATA_REGION_OUT_OF_BOUNDS")
            descriptor_crc, descriptor_compressed, descriptor_uncompressed = struct.unpack_from("<III", data, dpos)
            if (descriptor_crc, descriptor_compressed, descriptor_uncompressed) != (i.CRC, i.compress_size, i.file_size):
                raise Denied("ZIP_DATA_DESCRIPTOR_CENTRAL_MISMATCH")
            end = dpos + 12
        if end > cd_off: raise Denied("ZIP_LOCAL_DATA_REGION_OUT_OF_BOUNDS")
        spans.append((o, end, i))
    spans.sort(key=lambda s: s[0])
    pos = 0
    for o, end, _ in spans:
        if o < pos: raise Denied("ZIP_OVERLAPPING_ENTRIES")
        if o > pos: raise Denied("ZIP_UNREFERENCED_BYTES_BEFORE_ENTRY")
        pos = end
    if pos != cd_off: raise Denied("ZIP_UNREFERENCED_BYTES_BEFORE_CENTRAL_DIRECTORY")
    budget = MAX_UNCOMPRESSED
    for i in infos:
        if i.is_dir():
            if i.file_size: raise Denied("ZIP_DIRECTORY_WITH_DATA")
            continue
        got = 0
        with z.open(i, "r") as fh:
            while True:
                chunk = fh.read(1 << 16)
                if not chunk: break
                got += len(chunk); budget -= len(chunk)
                if got > i.file_size or budget < 0: raise Denied("ZIP_ACTUAL_SIZE_EXCEEDS_DECLARATION")
        if got != i.file_size: raise Denied("ZIP_ACTUAL_SIZE_MISMATCH")

def triage(root: Path, path: Path, case_id: str) -> dict:
    if not isinstance(case_id,str) or not CASE_RE.fullmatch(case_id): raise Denied("CASE_ID_INVALID")
    raw=_fd_read_snapshot(root,path)
    kind=_kind(raw[:16])
    zip_summary=_validate_zip_bytes(raw) if kind=="ZIP" else None
    embedded = False
    if kind != "ZIP" and b"PK\x05\x06" in raw:
        try: embedded = zipfile.is_zipfile(io.BytesIO(raw))
        except Exception: embedded = True   # R6-F10
    return {
      "schema":SCHEMA,"case_id":case_id,"source_sha256":hashlib.sha256(raw).hexdigest(),
      "source_bytes":len(raw),"artifact_type":kind,
      "evidence_mode":"FD_CAPTURED_BYTES_STATIC_MAGIC_ZIP_CENTRAL_AND_LOCAL_HEADERS_ONLY",
      "zip_summary":zip_summary,"embedded_zip_polyglot":embedded,"claim_ceiling":"C1_DESCRIPTIVE_ONLY",
      "execution_performed":False,"decompilation_performed":False,"mcp_called":False,"network_called":False,
      "claim":"CAPTURED_BYTES_AND_METADATA_OBSERVED_NOT_BEHAVIOR_VERIFIED",
      "authority":"NONE_NOT_AN_AUTHORIZATION_GATE",
      "unresolved":["NOT_A_SANDBOX","WRITER_EXCLUSION_BY_LINUX_LEASE_ONLY_NOT_ROOT_OR_NFS","NO_ZIP64","ZIP_DECLARED_UNCOMPRESSED_ONLY","NO_EXECUTION","NO_SOURCE_CODE_RECOVERY","NO_WINDOWS_NATIVE_HANDLE_VALIDATION"]
    }

def main(argv=None):
    p=argparse.ArgumentParser(description="NEXUS REA C1 offline bound-byte triage V0.4 POSIX-only research candidate")
    p.add_argument("--root",required=True,type=Path);p.add_argument("--artifact",required=True,type=Path);p.add_argument("--case-id",required=True)
    args=p.parse_args(argv)
    try:
        print(json.dumps(triage(args.root,args.artifact,args.case_id),sort_keys=True,separators=(",",":")))
        return 0
    except (Denied,OSError,ValueError) as e:
        print("DENIED_C1: "+str(e),file=sys.stderr)
        return 2
if __name__=="__main__": raise SystemExit(main())
