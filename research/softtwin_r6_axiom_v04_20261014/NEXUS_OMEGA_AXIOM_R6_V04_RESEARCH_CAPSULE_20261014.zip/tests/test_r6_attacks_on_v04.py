"""R6 one-defect regression tests. V0.3 must meet the safe expectation; V0.1 must REPRODUCE the vulnerability
(recorded as VULNERABILITY_REPRODUCED, not SECURITY_PASS)."""
import os, subprocess, sys, unittest, json
from pathlib import Path
HERE = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(HERE/'lane_S')); sys.path.insert(0, str(HERE/'src'))
import r6_attacks as A
class R6Attacks(unittest.TestCase): pass
def mk(cid, fn, exp):
    def t_fixed(self):
        r = A.run_case('nexus_artifact_triage_v04', fn); self.assertTrue(A.classify(exp, r), r)
    def t_repro(self):
        r = A.run_case('nexus_artifact_triage_v01', fn); self.assertFalse(A.classify(exp, r), r)
    return t_fixed, t_repro
for cid, smap, desc, fn, exp in A.CASES:
    f, r = mk(cid, fn, exp); k = cid.replace('-', '_').lower()
    setattr(R6Attacks, f'test_{k}_v04_fixed', f); setattr(R6Attacks, f'test_{k}_v01_vulnerability_reproduced', r)
class R6Stat(unittest.TestCase):
    def test_race_v04_zero_undetected_mixed(self):
        env = dict(os.environ, RACE_N='60')
        o = json.loads(subprocess.check_output([sys.executable, str(HERE/'lane_S/race_mixed_snapshot.py'), 'nexus_artifact_triage_v04'], env=env))
        self.assertEqual(o['nexus_artifact_triage_v04']['undetected_mixed'], 0)
    def test_fuzz_v04_no_unhandled(self):
        o = json.loads(subprocess.check_output([sys.executable, str(HERE/'lane_S/fuzz_exceptions_v04.py'), '600']))
        self.assertEqual(o['v04']['unhandled'], {}); self.assertTrue(o['v01']['unhandled'])
    def test_cli_v01_crashes_on_unsupported_method_v04_exit2(self):
        import io, zipfile, tempfile, struct
        b = io.BytesIO()
        with zipfile.ZipFile(b, 'w') as z: z.writestr('a', b'x')
        d = bytearray(b.getvalue()); struct.pack_into('<H', d, 8, 99)
        cd = d.rfind(b'PK\x01\x02'); struct.pack_into('<H', d, cd+10, 99)
        with tempfile.TemporaryDirectory() as t:
            p = Path(t)/'m.zip'; p.write_bytes(bytes(d))
            rc = {v: subprocess.run([sys.executable, str(HERE/'src'/f'nexus_artifact_triage_{v}.py'), '--root', t, '--artifact', str(p), '--case-id', 'NEXUS_R6_CLI_CASE'], capture_output=True).returncode for v in ('v01', 'v04')}
        self.assertEqual(rc['v04'], 2); self.assertNotEqual(rc['v01'], 2, rc)
if __name__ == '__main__': unittest.main()
