"""AXIOM R6 independent synthetic fixtures, V0.3 reproduced vulnerabilities, V0.4 regression.
All bytes synthetic, local, bounded. Positive legal ZIP comment must remain valid.
"""
import io
import sys
import struct
import tempfile
import unittest
import zipfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'src'))
import nexus_artifact_triage_v03 as v03
import nexus_artifact_triage_v04 as v04
CASE = 'NEXUS_R6_AXIOM_FIXTURE'

class NonSeek(io.BytesIO):
    def seek(self, *args): raise OSError('not seekable')
    def tell(self): raise OSError('not seekable')

def fixed_member(name, method):
    i=zipfile.ZipInfo(name, date_time=(2020, 1, 1, 0, 0, 0))
    i.compress_type=method
    return i

def classic_zip(comment=b''):
    b=io.BytesIO()
    with zipfile.ZipFile(b,'w',zipfile.ZIP_STORED) as z:
        z.writestr(fixed_member('a.txt', zipfile.ZIP_STORED),b'PUBLIC-SYNTHETIC')
        z.comment=comment
    return b.getvalue()

def descriptor_zip():
    b=NonSeek()
    with zipfile.ZipFile(b,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr(fixed_member('a.txt', zipfile.ZIP_DEFLATED),b'PUBLIC-SYNTHETIC' * 20)
    data=b.getvalue()
    assert b'PK\x07\x08' in data
    return data

class T(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.p=self.root/'a.zip'
    def inspect(self,mod,data):
        self.p.write_bytes(data)
        return mod.triage(self.root,self.p,CASE)
    def test_good_zip_v04(self):
        self.assertEqual(self.inspect(v04,classic_zip())['zip_summary']['entries'],1)
    def test_good_zip_with_comment_v04(self):
        self.assertEqual(self.inspect(v04,classic_zip(b'legal comment'))['zip_summary']['entries'],1)
    def test_good_descriptor_v04(self):
        self.assertEqual(self.inspect(v04,descriptor_zip())['zip_summary']['entries'],1)
    def test_trailer_accepted_v03_vulnerability_reproduced(self):
        self.assertEqual(self.inspect(v03,classic_zip()+b'UNREFERENCED_APPEND'*20)['zip_summary']['entries'],1)
    def test_trailer_denied_v04(self):
        with self.assertRaisesRegex(v04.Denied,'ZIP_UNREFERENCED_TRAILING_BYTES'):
            self.inspect(v04,classic_zip()+b'UNREFERENCED_APPEND'*20)
    def test_corrupt_declared_comment_length_denied_v04(self):
        raw=bytearray(classic_zip(b'ok'));q=raw.rfind(b'PK\x05\x06');struct.pack_into('<H',raw,q+20,0)
        with self.assertRaisesRegex(v04.Denied,'ZIP_UNREFERENCED_TRAILING_BYTES'):
            self.inspect(v04,raw)
    def descriptor_mutation(self,at):
        raw=bytearray(descriptor_zip());off=raw.find(b'PK\x07\x08');assert off>=0
        raw[off+at]^=0x70
        return bytes(raw)
    def test_three_descriptor_mutations_accepted_v03_vulnerability_reproduced(self):
        for at in (4,8,12):
            with self.subTest(descriptor_field_offset=at):
                self.assertEqual(self.inspect(v03,self.descriptor_mutation(at))['zip_summary']['entries'],1)
    def test_three_descriptor_mutations_denied_v04(self):
        for at in (4,8,12):
            with self.subTest(descriptor_field_offset=at):
                with self.assertRaisesRegex(v04.Denied,'ZIP_DATA_DESCRIPTOR_CENTRAL_MISMATCH'):
                    self.inspect(v04,self.descriptor_mutation(at))

if __name__=='__main__':unittest.main()
