# NEXUS OMEGA — AXIOM R6 independent causal adjudication R0

**Date:** 2026-10-14 · **Claim ceiling:** `C1_DESCRIPTIVE_ONLY` · **Authority:** `AXIOM_SOFT_ADJUDICATION_ONLY`.

## 1. Causal intake and custody

Six user-provided R6 source objects physically inspected in the current tool runtime. The large `nexus-r6-maxi-return.zip` contains 70 regular-entry names; ZIP CRC passed. Its internal `SHA256SUMS` contains **69/69** matching raw-byte SHA-256 values, covering all 69 remaining entries. A hash-only manifest is **not** an operator signature, authenticated expert identity, receiver ACK, or execution authorization.

| Original upload | Bytes | SHA-256 |
|---|---:|---|
| `NEXUS_~1(20261014-190237).TXT` | 8208 | `52708f98fe07bbe8deee623e54f7843f772e2432a1d231292000988bf6a05865` |
| `NEXUS_~2(9).TXT` | 12156 | `536e8264ac65d6551258328550dc92ac4cb619f1a66336354200ca7c80fad416` |
| `NEXUS_~1(10).MD` | 9389 | `5beafb56eb58ad2f75a496632a9c3c16042ab217aa7b041fea7ce7cc5bf23526` |
| `NEXUS-~2(3).MD` | 12645 | `fd122c5fff0d1b7508b39f8b488403f0f057fdb241fc509b8db835a908ca389c` |
| `NEXUS-~1(7).MD` | 32365 | `6e50850553a661160dc5671463b8129ecff8869c5b04837769fcd37d015aaf93` |
| `nexus-r6-maxi-return.zip` | 179031 | `7f766bdd4113e6033b03221e404f104217c62fdcf608f1518e56350f35aa14c2` |

These are **distinct submissions**. Similar object titles do not certify joint execution. The big ZIP explicitly self-identifies as a **single Grok Bot return**, not a collectively signed multi-expert statement. Some parallel expert reports are static or designed-not-executed, even where others report actual tests. Exact received bytes were available here; **no Cursor receiver ACK** of this R6 ZIP has been observed.

## 2. AXIOM actual executed cross-checks (this session, Linux Python 3.13)

1. Original external V0.3 compatibility/delta: **42/42 PASS**.
2. Original R6 attack suite: **37/37 PASS**. These tests confirm their stated synthetic expectations, not absence of all unknown exploits.
3. Policy validator/injection suite: **18/18 PASS** (synthetic, no live MCP).
4. Original external V0.2 predecessor: **41/42**; remaining mismatch is an expected error-name classification `SECURE_OPEN_FAILED_20` vs `ROOT_UNAVAILABLE_OR_SYMLINK`, not acceptance of the symlink.
5. Prior V0.2's own 11 fixtures against V0.3: **7/11**; one deliberately changed hardlink policy, one version-schema expectation, and two **invalid `os.stat_result` mocks** on Python 3.13. These four cannot be declared four demonstrated security bypasses. They also cannot be reported as 11/11 PASS.
6. Independent seeded mutation subset, 1,000 cases: V0/V0.1/V0.2 each emitted **8 `NotImplementedError`**, V0.3 emitted **zero** unhandled. Caveat: `seed_zip()` uses default ZIP timestamps; its initial raw bytes change across runs even though `random.Random(20261014)` is fixed. Thus mutation byte sequences are **not globally byte-deterministic** without frozen ZIP member timestamps and pinned interpreter.
7. Independent hostile-writer test (50 trials, 1 MiB): V0.1 `1` undetected mixed hash and `49` denied; V0.3 `0` mixed and `50` denied. This confirms a narrow observed improvement, **not** universally atomic snapshotting or guaranteed throughput. The external counts `245–270/300` apply to its own separate run, not our smaller replay.
8. Mathematics: reran `lane_M/math_checks.py`; verified λ = −0.5, N = 1,000, scalar sum ≈ 3993.333333, invalid bound ≈ 888.888889, sharp input-only RHS 4000. Reproduced non-normal 2x2 DC-gain ≈ 40.09975 against scalar `1/(1−ρ) = 2`.
9. Null-model: reran provided `null_model.py` on the 24 held-out texts; **22/24 accepted**, matching JSON. The expert-reported LLM `4/24` constrained acceptance, `0/24` unconstrained, model/binary hashes, RSS, tokens/s and latency remain **EXTERNAL_REPORTED**: the actual GGUF and llama-server bytes were **not delivered for our execution**. The task labels and null-model keywords were authored by the same expert; purported preregistration lacks independently verifiable pre-experiment time-stamping; no operator KVM2 evidence. No general superiority claim over all LLMs.
10. TLA+ supplied TLC logs show 4,512,673 generated states / 447,552 distinct with `BUGGY=FALSE`, and a `OnlyOperatorAuthority` counterexample with `BUGGY=TRUE`. **LOG_REVIEWED**, not independent TLC reexecution. The tiny abstract model is not a proof of live MCP authorization enforcement.

## 3. Two *new* reproduced failures in R6 V0.3, discovered by AXIOM

### R6-AXIOM-N01 — ZIP trailing-bytes inventory gap

A valid ordinary ZIP with synthetic appended `UNREFERENCED_APPEND` bytes remains **ACCEPTED** by V0.3, with unchanged one-entry ZIP inventory and `embedded_zip_polyglot=false`. The unreferenced trailer is bound by **outer** SHA-256 but omitted from the ZIP entry inventory. Therefore it is **NOT** hash-integrity bypass or remote code execution. It is an archive-structure and inventory completeness failure relative to V0.3's gap-free layout ambition.

### R6-AXIOM-N02 — ZIP Data Descriptor consistency gap

A valid nonseekable-produced ZIP (flag 0x08) emits a 16-byte Data Descriptor. V0.3 **ACCEPTS** each independently mutated descriptor field: CRC-32, compressed size, and uncompressed size. It validates the Central Directory CRC during decompression but fails to compare **descriptor witness** fields against the Central Directory. This is an internal-consistency bypass, **not** an executed payload.

### V0.4 candidate: corrected, never overwrites historical V0.3

`src/nexus_artifact_triage_v04.py` is a new versioned POSIX **research candidate**, not a security release. It (a) ensures the End of Central Directory plus declared comment ends at `len(raw)` (valid comments allowed), and (b) parses Data Descriptors and compares CRC/size fields against the Central Directory. The regression suite uses fixed ZIP member timestamps for deterministic **new synthetic fixtures**. No external execution, decompiler, live host access or rights-grant code has been added.

Independent after-patch test results: **79/79 V0.4 adapted compatibility/attack suite PASS** (42 compatibility/delta + 37 R6 attacks); **8/8 AXIOM new differential fixtures PASS**. The latter includes genuine good ZIP, good ZIP with comment, good signed Data Descriptor, V0.3 accepted-malformed counterexamples, and V0.4 denials. The adapter and other source tests remain separately bound.

**Residual limitations:** Linux-specific file lease `F_SETLEASE` may fail on unsupported file systems, disallows certain legitimate concurrent opens and has process-global SIGIO considerations; `/proc/self/fd` is assumed. No NFS, root-level hostile writer, immutable-snapshot, Windows junction/ADS or enterprise deployment guarantee. `st_nlink == 1` is deliberately conservative and can reject legitimate hardlinked files. Legitimate archive formats with arbitrary trailing application metadata are denied by strict policy. No security-pass promotion from synthetic-only tests.

## 4. Inter-expert conflicts and corrections

- **Mathematics:** Correct strict inclusion is `ℓ² ⊊ c₀`; `1/(t+1)` *is* square-summable; `1/√(t+1)` is the valid witness in `c₀ \ ℓ²`. A MISTRAL text passage (the M1 paragraph of `NEXUS-~1(7).MD`) internally **misstates** these facts; that paragraph is REJECTED, while independently checked equations elsewhere are retained. Correct signed scalar gain: `1/(1−|λ|)`; no promotion to matrix claim without an appropriate semigroup norm.
- **EU law:** Official primary case **C-650/17 = Royalty Pharma** (medical supplementary protection certificate, ECLI:EU:C:2020:327), **not Levola Hengelo** as claimed by an earlier parallel expert report. Relevant software-error correction authority is **C-13/20 Top System** (ECLI:EU:C:2021:811); no blanket decompilation right. Keep §§69d/69e purposes and limits separate.
- **Public research index:** Seven source entries, no index self-entry with 40-digit SHA-1 mislabeled as SHA-256. The alleged bug is NOT_REPRODUCED and must NOT spawn work.
- **Tarball identity:** Registry package version and a later pinned Git commit both declare REA 6.5.0. Source return reports 1,650 npm tarball files, only 67 source-blob correspondences, and `gitHead=null`. Tarball correspondence is an EXTERNAL_REPORTED byte analysis unless AXIOM receives and rehashes the 5.63 MB tarball; lack of equality to a later Git commit is not proof of compromise. No install.
- **Claims of `RUNNING`:** Only actual local synthetic runs are accepted at their tested scope. The operator VPS / KVM2 benchmark remains NOT_EXECUTED and no customer production claims follow. Synthetic policy tests do not demonstrate a deployed fail-closed agent system.

## 5. R6 decisions, scientific quality and orchestration

- **R6 full-return research:** `PASS_WITH_MATERIAL_CAVEATS_C1_EVIDENCE_PRODUCING` at *independently reviewed source/reproduction level*.
- **V0.3:** GENUINE_IMPROVEMENT_BUT_NOT_TERMINAL (two previously untested internal ZIP gaps reproduced).
- **V0.4:** SANDBOX_CANDIDATE_87_OF_87_TESTS_PASS, not complete hardening or runtime deployment authorization.
- **CPU:** Null baseline retains research priority only for this specific six-category synthetic task; no host performance claim.
- **Math:** Invalid universal signed-λ bound must remain ERRATUM_REQUIRED until the formal upstream text is revised; proof of counterexample is NOT the act of revising every earlier canonical artifact.
- **Governance:** Tool data never grants execution. No Cursor task triggered by Git push. No Hostinger write. No main merge. No MCP installation. Private source blobs stay private. C1_DESCRIPTIVE_ONLY.
- **Organizational rule:** NO_REPEAT_ZIP_SEARCH. Receiver should fetch authenticated source bytes via a binary-capable transport and verify directly. One substantive next research batch only upon explicit task authority; do not generate follow-up microorders or redundant re-reviews.

**Next:** Preserve this adjudication and synthetic V0.4 as an append-only branch; retain original R6 full return unchanged. Future work should focus on (i) independent fuzzing with frozen fixture bytes and hostile-writer semantics, (ii) real authorized operator CPU null-model work if material, (iii) completing formal math errata in authoritative source, rather than scheduling more ZIP searches. These are scientific directions, **not execution authorizations**.
