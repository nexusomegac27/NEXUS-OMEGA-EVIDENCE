# NEXUS OMEGA — AXIOM R6 V0.4 public-safe reproduction

Source: AXIOM independent R6 adjudication. **C1_DESCRIPTIVE_ONLY; research only; no production or third-party target authorization.** All synthetic local inputs, no network; POSIX/Linux required for file leases (`fcntl.F_SETLEASE`).

The independent V0.4 is **not** a modification of the expert's V0.3; its path and SHA-256 are separately bound. Only two archive-structure inconsistencies are corrected: (A) unreferenced bytes after ZIP EOCD+comment, (B) Data Descriptor CRC/size disagreement with Central Directory.

Unpack the public-safe ZIP into an empty directory and run:

```sh
python3 -m unittest discover -s tests -p 'test_*_on_v04.py' -v
python3 -m unittest tests/test_axiom_v04_new_zip_boundaries.py -v
python3 -m unittest lane_P/test_evidence_policy.py -v
```

Expected on supported local POSIX fixture environment:
- 79/79 copied V0.4 compatibility and R6-attack tests.
- 8/8 AXIOM new differential tests, including V0.3 vulnerability reproduction.
- 18/18 synthetic protocol-policy tests.

Synthetic ZIP members in new differential tests have a **fixed `date_time=(2020,1,1,0,0,0)`** to avoid the original external fuzz harness's time-varying ZIP seed. `lane_S/fuzz_exceptions_v04.py` remains a copy of the historical fuzz harness plus V0.4 evaluation and **still has a time-varying original seed ZIP**; treat that harness as exploratory until its fixture bytes are pinned.

Source package original R6 full ZIP is **private**, not distributed here. No recipient ACK, executable signer, Windows correctness, Hostinger performance or universal sandbox property is asserted.
