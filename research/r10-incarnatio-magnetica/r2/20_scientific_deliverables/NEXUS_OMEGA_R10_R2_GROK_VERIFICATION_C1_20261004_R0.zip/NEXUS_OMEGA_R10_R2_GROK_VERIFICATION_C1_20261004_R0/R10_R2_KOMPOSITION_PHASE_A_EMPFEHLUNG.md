# R10_R2_KOMPOSITION_PHASE_A_EMPFEHLUNG

## Forschungsanker
- BagIt RFC8493 hierarchische File-Layouts + SHA-256/512 Verifikation — stabil seit 2018【6185063708977863198†L11-L18】
- RO-Crate 1.3 released 2026-06-23 DOI 10.5281/zenodo.20720080【5664848043148518695†L5-L11】
- W3C PROV-O Recommendation 2013-04-30 Entity/Activity/Agent【4782249959088587592†L5-L7】
- SCITT RFC9943 Proposed Standard June 2026 Signed Statement + Receipt + Transparent Statement【7047244891310715765†L6-L9】
- in-toto SLSA Provenance + Sigstore + TUF: DSSE envelope, cosign verify-attestation, Rekor v2, multiple impl【3901219064590150579†L8-L17】

## Kompositionsanalyse Ergebnis

**Boring reif und dokumentierte Interop:**
- C01 BagIt+RO-Crate+PROV-O: YES interop via researchobject/ro-crate docs, ledger bag.py, rocrate-validator
- C02 SCITT+in-toto+SLSA+Sigstore+TUF: YES interop via GitHub Artifact Attestations, Tekton Chains, bundle-attestation.sigstore.json pins checksums.txt

**Hypothetisch, keine dokumentierte Interop:**
- C03 CAAM+HDP+TIBET: alle WIP -00/-01, keine Tests, trust mismatch (HDP self-sovereign offline vs CAAM sidecar ReBAC/RATS vs TIBET device-to-device)
- C06 Maximal: Hypothese, verletzt minimal primitives principle

**Empfehlung:**
Minimal reusable = BagIt + RO-Crate + PROV-O + SCITT + in-toto/SLSA/Sigstore
- C01 löst .tla/.cfg nicht vorhanden, rehash, custody gap
- C02 löst TLC-Version unbekannt (SLSA provenance), Handoff quittiert (SCITT Receipt), Failure teilweise (in-toto attestation)
- CAAM + HDP optional für capability + human provenance, aber als WIP beobachten, nicht als Fundament

Kein Exponential Claim. Kein Architektur Final.
