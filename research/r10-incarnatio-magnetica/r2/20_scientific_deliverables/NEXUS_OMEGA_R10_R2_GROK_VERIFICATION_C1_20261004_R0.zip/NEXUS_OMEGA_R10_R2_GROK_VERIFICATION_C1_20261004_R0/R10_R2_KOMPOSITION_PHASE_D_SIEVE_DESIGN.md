# R10_R2_KOMPOSITION_PHASE_D_SIEVE_DESIGN

## Sieb-Fragen aus META.AI

> Bag transportiert .tla + .cfg + Trace? SCITT Receipt liefert Quittierung? SLSA pinnt TLC-Version? CAAM verhindert MANUS Blocker? Wie sieht Failure Artifact aus?

## Test-Protokolle S01-S05 (Design, keine Ausführung ohne Operator)

### S01 BagIt transportiert .tla + .cfg + Trace?
- **Test:** BagIt Struktur erstellen: data/spec/Spec.tla, data/spec/Spec.cfg, data/trace/tlc-output.txt, data/trace/counterexample.itf.json, tagmanifest-sha512.txt, manifest-sha512.txt, bagit.txt, bag-info.txt, fetch.txt falls Declared Absence
- **Verifikation:** bagit.py --validate, SHA-512 stimmt überein, payload internal semantics irrelevant (RFC8493)【6185063708977863198†L11-L18】
- **Nachweis:** BagIt kann strukturierte Verzeichnisse transportieren, hierarchische file layout conventions
- **Erfolg:** PASS wenn bag valid, FAIL wenn checksum mismatch, HOLD wenn .tla > size limit
- **Umgebung:** Python sandbox + bagit lib, Docker optional, kein Netzwerk

### S02 SCITT Receipt liefert Quittierung?
- **Test:** Erstelle Signed Statement: COSE_Sign1 over BagIt manifest hash (C01 output). Sende an SCITT Transparency Service (SCRAPI still draft). Erwarte Receipt.
- **Verifikation:** Receipt enthält inclusion proof, Transparent Statement = Statement + Receipt verifiable offline without contacting service【7047244891310715765†L6-L9】
- **Nachweis:** Quittierung möglich, anders als HDP das kein Receipt liefert
- **Erfolg:** PASS wenn Receipt kommt und offline verify ok, FAIL wenn Service unreachable, HOLD wenn SCRAPI draft nicht implementiert
- **Umgebung:** SCITT reference implementation, COSE lib

### S03 SLSA pinnt TLC-Version?
- **Test:** Erstelle SLSA Provenance v1 in-toto Statement: subject SHA256 of Spec.tla, predicate builder.id, buildType, materials [tla2tools.jar digest], builder version TLC 2.19 from TLA+ tools 1.7.4
- **Verifikation:** in-toto subject is SHA256 of checksums.txt, so signing this one file transitively pins every content【3901219064590150579†L28-L31】. cosign verify-attestation --type slsaprovenance1
- **Nachweis:** Version im Attestation enthalten, offline verifizierbar via Sigstore bundle (DSSE + Fulcio cert + Rekor)
- **Erfolg:** PASS wenn provenance enthält TLC version, FAIL wenn version fehlt, HOLD wenn Sigstore offline
- **Umgebung:** Sigstore cosign, SLSA generator, no central registry needed (vs IPP central polling)

### S04 CAAM verhindert MANUS Blocker?
- **Test:** Erstelle CAAM SCO Session Context Object für TLC-Run: purpose-bound delegation, ReBAC, RATS attestation, sidecar-based【509014478337478558†L5-L8】. Simuliere Capability-Mismatch: Executor hat Tool nicht (R41).
- **Verifikation:** CAAM post-discovery authorization handshake usable after ARDP resolution【509014478337478558†L5-L8】 erkennt mismatch vor Transfer
- **Nachweis:** CAAM kann R41 Blocker adressieren, aber Status -00 sehr früh, may be updated/replaced/obsoleted
- **Erfolg:** PASS wenn mismatch erkannt, FAIL wenn CAAM spec nicht implementierbar, HOLD wenn ARDP nicht vorhanden
- **Umgebung:** CAAM GitHub contextual-agent-authorization-mesh, SPIFFE workload identity mock

### S05 Failure-Artifact für TLC-Counterexample?
- **Test:** Nimm TLC counterexample trace (structured {step, action, state_delta} + violated invariant)【3284281200981550059†L18-L23】, serialisiere als in-toto custom predicate https://nexus-omega.dev/failure/tlc-counterexample/v0.1 (Phase B Schema), DSSE envelope, content-address SHA-256
- **Verifikation:** Offline verification mit public key only (like HDP design goal offline verifiability【3278302269222846379†L43-L51】), no network call
- **Nachweis:** Failure-Artifact funktioniert als First-Class, nicht nur Chattext
- **Erfolg:** PASS wenn offline verify ok und trace vollständig (every state in error trace, in order)【3284281200981550059†L51-L54】, FAIL wenn trace truncated, HOLD wenn ITF not available
- **Umgebung:** Python in-toto lib, DSSE, deterministic JSON

## Test-Umgebung Spezifikation
- Docker/Podman optional, Python 3.9 sandbox vorhanden, Java 17 vorhanden, tla2tools.jar fehlt (TLA_TOOLCHAIN NO)
- Netzwerk PARTIAL, kein direkter datatracker fetch für alle drafts
- Speicher: BagIt bags <100MB, SCITT statements <10KB
- Keine TLC Ausführung ohne Operator (STOP_BOUNDARY_02)

## Erfolgskriterien
- PASS: Artefakt erstellt, SHA-256 berechnet, offline verifizierbar, keine zentrale Registry nötig
- FAIL: Checksum mismatch, Receipt fehlt, Version fehlt, trace truncated
- HOLD: Tool nicht vorhanden (TLC, SCRAPI, CAAM impl) — valid capability finding, not failure

## Sieb-Protokoll Zusammenfassung
S01 und S02 und S03 sind boring reif (BagIt, SCITT, SLSA) — sollten zuerst laufen.
S04 und S05 sind hypothetisch (CAAM WIP, Failure custom predicate) — danach, mit Operator.

Kein Exponential Claim, keine Implementierung in diesem Return, nur Design C1.
