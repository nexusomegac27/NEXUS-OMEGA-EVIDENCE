# R10_R2_KOMPOSITION_PHASE_B_FAILURE_ARTIFACT

## Kritischste Lücke (META.AI)

> F09 Failure als Chattext — Kein Primitiv modelliert TLC Counterexample (R36 InvW1_2 verletzt) als First-Class Artifact.

## Bestehende Failure-Formate Recherche

- TLC Trace: sequence of states, each tagged with action that produced it. stdout contains counterexample trace. Tool skill tla-run-tlc extracts trace as ordered list {step, action, state_delta} plus violated invariant name【3284281200981550059†L18-L23】
- Apalache/Alloy: ITF JSON trace https://apalache-mc.org/docs/adr/015adr-trace.html, cuilo library consumes typed counterexample traces with ITF【3284281200981550059†L33-L37】
- SARIF 2.1.0: tool.driver.name, rules, results[].level error, locations[].physicalLocation.artifactLocation.uri — Standard für Static Analysis, nicht für Counterexamples【5265891526805454691†L21-L29】
- in-toto attestation: custom predicates allowed, _type https://in-toto.io/Statement/v1, predicateType arbitrary【5265891526805454691†L31-L36】
- JUnit: AssertionError expected:<[Field2]> but was <[Field1]> — zu simpel für state traces

Konsequenz: **Kein Standard für TLC-Counterexamples als Artefakt.** SARIF zu statisch, JUnit zu simpel, VEX nur für Vulnerabilities.

## Failure-Artifact Design Vorschlag v0.1 C1 DESCRIPTIVE_ONLY

**Format:** in-toto Statement mit custom predicate `https://nexus-omega.dev/failure/tlc-counterexample/v0.1`

**DSSE Envelope** + **SCITT Signed Statement** → Transparency Service returns Receipt → Transparent Statement offline verifizierbar (RFC9943)【7047244891310715765†L6-L9】

**Felder:**
- failure_id: SHA-256 canonical JSON (content-addressed)
- failure_type: TLC_COUNTEREXAMPLE | APALACHE_COUNTEREXAMPLE | STATE_SPACE_EXHAUSTED | VALIDATION_MISMATCH
- source_spec, source_config: digest SHA256, uri bag://payload/...
- tool_version: TLC 2.19 from TLA+ tools 1.7.4, Java 17, invocation
- trace: ITF JSON + TLC raw text + structured [{step, action, state, delta}] + violated_at_step
- invariant_violated: InvW1_2 (R36)
- expected vs actual
- timestamp, parent_receipt (SCITT Receipt chain), environment (bagit_manifest sha512)
- declared_absence: missing_files explicit (Lacuna Konzept)
- signature: DSSE Ed25519 or Sigstore keyless (Fulcio ephemeral + Rekor)

**Serialisierung:**
- Deterministische JSON Kanonisierung (UPIP Vorschlag)
- SHA-256 content address
- SCITT COSE_Sign1

**Reverse:**
- Success Artifact: states explored, distinct states, depth, timestamp
- Partial: depth limit reached

**Komposition mit SCITT:**
1. Failure Artifact = in-toto Statement + DSSE
2. Senden an SCITT Transparency Service
3. Receipt zurück
4. Paar = Transparent Statement offline verifizierbar ohne Registry (anders als IPP zentrale Registry polling 5s)

**Keine Implementierung, nur Schema Design C1.**

**Nächster Schritt:** Empirische Sieve S05 testen: Counterexample als in-toto Statement offline verifizieren.
