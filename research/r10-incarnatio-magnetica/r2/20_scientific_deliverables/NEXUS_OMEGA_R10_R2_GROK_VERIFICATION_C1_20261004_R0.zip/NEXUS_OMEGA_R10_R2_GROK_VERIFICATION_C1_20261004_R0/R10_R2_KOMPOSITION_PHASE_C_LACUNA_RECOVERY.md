# R10_R2_KOMPOSITION_PHASE_C_LACUNA_RECOVERY

## SOURCE_GAP (META.AI)

> Lacuna SOURCE_GAP — Declared Absence als First-Class ist genau was R41 braucht. Hoch wertvoll aber Quelle nicht erreichbar. Zenodo 22063353 nicht gefunden.

## Suche MISTRAL_VIBE

**Schritt C1 Direkte Suche:**
- browser.search Zenodo 22063353 Lacuna provenance — kein Treffer, nur ancient documents lacuna, LACUNA Testbed 12608602, Signing data citations【950217617116947756†L3-L12】
- browser.search declared absence provenance W3C PROV null value — Ergebnisse: PROV-DM explicit identifier with syntactic marker '-' to mark absence of identifier【3616736597358263562†L14-L18】, DICOM extension uses null to distinguish field was redacted vs never present【3616736597358263562†L5-L9】
- Suche objectsoffactioncollection — nur DERNEX erwähnt, keine Primärquelle erreichbar

**Schritt C2 Fallback Quellen:**
- W3C PROV-DM: marker '-' für absence vorhanden — das ist Declared Absence Pattern
- W3C PROV-O: kann mit custom property prov:hadAbsence? Nicht standard aber erweiterbar
- RO-Crate: Metadata Document kann missing value handling via null oder absent key
- in-toto custom predicate: declared_absence Feld möglich (siehe Failure Artifact Schema)
- VEX: Vulnerability Exploitability eXchange — declares absence of exploitability, ähnliches Konzept

**Schritt C3 Non-Finding Certificate:**

```
NOT_FOUND_WITHIN_THIS_SEARCH_SURFACE != DOES_NOT_EXIST
Search Horizon: browser.search limited to indexed web, Zenodo API not directly queried, datatracker blocked partial
Terms: Zenodo 22063353, Lacuna Specification for Provenance Records, objectsoffactioncollection, Declared Absence + Provenance
Result: No primary source reachable
```

**Schritt C4 Alternative Lösung ohne Lacuna:**

Wie kann Declared Absence in NEXUS modelliert werden ohne Lacuna?

1. **W3C PROV-DM '-' marker:** Nutze syntactic marker '-' für absence of identifier — bereits standardisiert【3616736597358263562†L14-L18】
2. **BagIt manifest + fetch.txt:** BagIt erlaubt fetch.txt für absent files + explicit tag `BagIt-Profile` declares absence
3. **in-toto custom predicate declared_absence:** Array missing_files, present_but_unverified — im Failure Artifact Schema bereits enthalten
4. **RO-Crate metadata:** `"@type": "File"` mit `"contentSize": 0` + `"additionalProperty": {"name": "declaredAbsence", "value": true}`
5. **SCITT:** Registration policy can declare absence — SCITT requires transparency services to maintain registration policies【7047244891310715765†L11-L14】

Empfehlung: Lacuna Konzept ist wertvoll, aber nicht abhängig von Lacuna Spec. Implementiere Declared Absence als:
- BagIt fetch.txt + tag
- PROV-DM '-' marker
- in-toto predicate declared_absence

Damit R41 Gap "nächste Runde erwartet unsichtbare Dateien" explizit modellierbar: nicht einfach fehlen, sondern deklariert fehlen.

Kein synthetischer Nachweis, kein Quellen ohne Primärbindung.
