
"""
R39 magnetic_gap_computer v2 - mit Konvention-Pinning und Identitäts-Asserts
DEV-001 Fix: Kernpfad vs Totalpfad explizit, Default = Kernpfad (klassisch)

Formeln:
  R_core = l_core / (mu0 * mu_r * A_e)
  R_gap = g / (mu0 * A_e)
  R_total = R_core + R_gap
  G1 = R_gap / R_core = mu_r * g / l_core (ideal)
  G3 = W_gap / W_core = G1 (ideal)
  G4 = I_sat_gapped / I_sat_ungapped = 1 + G1 (konventionsunabhängig)
  Kernpfad: mu_e_core = mu_r / (1 + G1) = mu_r / (1 + mu_r*g/l_core)
            G2_core = 1 / (1 + G1)
  Totalpfad: mu_e_total = mu_e_core * (1 + g/l_core)
             G2_total = (1 + g/l_core) / (1 + G1)

Konvention PINNED: KERNPFAD (Encyclopedia Magnetica Standard)
"""

import math
mu0 = 4*math.pi*1e-7

def compute_magnetic_gap_v2(l_core_mm=100, gap_mm=1.0, mu_r=2000, A_e_mm2=100, N=100, B_sat_T=0.4, convention="core_path"):
    """
    convention: "core_path" (klassisch, empfohlen) oder "total_path" (modern)
    """
    l_core = l_core_mm/1000.0
    g = gap_mm/1000.0
    A_e = A_e_mm2*1e-6
    l_e = l_core  # klassische Definition le = l_core
    l_total = l_core + g

    R_core = l_core / (mu0 * mu_r * A_e)
    R_gap = g / (mu0 * A_e)
    R_total = R_core + R_gap

    # Kernwerte
    G1 = R_gap / R_core  # = mu_r * g / l_core ideal
    G3 = G1  # W_gap/W_core ideal
    G4 = R_total / R_core  # = 1 + G1, konventionsunabhängig

    # Permeabilität je Konvention
    mu_e_core = mu_r / (1 + G1)  # Kernpfad
    G2_core = 1.0 / (1 + G1)

    mu_e_total = mu_e_core * (1 + g/l_core)  # Totalpfad
    G2_total = (1 + g/l_core) / (1 + G1)

    if convention == "core_path":
        mu_e = mu_e_core
        G2 = G2_core
    elif convention == "total_path":
        mu_e = mu_e_total
        G2 = G2_total
    else:
        raise ValueError("convention must be core_path or total_path")

    L = N**2 / R_total
    I_sat_gapped = B_sat_T * R_total * A_e / N
    I_sat_ungapped = B_sat_T * R_core * A_e / N

    # Identitäts-Asserts (DEV-001 Fix)
    eps = 1e-12
    assert abs(G3 - G1) < eps, f"IDENTITY FAIL: G3={G3} != G1={G1}"
    assert abs(G4 - (1+G1)) < eps, f"IDENTITY FAIL: G4={G4} != 1+G1={1+G1}"
    if convention == "core_path":
        assert abs(G2 - 1/(1+G1)) < eps, f"IDENTITY FAIL core_path: G2={G2} != 1/(1+G1)"
    else:
        assert abs(G2 - (1+g/l_core)/(1+G1)) < eps, f"IDENTITY FAIL total_path: G2 mismatch"

    return {
        "inputs": {"l_core_mm": l_core_mm, "gap_mm": gap_mm, "mu_r": mu_r, "A_e_mm2": A_e_mm2, "N": N, "B_sat_T": B_sat_T, "convention": convention},
        "R_core": R_core,
        "R_gap": R_gap,
        "R_total": R_total,
        "G1": G1,
        "G2": G2,
        "G3": G3,
        "G4": G4,
        "mu_e": mu_e,
        "mu_e_core": mu_e_core,
        "mu_e_total": mu_e_total,
        "G2_core": G2_core,
        "G2_total": G2_total,
        "L": L,
        "I_sat_gapped": I_sat_gapped,
        "I_sat_ungapped": I_sat_ungapped,
        "convention_pinned": "core_path (klassisch, Encyclopedia Magnetica Standard)",
        "dev_001_fixed": True
    }

if __name__ == "__main__":
    import json
    # Test Kernpfad (gepinnt)
    res_core = compute_magnetic_gap_v2(convention="core_path")
    print("CORE_PATH (PINNED):")
    print(json.dumps(res_core, indent=2))

    # Test Totalpfad (zum Vergleich)
    res_total = compute_magnetic_gap_v2(convention="total_path")
    print("\nTOTAL_PATH (zum Vergleich):")
    print(json.dumps(res_total, indent=2))

    # Sweep
    print("\nSWEEP core_path:")
    for gap in [0.2, 0.5, 1.0, 2.0, 5.0]:
        r = compute_magnetic_gap_v2(gap_mm=gap, convention="core_path")
        print(f"gap {gap}mm: G1={r['G1']:.1f}, G2={r['G2']:.6f}, G3={r['G3']:.1f}, G4={r['G4']:.1f}, mu_e={r['mu_e']:.2f}")
