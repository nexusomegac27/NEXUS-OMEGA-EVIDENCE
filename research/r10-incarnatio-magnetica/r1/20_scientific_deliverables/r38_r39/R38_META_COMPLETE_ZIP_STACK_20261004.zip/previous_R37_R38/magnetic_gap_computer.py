
import math
mu0 = 4*math.pi*1e-7

def compute_magnetic_gap_vector(l_core_mm=100, gap_mm=1.0, mu_r=2000, A_e_mm2=100, N=100, B_sat_T=0.4):
    l_core = l_core_mm/1000
    g = gap_mm/1000
    A_e = A_e_mm2*1e-6
    l_e = l_core + g
    R_core = l_core / (mu0 * mu_r * A_e) if A_e>0 else float('inf')
    R_gap = g / (mu0 * A_e) if A_e>0 else float('inf')
    R_total = R_core + R_gap
    mu_e = l_e / (A_e * R_total * mu0) if R_total>0 else 0
    L = N**2 / R_total if R_total>0 else 0
    I_sat_gapped = B_sat_T * R_total * A_e / N if N>0 else 0
    I_sat_ungapped = B_sat_T * R_core * A_e / N if N>0 else 0
    G1 = R_gap / R_core if R_core>0 else float('inf')
    G2 = mu_e / mu_r if mu_r>0 else 0
    G3 = mu_r * g / l_core if l_core>0 else float('inf')  # W_gap/W_core approx
    G4 = I_sat_gapped / I_sat_ungapped if I_sat_ungapped>0 else float('inf')
    return {
        "G1_reluctance_ratio": G1,
        "G2_permeability_drop": G2,
        "G3_energy_storage_ratio": G3,
        "G4_saturation_tolerance_gain": G4,
        "mu_e": mu_e,
        "L_H": L,
        "R_total": R_total
    }

def decision_function(evidence: dict) -> str:
    blocked = evidence.get("blocked_claims_detected", [])
    if blocked: return "HARD_FAIL"
    if not evidence.get("c4_invariants_preserved", True): return "HARD_FAIL"
    if evidence.get("symbolik_as_evidenz_drift", False): return "HARD_FAIL"
    if evidence.get("implementation_attempt", False): return "HARD_FAIL"
    if evidence.get("direct_omega_write", False): return "HARD_FAIL"
    minor = []
    if evidence.get("namensvarianten_unvereinheitlicht", False): minor.append("namensvarianten")
    if evidence.get("magnetic_gap_vector_not_schema_validated", False): minor.append("vector_schema")
    if minor: return "PASS_WITH_MINOR_REVISIONS"
    return "PASS"

if __name__ == "__main__":
    import json
    vec = compute_magnetic_gap_vector()
    print(json.dumps(vec, indent=2))
