
def compute_oci(total_transitions: int, external_writes: int) -> float:
    if total_transitions==0: return 1.0
    return 1.0 - (external_writes/total_transitions)

def compute_rr(stress_events: list) -> float:
    """
    stress_events: list of dict {connected_after: bool, similarity: 0-1, optimal_similarity:0-1, correction_capability:0-1}
    """
    if not stress_events: return 0.0
    acc=0.0
    for ev in stress_events:
        if not ev.get("connected_after", False):
            continue
        sim = ev.get("similarity",0)
        opt = ev.get("optimal_similarity",0.6)
        corr = ev.get("correction_capability",0)
        acc += (1 - abs(sim-opt)) * corr
    return acc / len(stress_events)

def is_progress(similarity_increase: bool, correction_capability_decrease: bool) -> bool:
    # Falsifikation: similarer aber weniger Korrekturfähigkeit = kein Fortschritt
    if similarity_increase and correction_capability_decrease:
        return False
    return True

# C4 invariant checker
def check_c4_preserved(hard_soft_fusion: bool, hard_soft_separation: bool, confusion: bool, forced_change: bool) -> bool:
    # WITHOUT_CONFUSION, WITHOUT_FORCED_CHANGE, WITHOUT_DIVISION, WITHOUT_SEPARATION
    if confusion or forced_change or hard_soft_fusion or hard_soft_separation:
        return False
    return True
