# -*- coding: utf-8 -*-
"""
NEXUS OMEGA A72 — Deterministic Decision Function
Claim ceiling: C1.1_ARTIFACT_VALIDATED_STRUCTURE_ONLY maximum
"""

from __future__ import annotations
from typing import Any, Dict


def decide_a72(
    hashes_valid: bool,
    schema_valid: bool,
    source_registry_valid: bool,
    all_primitives_traceable: bool,
    symbol_used_as_evidence: bool,
    forbidden_claim_detected: bool,
    sunset_clauses_present: bool,
    tests_passed: bool,
) -> Dict[str, Any]:
    """
    Deterministic A72 decision.
    No override. No interpretation.
    """
    if not hashes_valid:
        return {
            "claim_status": "C1.2_CLOSED",
            "reason": "HASHES_INVALID",
            "artifact_valid": False,
        }

    if not schema_valid:
        return {
            "claim_status": "C1.2_CLOSED",
            "reason": "SCHEMA_INVALID",
            "artifact_valid": False,
        }

    if not source_registry_valid:
        return {
            "claim_status": "C1.2_CLOSED",
            "reason": "SOURCE_REGISTRY_INVALID",
            "artifact_valid": False,
        }

    if not all_primitives_traceable:
        return {
            "claim_status": "C1.2_CLOSED",
            "reason": "PRIMITIVES_NOT_TRACEABLE",
            "artifact_valid": False,
        }

    if symbol_used_as_evidence:
        return {
            "claim_status": "C1.2_CLOSED",
            "reason": "SYMBOL_USED_AS_EVIDENCE",
            "artifact_valid": False,
        }

    if forbidden_claim_detected:
        return {
            "claim_status": "C1.2_CLOSED",
            "reason": "FORBIDDEN_CLAIM_DETECTED",
            "artifact_valid": False,
        }

    if not sunset_clauses_present:
        return {
            "claim_status": "C1.2_CLOSED",
            "reason": "SUNSET_CLAUSE_MISSING",
            "artifact_valid": False,
        }

    if not tests_passed:
        return {
            "claim_status": "C1.2_CLOSED",
            "reason": "TESTS_NOT_PASSED",
            "artifact_valid": False,
        }

    return {
        "claim_status": "C1.1_ARTIFACT_VALIDATED_STRUCTURE_ONLY",
        "reason": "A72_ARTIFACT_STRUCTURE_VALIDATED_NO_EMPIRICAL_CLAIM",
        "artifact_valid": True,
        "forbidden_interpretations": [
            "myth_as_evidence",
            "governance_effectiveness_claim",
            "causal_claim",
            "biological_claim",
            "memory_claim",
            "learning_claim",
            "consciousness_claim",
            "anthropomorphic_claim",
            "magnetic_gap_as_proven_symbiosis",
        ],
    }
