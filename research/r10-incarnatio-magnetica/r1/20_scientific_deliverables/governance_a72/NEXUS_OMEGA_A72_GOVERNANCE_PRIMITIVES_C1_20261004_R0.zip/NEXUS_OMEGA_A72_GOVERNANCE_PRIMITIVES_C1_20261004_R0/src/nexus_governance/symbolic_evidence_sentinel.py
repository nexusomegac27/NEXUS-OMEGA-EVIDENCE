# -*- coding: utf-8 -*-
"""
NEXUS OMEGA A72 — Symbolik-ist-keine-Evidenz-Sentinel
"""

from __future__ import annotations
from typing import Any, Dict, Iterable, List


FORBIDDEN_TERMS = [
    "bewusstsein",
    "qualia",
    "lernt",
    "lernen bestätigt",
    "erinnert",
    "gedächtnis bestätigt",
    "biologisch bewiesen",
    "neurobiologisch bewiesen",
    "kausal bewiesen",
    "governance wirksamkeit bewiesen",
    "evidenz durch mythos",
    "mythos beweist",
    "symbiose bewiesen",
    "magnetic gap beweist",
]

EVIDENCE_MISUSE_PATTERNS = [
    "mythos als evidenz",
    "symbolik als evidenz",
    "platon beweist nexus",
    "ikarus beweist nexus",
    "pandora beweist nexus",
    "odysseus beweist nexus",
    "aristoteles beweist nexus",
    "nietzsche beweist nexus",
    "wu wei beweist nexus",
    "hiob beweist nexus",
    "chalcedon beweist nexus",
    "michelangelo beweist nexus",
]


def flatten_strings(obj: Any) -> Iterable[str]:
    if isinstance(obj, dict):
        for value in obj.values():
            yield from flatten_strings(value)
    elif isinstance(obj, list):
        for item in obj:
            yield from flatten_strings(item)
    elif isinstance(obj, str):
        yield obj


def find_forbidden_terms(*documents: Dict[str, Any]) -> List[dict]:
    findings = []
    for doc_index, document in enumerate(documents):
        for text in flatten_strings(document):
            lower = text.lower()
            for term in FORBIDDEN_TERMS:
                if term in lower:
                    findings.append({
                        "doc_index": doc_index,
                        "type": "forbidden_term",
                        "term": term,
                        "text": text,
                    })
            for pattern in EVIDENCE_MISUSE_PATTERNS:
                if pattern in lower:
                    findings.append({
                        "doc_index": doc_index,
                        "type": "symbolic_evidence_misuse",
                        "pattern": pattern,
                        "text": text,
                    })
    return findings


def check_symbolic_evidence_boundary(
    section_9b: Dict[str, Any],
    section_x: Dict[str, Any],
    section_xi: Dict[str, Any],
) -> dict:
    findings = find_forbidden_terms(section_9b, section_x, section_xi)

    symbol_used_as_evidence = any(
        item["type"] == "symbolic_evidence_misuse"
        for item in findings
    )
    forbidden_claim_detected = len(findings) > 0

    sunset_x = section_x.get("sunset_clause_months")
    sunset_xi = section_xi.get("sunset_clause_months")

    sunset_clauses_present = (
        isinstance(sunset_x, int)
        and sunset_x >= 12
        and isinstance(sunset_xi, int)
        and sunset_xi >= 12
    )

    return {
        "sentinel_passed": (
            not symbol_used_as_evidence
            and not forbidden_claim_detected
            and sunset_clauses_present
        ),
        "symbol_used_as_evidence": symbol_used_as_evidence,
        "forbidden_claim_detected": forbidden_claim_detected,
        "sunset_clauses_present": sunset_clauses_present,
        "findings": findings,
        "claim_boundary": "symbolic_structure_only_no_empirical_evidence",
    }
