# NEXUS OMEGA A72 — Governance Primitive Artifact (External Auditor Production)

## One-command audit

```bash
python scripts/06_reproduce_all.py
```

## Expected claim_status

`C1.1_ARTIFACT_VALIDATED_STRUCTURE_ONLY`

This means only: structure is schema-present, bounded, traceable, no forbidden claims.

It does **not** mean governance effectiveness, empirical evidence, causal proof, biological identity, learning, memory or consciousness.

## Magnetic Gap Computer

`outputs/magnetic_gap_computer_results.json` contains pure physics computations of reluctance, effective permeability, inductance and saturation metrics for an air-gapped magnetic circuit. These are structural analogies only.

## Hard fail status

`C1.2_CLOSED`

## No follow-up without consultation
