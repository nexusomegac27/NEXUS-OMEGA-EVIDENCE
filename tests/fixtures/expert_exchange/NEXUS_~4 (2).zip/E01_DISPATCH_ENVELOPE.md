# E-R2 DISPATCH ENVELOPE · E01 / AI-1

**OBJECT:** `NEXUS_OMEGA_E_R2_DISPATCH_ENVELOPE_E01_20261029_R0`
**PARENT ROUND:** `NEXUS_OMEGA_AXIOM_NATIVE_APP_R2_INDEPENDENT_EXPERT_ROUND_20261028_R1`
**AUTHORITY:** OPERATOR_ALEXANDER_VIA_AXIOM
**DATE:** 2026-10-29
**PRIORITY:** P0
**DOMAIN:** Android App Architect / VC10 lineage
**FIRST_PASS:** BLIND
**CLAIM_CEILING:** `C1_DESCRIPTIVE_ONLY`

## 1. Your mandate

Read `E01` in member `01_AXIOM_CONVOCATION_AND_EXPERT_MANDATES_R1.md` of the R1 package,
including the section **„R1 additional mandate"** — it is part of the binding question. Answer
strictly in the structure of `02_EXPERT_RETURN_TEMPLATE_R1.md` (all mandatory fields).

## 2. Verify before reading (mandatory)

```bash
sha256sum -c SHA256SUMS
sha256sum NEXUS_OMEGA_AXIOM_NATIVE_APP_R2_INDEPENDENT_EXPERT_ROUND_20261028_R1.zip
#   expect: cb593c962d6582ab5e2fb842aa9b5c3853b44db2c265b6e3ddff1894aa0e889e
unzip -t NEXUS_OMEGA_AXIOM_NATIVE_APP_R2_INDEPENDENT_EXPERT_ROUND_20261028_R1.zip   # expect: No errors detected, 6 members
```

Any `MISMATCH` → `STOP_AND_REPORT`. No content use, no verdict, no repair attempt.

## 3. Binding return identity

```
OBJECT = NEXUS_OMEGA_E_R2_EXPERT_E01_RETURN_20261028_R1
PARENT = NEXUS_OMEGA_AXIOM_NATIVE_APP_R2_INDEPENDENT_EXPERT_ROUND_20261028_R1
```

The `_R1` suffix is binding (errata of 2026-10-29). `_R0` or other stamps are rejected at intake
on namespace grounds only. Do not claim AXIOM's intake rehash as your own; declare your own
`INDEPENDENT_REHASH` only for bytes you actually held.

## 4. Prohibitions (non-negotiable)

`GITHUB_WRITE=NO` · `DEVICE_INSTALL=NO` · `PRODUCTIVE_EGRESS=NO` · `PUBLIC_RAW_DATA=NO` ·
`CLAIM_PROMOTION=NO` · no execution outside separately authorized isolated synthetic labs ·
no impersonation of other agents · no copied summaries as substitution for independent work.

## 5. Evidence discipline

Classify every assertion (`DIRECT_BYTES` / `EXECUTION_OBSERVED` / `PUBLIC_PRIMARY_SOURCE` /
`CURSOR_REPORTED` / `INFERENCE` / `SOURCE_NOT_PRESENT`). `NOT_EXECUTED` is neither `FAIL` nor
`PASS`. Adjacent method-name passes never count as exact-ID coverage. Missing evidence is
`SOURCE_GAP`, never fabricated failure or pass.

## 6. Pairwise crosscheck awareness

After the blind first pass, your lane participates in P08 as: pair E01×E10 (build lineage).

## 7. Deadline

`DEADLINE = <set by operator at transmission time>`
